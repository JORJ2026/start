# User guide

## 1. Getting around

- **Sidebar.** Modules are grouped the way a QMS usually runs: Planning, Support, Operation, Evaluation, Improvement, Administration. The number beside a module is its count of open records. A red "*n* overdue" means something needs attention. On phones the sidebar opens from the menu button (top left), and Esc closes it.
- **Acting as.** Choose who you are in the top bar. Everything you create, change, approve or comment on is recorded against that user.
- **Search.** Press `/` to jump to the filter on a list page, or to the global search box elsewhere. Global search covers every field of every record.
- **Lists.** Filter by text, status, *Open only* or *Overdue only*. Click a column heading to sort. Each list remembers its filters and sort between visits. **Export CSV** downloads the whole module.
- **Theme.** The circle button switches between light and dark.

## 2. Working on a record

Every record page has the same layout:

1. **Header.** Shows the ID, title, status, revision (for documents), the next due date and calculated values such as risk score, supplier grade or calibration status.
2. **Progress bar.** Shows the workflow stages, with completed stages marked.
3. **Action buttons.** Show the next allowed steps. A step that is not ready yet appears disabled with the reason underneath (for example, *Required before this step: Containment actions*). Once you start typing, the buttons enable. Clicking one saves your edits first and then checks the step again.
4. **Tabs:**
   - **Details:** the form. Editable records show inputs. Locked records (closed, effective, approved and so on) show read-only text.
   - **Related:** records this one links to, records that link to it, and a traceability chain up to four levels deep. For example, a complaint leads to an NCR, a CAPA, the risk entry, the revised work instruction and the retraining records.
   - **Evidence:** attach files up to 3 MB each. Each file gets a SHA-256 checksum. You can add evidence at any stage, including after closure. Removing evidence requires a reason and is logged.
   - **History:** every change, with old and new values, user, time, comment and hash. The banner confirms the chain was verified.
   - **Approvals:** each approve or reject decision, with a signature hash.
   - **Revisions** (documents only): released revisions and who trained on them.
5. **Comments.** These go into the history permanently.
6. **Shortcut buttons.** These create linked records with the link pre-filled, for example *Raise NCR from this complaint*, *Record calibration* or *Assign training*.

If you try to leave a page with unsaved edits, the app asks first.

## 3. Approvals

Some steps need approval: releasing documents, approving CAPA action plans and closures, completing supplier evaluations, concessions, and so on. The full list is in `WORKFLOW_REFERENCE.md`.

- Clicking such a step sends an **approval request** and locks the record. You can add a note for the approver.
- Any *other* active user with **Approval authority = Yes** can approve or reject it. The requester can never approve their own request (segregation of duties).
- A rejection needs a reason. The record unlocks so the requester can revise it and resubmit.
- The requester can **withdraw** a request.
- **My work** lists approvals waiting for you, your own requests waiting on others, and your items due within 30 days.

When someone approves, the system checks the step's rules again. A step that has become invalid in the meantime cannot be approved.

## 4. The corrective-action lifecycle

| Stage | What to record | Gate to the next stage |
|---|---|---|
| Open | Problem statement, source, owner, target date | Owner and problem present |
| Containment | Immediate actions that protect the customer and stop the problem spreading | Containment recorded |
| Root cause | Method (5 Whys, cause-and-effect, fault tree, is/is-not) and the cause | Method and cause recorded |
| Action plan | One row per action with owner and due date. Also link the risk entries the CAPA updates | Every row has action, owner and due date. **Approval** |
| Implementation | Mark each action Done with its completion date. Revise documents (set *Change driven by CAPA*), assign training and update plans | All actions Done with dates |
| Verification | Evidence that the actions are in place | Verification recorded. The effectiveness due date defaults to 60 days |
| Effectiveness review | Data that shows whether the problem has recurred | *Effective* plus evidence leads to **Close** (**approval**). *Not effective* returns the CAPA to Root cause, with a comment required |

Link the CAPA *from* the source record, using the **CAPA** field on the complaint, the NCR, the audit finding row or the management-review decision row. Audits, complaints and major NCRs cannot be closed until their nonconformities have a CAPA.

**Walkthrough in the demo:** open CAPA-0001, then look at the **Related** tab, **Evidence**, **History** (with the rejected and then approved action plan) and **Approvals**. Next, open DOC-0007 (WI-CNC-014) and its **Revisions** tab to see rev B and who trained on it. Finally, open **Reports → Traceability**.

## 5. Module notes

- **Documents.** New documents start at revision A. *Start revision* on an effective document returns it to Draft as revision B, C and so on, and the change summary becomes mandatory. When a document is released, the system records the effective date, the next review date and a content hash.
- **Training.** Completing a record captures the document revision trained. If the document is revised later, the record shows *Retraining needed* until a newer completed record exists. Verification of competence needs a trainer, evidence and approval.
- **Equipment and calibration.** Next due = last approved passing calibration + interval. A *Fail* or *Pass after adjustment* result needs an impact assessment on earlier measurements. Equipment that is out of service cannot return until it has a current passing calibration.
- **Inspection.** A lot can only be accepted with rejected pieces if an NCR references the inspection. Rejecting a whole lot always needs an NCR.
- **Suppliers.** A supplier can be approved only after a completed evaluation. Completing an evaluation schedules the next one from the supplier's interval.
- **Risks.** Score = likelihood × impact. Low is 1–4, Medium 5–9, High 10–15 and Critical 16–25. Moving to Monitoring requires residual ratings.
- **Management reviews.** New reviews are pre-filled with a checklist of review inputs. Recording the meeting as held captures a snapshot of the live KPIs into the minutes.
- **Objectives.** Add one measurement row per period (YYYY-MM). The latest value is compared with the target in the chosen direction.

## 6. Reports and printing

**Reports** offers eight reports: the CAPA register, overdue and upcoming items, traceability for each CAPA, the training matrix, calibration status, supplier performance, the audit programme and recent activity. Each report can be exported as CSV or printed. To make a PDF, print and choose *Save as PDF*. Any record page can also be printed. The print layout hides the navigation and buttons.

## 7. Backups. Please read this section

Your data lives in this browser profile on this computer only.

- **Back up:** go to Data, backup & integrity and choose **Download backup**. You get a single JSON file with everything, including evidence files, and a checksum.
- **Restore:** choose the file. Before anything is replaced, the app checks the format, the checksum, the schema version and a full integrity check. Your current data is kept as an undo point, and **Undo last restore** brings it back.
- **New computer:** open `qms.html` there, choose *restore a backup* on the setup screen, and select the file.
- Clearing site data or browser history for this file, or uninstalling the browser profile, **deletes the database**. Keep dated backups somewhere else.

## 8. Integrity check

**Run integrity check** (Data page) verifies, for every record:

- the hash chain of its history
- that its current content matches the last recorded change
- that every link resolves
- that IDs, statuses and unique fields are valid
- that evidence files match their checksums

Any problem is listed by record. The check also runs automatically every time the app starts.
