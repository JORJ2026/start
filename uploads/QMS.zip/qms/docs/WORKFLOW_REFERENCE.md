# Workflow and field reference

Generated from `src/core.js` by `node docs/gen-reference.js`, so it always matches the code.

Legend: **Approval** = a different user with approval authority must approve. *conditional* = approval depends on the record content. **Locked** = states where fields cannot be edited.

## People (`PER-0001`, clause 7.1.2 / 7.2)

States: **Active** (initial) · Inactive  
Locked: never

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Deactivate | Active | Inactive |  | required |  |  |
| Reactivate | Inactive | Active |  |  |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Full name | text | yes |  |
| Job title | text |  |  |
| Department | select |  | Quality / Operations / Engineering / Purchasing / Sales / Executive / Maintenance |
| Email | email |  |  |
| Approval authority | select |  | No / Yes |
| System administrator | select |  | No / Yes |

</details>

## Processes (`PRC-0001`, clause 4.4)

States: **Active** (initial) · Retired  
Locked: Retired

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Retire | Active | Retired | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Process name | text | yes |  |
| Owner | ref |  | links to People |
| Purpose | textarea |  |  |
| Inputs | textarea |  |  |
| Outputs | textarea |  |  |
| Performance measures | textarea |  |  |

</details>

## Documents (`DOC-0001`, clause 7.5)

States: **Draft** (initial) · Effective · Obsolete  
Locked: Effective, Obsolete

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Submit for approval | Draft | Effective | yes |  | Owner, Content / scope |  && isEmpty(r.data.changeSummary)) ?  |
| Start revision | Effective | Draft |  | required |  |  |
| Make obsolete | Effective, Draft | Obsolete | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Document number | text | yes | unique |
| Title | text | yes |  |
| Type | select | yes | Quality manual / Policy / Procedure / Work instruction / Form / Specification / Record template |
| Revision | text |  | set by workflow |
| Process | ref |  | links to Processes |
| Owner | ref |  | links to People |
| Change summary | textarea |  |  |
| Change driven by CAPA | ref |  | links to Corrective actions |
| Content / scope | textarea |  |  |
| Review interval (months) | number |  | min 1; max 60 |
| Effective date | date |  | set by workflow |
| Next review | date |  | set by workflow |

</details>

## Internal audits (`AUD-0001`, clause 9.2)

States: **Planned** (initial) · In progress · Report issued · Closed · Cancelled  
Locked: Closed, Cancelled

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Start audit | Planned | In progress |  |  |  |  |
| Issue report | In progress | Report issued |  |  | Actual date, Summary of results |  |
| Close audit | Report issued | Closed | yes |  |  | Every nonconformity finding must be linked to a CAPA before closure. |
| Cancel | Planned | Cancelled | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Audit title | text | yes |  |
| Audit type | select | yes | Process / System / Product / Layered process |
| Process | ref |  | links to Processes |
| Requirement areas (clause refs) | text |  |  |
| Lead auditor | ref | yes | links to People |
| Auditee | ref |  | links to People |
| Planned date | date | yes |  |
| Actual date | date |  |  |
| Scope and criteria | textarea |  |  |
| Summary of results | textarea |  |  |
| Findings | table |  | columns: Type, Clause, Finding, CAPA (→ Corrective action) |

</details>

## Corrective actions (`CAPA-0001`, clause 10.2)

States: **Open** (initial) · Containment · Root cause · Action plan · Implementation · Verification · Effectiveness review · Closed · Cancelled  
Locked: Closed, Cancelled

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Begin containment | Open | Containment |  |  | Owner, Problem statement |  |
| Containment complete | Containment | Root cause |  |  | Containment actions |  |
| Root cause identified | Root cause | Action plan |  |  | Root cause method, Root cause |  |
| Approve action plan | Action plan | Implementation | yes |  | Action plan | Each action needs a description, owner and due date. |
| Actions complete | Implementation | Verification |  |  |  |  // !a.completedOn) ?  |
| Implementation verified | Verification | Effectiveness review |  |  | Implementation verification |  |
| Close as effective | Effectiveness review | Closed | yes |  | Effectiveness evidence | Effectiveness result must be "Effective" to close. |
| Not effective — reinvestigate | Effectiveness review | Root cause |  | required |  | Not effective |
| Cancel | Open, Containment, Root cause, Action plan | Cancelled | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Title | text | yes |  |
| Source | select | yes | Customer complaint / Nonconformance / Internal audit / Supplier issue / Risk review / Management review / Calibration failure |
| Priority | select | yes | Low / Medium / High |
| Owner | ref |  | links to People |
| Process | ref |  | links to Processes |
| Opened | date | yes |  |
| Target closure | date | yes |  |
| Problem statement | textarea | yes |  |
| Containment actions | textarea |  |  |
| Root cause method | select |  | 5 Whys / Cause-and-effect diagram / Fault tree / Is / Is-not / Other |
| Root cause | textarea |  |  |
| Action plan | table |  | columns: Action, Owner (→ Person), Due, Status, Completed |
| Risk register entries updated | refs |  | links to Risk register |
| Implementation verification | textarea |  |  |
| Effectiveness check due | date |  |  |
| Effectiveness result | select |  | Effective / Not effective |
| Effectiveness evidence | textarea |  |  |

</details>

## Nonconformances (`NCR-0001`, clause 8.7)

States: **Open** (initial) · Under review · Dispositioned · Closed · Cancelled  
Locked: Closed, Cancelled

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Start review | Open | Under review |  |  | Owner |  |
| Record disposition | Under review | Dispositioned | conditional |  | Disposition, Disposition rationale |  |
| Close | Dispositioned | Closed |  |  |  |  && !r.data.capa) ?  |
| Cancel (raised in error) | Open, Under review | Cancelled | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Title | text | yes |  |
| Detected | date | yes |  |
| Detection point | select | yes | Receiving inspection / In-process / Final inspection / Customer / Internal audit / Calibration |
| Part / product | text | yes |  |
| Lot / batch | text |  |  |
| Quantity affected | number |  | min 0 |
| Severity | select | yes | Minor / Major / Critical |
| Description | textarea | yes |  |
| Supplier | ref |  | links to Suppliers |
| Customer complaint | ref |  | links to Customer complaints |
| Inspection record | ref |  | links to Inspection records |
| Calibration record | ref |  | links to Calibration records |
| Owner | ref |  | links to People |
| Disposition | select |  | Rework / Repair / Scrap / Return to supplier / Use as is (concession) |
| Disposition rationale | textarea |  |  |
| CAPA | ref |  | links to Corrective actions |
| Disposition due | date |  |  |

</details>

## Customer complaints (`CMP-0001`, clause 8.2.1 / 9.1.2)

States: **Received** (initial) · Investigation · Response sent · Closed · Cancelled  
Locked: Closed, Cancelled

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Start investigation | Received | Investigation |  |  | Owner |  |
| Send response | Investigation | Response sent |  |  | Investigation summary, Response to customer |  |
| Close | Response sent | Closed | yes |  | Customer accepted response |  && !r.data.capa) ?  |
| Cancel (not a complaint) | Received | Cancelled | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Title | text | yes |  |
| Customer | text | yes |  |
| Customer contact | text |  |  |
| Received | date | yes |  |
| Channel | select |  | Email / Phone / Portal / Field visit / Returned goods |
| Part / product | text |  |  |
| Lot / batch | text |  |  |
| Category | select | yes | Dimensional / Cosmetic / Functional / Delivery / Documentation / Packaging |
| Severity | select | yes | Minor / Major / Critical |
| Customer description | textarea | yes |  |
| Owner | ref |  | links to People |
| Response due | date | yes |  |
| Investigation summary | textarea |  |  |
| Response to customer | textarea |  |  |
| Response sent | date |  |  |
| CAPA | ref |  | links to Corrective actions |
| Customer accepted response | select |  | Yes / No / No reply |

</details>

## Risk register (`RSK-0001`, clause 6.1)

States: **Open** (initial) · Treatment · Monitoring · Closed  
Locked: Closed

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Plan treatment | Open | Treatment |  |  | Treatment plan, Owner |  |
| Treatment implemented | Treatment | Monitoring |  |  | Residual likelihood, Residual impact |  |
| Re-treat | Monitoring | Treatment |  | required |  |  |
| Close | Open, Monitoring | Closed | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Title | text | yes |  |
| Type | select | yes | Risk / Opportunity |
| Process | ref |  | links to Processes |
| Description | textarea | yes |  |
| Likelihood (1-5) | select | yes | 1 / 2 / 3 / 4 / 5 |
| Impact (1-5) | select | yes | 1 / 2 / 3 / 4 / 5 |
| Existing controls | textarea |  |  |
| Treatment plan | textarea |  |  |
| Owner | ref |  | links to People |
| Next review | date | yes |  |
| Residual likelihood | select |  | 1 / 2 / 3 / 4 / 5 |
| Residual impact | select |  | 1 / 2 / 3 / 4 / 5 |

</details>

## Suppliers (`SUP-0001`, clause 8.4)

States: **Pending** (initial) · Approved · Conditional · Disapproved  
Locked: never

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Approve supplier | Pending, Conditional | Approved | yes |  |  | , r.id).some(x => x.entity ===  |
| Set conditional | Pending, Approved | Conditional | yes | required |  |  |
| Disapprove | Pending, Approved, Conditional | Disapproved | yes | required |  |  |
| Re-evaluate | Disapproved | Pending |  | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Supplier name | text | yes | unique |
| Category | select | yes | Raw material / Machined components / Surface treatment / Heat treatment / Calibration service / Packaging / Logistics |
| Criticality | select | yes | Low / Medium / High |
| Scope of supply | textarea |  |  |
| Contact | text |  |  |
| Certifications held | text |  |  |
| Evaluation interval (months) | number |  | min 1; max 36 |
| Next evaluation | date |  |  |

</details>

## Supplier evaluations (`SEV-0001`, clause 8.4.1)

States: **Draft** (initial) · Completed  
Locked: Completed

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Complete evaluation | Draft | Completed | yes |  |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Supplier | ref | yes | links to Suppliers |
| Period | text | yes |  |
| Evaluator | ref | yes | links to People |
| Evaluation date | date | yes |  |
| Quality score (0-100) | number | yes | min 0; max 100 |
| On-time delivery (0-100) | number | yes | min 0; max 100 |
| Responsiveness (0-100) | number | yes | min 0; max 100 |
| Defect rate (PPM) | number |  | min 0 |
| Comments | textarea |  |  |

</details>

## Equipment (`EQP-0001`, clause 7.1.5)

States: **In service** (initial) · Out of service · Retired  
Locked: Retired

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Remove from service | In service | Out of service |  | required |  |  |
| Return to service | Out of service | In service |  |  |  |  // !d.lastCal ?  |
| Retire | In service, Out of service | Retired |  | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Asset tag | text | yes | unique |
| Description | text | yes |  |
| Type | select |  | Caliper / Micrometer / Height gauge / CMM / Torque wrench / Pin gauge set / Surface plate / Hardness tester / Thread gauge |
| Location | text |  |  |
| Owner | ref |  | links to People |
| Range / resolution | text |  |  |
| Calibration interval (days) | number | yes | min 1; max 1825 |
| Calibration provider | ref |  | links to Suppliers |

</details>

## Calibration records (`CAL-0001`, clause 7.1.5.2)

States: **Draft** (initial) · Approved · Voided  
Locked: Approved, Voided

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Approve record | Draft | Approved | yes |  |  |  && isEmpty(r.data.impactAssessment)) ?  |
| Void | Draft | Voided |  | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Equipment | ref | yes | links to Equipment |
| Calibration date | date | yes |  |
| Performed by | ref |  | links to Suppliers |
| Certificate number | text | yes |  |
| Result | select | yes | Pass / Pass after adjustment / Fail |
| As-found data | textarea |  |  |
| As-left data | textarea |  |  |
| Impact assessment on prior measurements | textarea |  |  |

</details>

## Training records (`TRN-0001`, clause 7.2 / 7.3)

States: **Assigned** (initial) · Completed · Verified · Cancelled  
Locked: Verified, Cancelled

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Mark completed | Assigned | Completed |  |  | Completed |  |
| Verify competence | Completed | Verified | yes |  | Competence evidence, Trainer / assessor |  |
| Cancel | Assigned | Cancelled |  | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Employee | ref | yes | links to People |
| Training topic | text | yes |  |
| Controlled document | ref |  | links to Documents |
| Method | select | yes | Read and acknowledge / Classroom / On-the-job / External course / E-learning |
| Assigned | date | yes |  |
| Due | date | yes |  |
| Completed | date |  |  |
| Trainer / assessor | ref |  | links to People |
| Competence evidence | textarea |  |  |
| Document revision trained | text |  | set by workflow |
| Retraining due | date |  |  |

</details>

## Inspection plans (`IPL-0001`, clause 8.5.1 / 8.6)

States: **Draft** (initial) · Approved · Obsolete  
Locked: Approved, Obsolete

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Submit for approval | Draft | Approved | yes |  | Characteristics |  |
| Revise plan | Approved | Draft |  | required |  |  |
| Make obsolete | Draft, Approved | Obsolete | yes | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Plan title | text | yes |  |
| Part number | text | yes |  |
| Stage | select | yes | Receiving / First article / In-process / Final |
| Process | ref |  | links to Processes |
| Governing document | ref |  | links to Documents |
| Sampling rule | text |  |  |
| Characteristics | table |  | columns: Characteristic, Specification, Method, Gauge (→ Equipment), Frequency |

</details>

## Inspection records (`INS-0001`, clause 8.6)

States: **Open** (initial) · Accepted · Rejected  
Locked: Accepted, Rejected

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Accept lot | Open | Accepted |  |  |  | , r.data.plan); if (p && p.status !==  |
| Reject entire lot | Open | Rejected |  |  |  | , r.id).some(x => x.entity ===  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Inspection plan | ref | yes | links to Inspection plans |
| Date | date | yes |  |
| Lot / batch | text | yes |  |
| Inspector | ref | yes | links to People |
| Quantity inspected | number | yes | min 1 |
| Quantity rejected | number | yes | min 0 |
| Notes / measurements | textarea |  |  |

</details>

## Quality objectives (`OBJ-0001`, clause 6.2)

States: **Active** (initial) · Achieved · Not achieved · Retired  
Locked: Achieved, Not achieved, Retired

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Mark achieved | Active | Achieved | yes |  |  |  |
| Mark not achieved | Active | Not achieved | yes | required |  |  |
| Retire | Active | Retired |  | required |  |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Objective | text | yes |  |
| Process | ref |  | links to Processes |
| Owner | ref |  | links to People |
| Metric | text | yes |  |
| Unit | text |  |  |
| Direction | select | yes | Higher is better / Lower is better |
| Baseline | number |  |  |
| Target | number | yes |  |
| Target date | date | yes |  |
| How it will be achieved | textarea |  |  |
| Measurements | table |  | columns: Period (YYYY-MM), Value, Note |

</details>

## Management reviews (`MR-0001`, clause 9.3)

States: **Planned** (initial) · Held · Minutes approved  
Locked: Minutes approved

| Action | From | To | Approval | Comment | Required fields | Rule |
|---|---|---|---|---|---|---|
| Record meeting held | Planned | Held |  |  | Held on, Attendees, Review inputs |  |
| Approve minutes | Held | Minutes approved | yes |  | Decisions and actions, Conclusion on QMS suitability, adequacy and effectiveness |  |

<details><summary>Fields</summary>

| Field | Type | Required | Notes |
|---|---|---|---|
| Title | text | yes |  |
| Scheduled | date | yes |  |
| Held on | date |  |  |
| Chair | ref | yes | links to People |
| Attendees | text |  |  |
| Review inputs | table |  | columns: Topic, Summary |
| Decisions and actions | table |  | columns: Decision / action, Owner (→ Person), Due, CAPA (→ Corrective action), Status |
| Conclusion on QMS suitability, adequacy and effectiveness | textarea |  |  |

</details>

