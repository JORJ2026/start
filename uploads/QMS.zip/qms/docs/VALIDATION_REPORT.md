# Validation report

| Item | Value |
|---|---|
| Software | Offline QMS 1.0.0, `dist/qms.html` |
| Build SHA-256 | `1ece96f860392cc22b65cb5a2d22273540e63e5c948729e06dbea2b42f3934ca` |
| Date | 2026-11-27 |
| Environment | Linux, Node v22.23.5, Google Chrome for Testing 153, Playwright 1.63.0 (headless) |
| Result | **Engine tests 50/50 passed · Browser end-to-end tests 22/22 passed** |
| Raw logs | `docs/test-results/core-tests.txt`, `docs/test-results/ui-tests.txt` |

This report records the tests that were actually run against this build. It is evidence that the software behaves as specified in the test environment. It is **not** a validation of your quality system. If your sector requires computerized-system validation, perform your own risk-based installation, operational and performance qualification (IQ/OQ/PQ) in your environment, using this report and the test suites as inputs.

## Requirement traceability

| # | Requirement | Implementation | Verified by |
|---|---|---|---|
| R1 | Offline operation | Single HTML file. No external resources. CSP `connect-src 'none'`. IndexedDB storage | UI: *no network requests were made*; *data persists across reload* |
| R2 | Document control | Documents module: numbering (unique), approval to release, revision letters, revision log with content hash, periodic review date, obsolescence | Core: *approval…*, *locked records refuse edits; revision workflow…*, *readonly fields…* |
| R3 | Internal audits | Audit programme, findings table, closure gate needing a CAPA for each NC | Core: demo integrity; UI: every record and report renders; audit-programme report |
| R4 | Corrective actions | 8-stage workflow, two approval gates, effectiveness loop | Core: *flagship CAPA-0001 traversed…*, *failed effectiveness check that looped back*, *required fields and guards…*; UI: *full corrective-action lifecycle through the UI…* |
| R5 | Nonconformance reports | Detection point, disposition, conditional approval, CAPA gate | Core: *conditional approval: NCR concession…* |
| R6 | Risk register | L×I scoring, residual risk, heat map, review due dates | Core: KPI tests; UI: dashboard render |
| R7 | Supplier evaluations | Weighted score and grade, approval gate, re-evaluation scheduling | Core: *supplier evaluation completion schedules…* |
| R8 | Calibration management | Interval, next due, overdue, impact assessment on failure, return-to-service gate | Core: *equipment cannot return to service…* |
| R9 | Training records | Revision-aware currency, competence verification approval, matrix | Core: *training currency detects retraining…*, trace test |
| R10 | Customer complaints | Response due, investigation, acceptance, CAPA gate | Core: flagship trace test |
| R11 | Inspection plans | Characteristics linked to gauges, approval, inspection records and yield, NCR gate | Core: *cross-field validation…*; UI: lists and records render |
| R12 | Management reviews | Input checklist, decisions, KPI snapshot, minutes approval | Core: *management review captured a KPI snapshot…* |
| R13 | Quality objectives | Targets, direction, measurements, on/off-target status | Core: KPI tests; UI: dashboard |
| R14 | Performance dashboards | Live KPIs and 6 charts with data tables | Core: *KPIs agree with direct counts*; UI: dashboard at 8 viewports |
| R15 | Meaningful relationships | Typed references including in table rows; reverse links; traceability chain | Core: *flagship trace links…*, *trace from CAPA-0001 reaches the revised document…*, *integrity detects dangling references* |
| R16 | Approval workflows | Pending lock, segregation of duties, authority check, reject with reason, withdraw, re-check at approval, signature hash | Core: *approval: pending locks…*, *only the requester can withdraw…*; UI: *reject with reason…*, lifecycle test (requester sees no Approve button) |
| R17 | Revision histories | Per-record hash-chained history with field-level diffs | Core: all *integrity detects…* tests; UI: every History tab verified on all 122 demo records |
| R18 | Evidence attachments | Stored with SHA-256, 3 MB limit, logged removal with reason | Core: *attachments…*, *integrity detects corrupted evidence files*; UI: *evidence upload, checksum, download round-trip* |
| R19 | Due dates | Due logic per type, overdue flags, *My work*, due report | Core: *due items flag overdue work…* |
| R20 | Reporting | 8 reports, CSV export, print stylesheet | UI: *every report…renders*, *CSV and audit-trail exports…*, print render |
| R21 | Realistic demo data, full CAPA lifecycle | Scripted through the API; 122 records; fictional names | Core: *demo data passes the full integrity check*, *covers every module*, *deterministic*, flagship tests |
| R22 | Validate workflows | See R4, R5, R7, R8, R16 | 18 workflow tests in total |
| R23 | Validate record integrity | 8 tamper scenarios, startup check, on-demand check | Core: 8 *integrity detects…* tests; UI: *integrity check button reports tampering…* |
| R24 | Validate exports | CSV structure, escaping, formula neutralization, audit trail completeness and order | Core: 3 export tests; UI: downloaded files parsed |
| R25 | Validate backup restoration | Lossless round-trip, sequence continuity, 5 refusal cases, no change on failure, undo, restore from setup | Core: 6 backup tests; UI: 3 backup/restore tests |
| R26 | No copyrighted standard text; no certification claim | Clause numbers only. Wording is our own. Notice in app and README | Manual review (below) |
| R27 | Usability and accessibility | Labels on all controls, keyboard search, focus styles, dialogs, reduced motion, forced colors | UI: *form controls all have accessible names*, *keyboard…*, *mobile navigation drawer…* |
| R28 | Responsive | Breakpoint layouts | UI: no overflow at 320, 375, 414, 768, 1024, 1280, 1920 and 2560 px on 6 key pages |

## Defects found during validation and fixed

| Defect | Found by | Fix |
|---|---|---|
| Workflow buttons stayed disabled after typing a required value until the user saved manually | UI lifecycle test | Unsaved edits now enable the buttons. Clicking saves first, then re-checks the step |
| 8–12 px horizontal overflow at 320 px (two-column panels, file input) | UI responsive test | Responsive minimums using `min(…,100%)`; file inputs capped at container width |
| Traceability fanned out through shared process records, linking unrelated CAPAs | Visual review | Hub records are not expanded; added document → CAPA link; regression test added |
| Locked records showed greyed, truncated inputs | Visual review | Locked records now render as read-only text and tables |
| Toasts piled up during fast workflows | Visual review | At most 3 toasts at once; redundant "saved" message removed when a step change auto-saves |

## Manual review checklist

- [x] No ISO 9001:2015 requirement text is reproduced. Modules cite clause numbers. The management-review input list and all help text are original wording.
- [x] The app (Data page), README and this report state that software use does not guarantee conformity or certification.
- [x] All demo people, companies, suppliers and customers are fictional. Emails use the reserved `.example` domain.
- [x] Screenshots reviewed in light and dark themes, at desktop and mobile sizes, and in print layout (`docs/screenshots/`).

## Known limitations

1. Single-user per browser profile. No concurrent multi-user editing, no merging of databases.
2. *Acting as* is not authentication. See `ADMINISTRATION.md`.
3. History is tamper-evident, not tamper-proof.
4. Evidence is limited to 3 MB per file. Very large evidence sets increase backup size, and localStorage fallback mode has a limit of about 5 MB.
5. The browser tests ran on Chrome only. Firefox and Safari use the same standard APIs (IndexedDB, `<dialog>`, Blob downloads) but were not run in this validation.
6. No e-mail notifications, because the app is offline by design. *My work* and the overdue indicators take their place.
