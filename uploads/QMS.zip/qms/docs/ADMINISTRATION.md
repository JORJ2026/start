# Administration and data guide

## Architecture

```
dist/qms.html
 ├─ core.js   pure engine, no DOM. Runs in the browser and in Node
 │    schema (16 record types) → validation → workflows and approvals
 │    → hash-chained history → relationships → integrity → CSV/JSON/backup → KPIs
 ├─ seed.js   demonstration data, created through the public engine API
 └─ app.js    UI: hash router, views, forms, charts (inline SVG), storage adapter
```

- **No dependencies.** No external scripts, fonts or images. A Content Security Policy in the page blocks all network connections (`connect-src 'none'`).
- **Storage.** The app uses IndexedDB (key `database`), falls back to localStorage, and falls back again to memory with a visible warning. The page saves 150 ms after each change and shows its status in the top bar. The key `pre-restore` holds the undo point.
- **Single file.** `build.js` inlines the three scripts into `src/index.template.html`. You can edit the source files and rebuild without any tooling beyond Node.

## Data model

Every record has the same envelope:

```json
{
  "id": "CAPA-0001", "status": "Closed",
  "data": { "...fields defined by the schema..." },
  "attachments": [{ "id": "", "name": "", "type": "", "size": 0, "sha256": "", "addedBy": "", "addedAt": "", "description": "", "data": "<base64>" }],
  "approvals":   [{ "decision": "Approved", "transition": "", "to": "", "requestedBy": "", "requestedAt": "", "by": "", "byName": "", "at": "", "comment": "", "signatureHash": "" }],
  "pending": null,
  "revisions": [ "documents only" ],
  "created": "ISO time", "createdBy": "PER-0001",
  "history": [{ "seq": 1, "ts": "", "user": "", "action": "", "changes": [{ "field": "", "from": null, "to": "" }], "comment": "", "snapshotHash": "", "prevHash": "GENESIS", "hash": "" }]
}
```

The database is `{ meta: { schemaVersion, seq: {type: lastNumber}, company, events[] }, records: { type: { id: record } } }`.

### Relationships

Links are stored on one side only. Reverse links are worked out when needed, so they can't fall out of step.

```
complaint ─┐
NCR ───────┼─ capa ─────────────────────────────► CAPA ── risks[] ──► risk
audit.findings[].capa ──────────────────────────► CAPA
review.decisions[].capa ────────────────────────► CAPA
document.capa (change driven by) ───────────────► CAPA
NCR ── complaint / supplier / inspection / calibration
inspection ── plan ──► inspection plan ── characteristics[].gauge ──► equipment
calibration ── equipment, performedBy ──► supplier
training ── person, document          supplierEval ── supplier
most records ── process, owner ──► process, person
```

The traceability view walks these links in both directions, up to four levels. It does not expand through hub records (processes, suppliers, inspection plans, people), because they would connect everything to everything.

## Integrity model

- **History chain.** For each history entry, `hash = SHA-256(prevHash + canonicalJSON(entry without hash))`. The first entry chains from `GENESIS`.
- **Content seal.** Every entry stores `snapshotHash`, a SHA-256 of the record (with attachment metadata, without file bytes) *after* the change. If anyone edits the stored data outside the app, it no longer matches the last entry.
- **Evidence.** Each attachment stores the SHA-256 of its bytes.
- **Approvals.** `signatureHash = SHA-256(decision details + record content at the time of approval)`.
- **Checks performed:** chain links, entry hashes, sequence numbers, content seal, attachment checksums, all references including those in table rows, ID format and sequence range, valid status, unique fields, unknown record types.

This makes the database **tamper-evident**, not tamper-proof. Someone who controls the machine and the code can recompute a consistent database. Use off-site backups, operating-system access control and periodic comparison against archived backups for stronger assurance.

## Backup format

```json
{ "format": "offline-qms-backup", "formatVersion": 1, "schemaVersion": 1,
  "exportedAt": "ISO time", "recordCount": 122, "sha256": "<SHA-256 of canonical JSON of data>", "data": { "meta": {}, "records": {} } }
```

Restore runs in this order:

1. Parse the file.
2. Check the format marker and version.
3. Verify the checksum.
4. Refuse backups from a newer schema. Migrate older ones (the `MIGRATIONS` map in `core.js`).
5. Run a full integrity check on a temporary store.
6. Swap the data in.
7. Run the integrity check again, and roll back if it fails.

If any step fails, the current database is left untouched. A backup whose checksum was recomputed after tampering is still rejected by step 5.

**Suggested routine:** download a daily backup to a network share or other controlled location. Keep at least 30 daily and 12 monthly copies. Test a restore into a separate browser profile every quarter. Record the test as a calibration-style record or as internal-audit evidence.

## Deployment patterns

| Pattern | How | Notes |
|---|---|---|
| Single QA workstation | Keep `qms.html` on the local disk. Use one dedicated OS account | Simplest. Back up to a share |
| Small team, one shared PC | Keep a separate OS login for each person if possible. Choose the right person under *Acting as* | User choice is not authentication |
| Several sites | Each site runs its own copy and sends backups to HQ | There is no merge. Each database is independent |
| Read-only distribution | Send a backup and have the reader restore it in a separate browser profile | Good for auditors |

Multi-user concurrent editing, sign-on and server-side audit storage are outside this offline design. If you need them, `core.js` is self-contained and could run behind a server with a real identity provider.

## Schema changes

1. Edit `ENTITIES` in `src/core.js`. New optional fields need no migration.
2. For breaking changes, increase `SCHEMA_VERSION` and add `MIGRATIONS[oldVersion] = data => newData`.
3. Run `node docs/gen-reference.js`, `node build.js` and both test suites.

## Security notes

- All user content is HTML-escaped before rendering.
- CSV exports put an apostrophe in front of cells starting with `= + - @` to stop formula injection.
- The page's CSP blocks network access, and no data leaves the browser.
- Attachments are stored as data and never executed or rendered as HTML. They are downloaded on request.
