// Generates docs/WORKFLOW_REFERENCE.md from the live schema in src/core.js.
const fs = require('fs'), path = require('path');
const { ENTITIES } = require('../src/core.js');
let md = '# Workflow and field reference\n\nGenerated from `src/core.js` by `node docs/gen-reference.js`, so it always matches the code.\n\n';
md += 'Legend: **Approval** = a different user with approval authority must approve. *conditional* = approval depends on the record content. **Locked** = states where fields cannot be edited.\n\n';
for (const [k, e] of Object.entries(ENTITIES)) {
  md += '## ' + e.plural + ' (`' + e.prefix + '-0001`, clause ' + e.clause + ')\n\n';
  md += 'States: ' + e.workflow.states.map(s => s === e.workflow.initial ? '**' + s + '** (initial)' : s).join(' · ') + '  \n';
  md += 'Locked: ' + (e.lockedStates.length ? e.lockedStates.join(', ') : 'never') + '\n\n';
  md += '| Action | From | To | Approval | Comment | Required fields | Rule |\n|---|---|---|---|---|---|---|\n';
  for (const t of e.workflow.transitions) {
    const req = (t.requires || []).map(r => e.fields.find(f => f.k === r).label).join(', ');
    const rule = t.guard ? (String(t.guard).match(/'([^']{12,})'/) || ['', 'custom check'])[1] : '';
    md += '| ' + t.label + ' | ' + t.from.join(', ') + ' | ' + t.to + ' | ' + (typeof t.approval === 'function' ? 'conditional' : t.approval ? 'yes' : '') + ' | ' + (t.comment ? 'required' : '') + ' | ' + req + ' | ' + rule.replace(/\|/g, '/') + ' |\n';
  }
  md += '\n<details><summary>Fields</summary>\n\n| Field | Type | Required | Notes |\n|---|---|---|---|\n';
  for (const f of e.fields) {
    const notes = [f.ref ? 'links to ' + ENTITIES[f.ref].plural : '', f.options ? f.options.join(' / ') : '', f.columns ? 'columns: ' + f.columns.map(c => c.label + (c.ref ? ' (→ ' + ENTITIES[c.ref].label + ')' : '')).join(', ') : '', f.unique ? 'unique' : '', f.readonly ? 'set by workflow' : '', f.min !== undefined ? 'min ' + f.min : '', f.max !== undefined ? 'max ' + f.max : ''].filter(Boolean).join('; ');
    md += '| ' + f.label + ' | ' + f.type + ' | ' + (f.required ? 'yes' : '') + ' | ' + notes + ' |\n';
  }
  md += '\n</details>\n\n';
}
fs.writeFileSync(path.join(__dirname, 'WORKFLOW_REFERENCE.md'), md);
console.log('docs/WORKFLOW_REFERENCE.md', md.length, 'chars');
