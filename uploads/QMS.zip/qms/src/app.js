/* Offline QMS — browser application (no dependencies). */
(function () {
  'use strict';
  const Core = window.QMSCore, Seed = window.QMSSeed, E = Core.ENTITIES;
  const $ = (s, r) => (r || document).querySelector(s);
  const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
  const esc = v => String(v === null || v === undefined ? '' : v).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const isEmpty = v => v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length);

  /* ------------------------------------------------------------ storage */
  const DBNAME = 'offline-qms', KEY = 'database', PREF = 'offline-qms-prefs';
  const Storage = {
    mode: 'memory', idb: null, mem: {},
    async init() {
      try {
        if (!window.indexedDB) throw new Error('no idb');
        this.idb = await new Promise((res, rej) => {
          const r = indexedDB.open(DBNAME, 1);
          r.onupgradeneeded = () => r.result.createObjectStore('kv');
          r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
          setTimeout(() => rej(new Error('idb timeout')), 4000);
        });
        this.mode = 'indexeddb';
      } catch (e) {
        try { localStorage.setItem('__qms_t', '1'); localStorage.removeItem('__qms_t'); this.mode = 'localstorage'; } catch (e2) { this.mode = 'memory'; }
      }
    },
    async get(k) {
      if (this.mode === 'indexeddb') return new Promise((res, rej) => { const q = this.idb.transaction('kv').objectStore('kv').get(k); q.onsuccess = () => res(q.result || null); q.onerror = () => rej(q.error); });
      if (this.mode === 'localstorage') return localStorage.getItem(DBNAME + ':' + k);
      return this.mem[k] || null;
    },
    async set(k, v) {
      if (this.mode === 'indexeddb') return new Promise((res, rej) => { const tx = this.idb.transaction('kv', 'readwrite'); tx.objectStore('kv').put(v, k); tx.oncomplete = () => res(); tx.onerror = () => rej(tx.error); });
      if (this.mode === 'localstorage') return localStorage.setItem(DBNAME + ':' + k, v);
      this.mem[k] = v;
    },
    async del(k) {
      if (this.mode === 'indexeddb') return new Promise(res => { const tx = this.idb.transaction('kv', 'readwrite'); tx.objectStore('kv').delete(k); tx.oncomplete = () => res(); });
      if (this.mode === 'localstorage') return localStorage.removeItem(DBNAME + ':' + k);
      delete this.mem[k];
    }
  };
  const prefs = (() => { try { return JSON.parse(localStorage.getItem(PREF) || '{}'); } catch (e) { return {}; } })();
  const savePrefs = () => { try { localStorage.setItem(PREF, JSON.stringify(prefs)); } catch (e) { /* storage unavailable */ } };

  /* ------------------------------------------------------------ state */
  let store = null, dirty = false, saveTimer = null, startupIntegrity = null, hasUndo = false;
  const me = () => prefs.user && store && store._raw('people', prefs.user) && store._raw('people', prefs.user).status === 'Active' ? prefs.user : null;
  const meRec = () => (me() ? store._raw('people', me()) : null);
  function setSaveState(t) { $('#saveState').textContent = t; }
  function scheduleSave() {
    setSaveState('Saving…');
    clearTimeout(saveTimer);
    saveTimer = setTimeout(async () => {
      try { await Storage.set(KEY, store.serialize()); setSaveState(Storage.mode === 'memory' ? 'Not persisted' : 'All changes saved'); }
      catch (e) { setSaveState('Save failed'); toast('Could not save to browser storage: ' + e.message + '. Export a backup now.', true); }
    }, 150);
  }
  function attachStore(s) { store = s; store.on(() => scheduleSave()); window.QMSApp.store = store; }

  /* ------------------------------------------------------------ ui helpers */
  function toast(msg, err) {
    const d = document.createElement('div'); d.className = 'toast' + (err ? ' err' : ''); d.textContent = msg;
    const box = $('#toasts'); box.appendChild(d); while (box.children.length > 3) box.firstChild.remove(); setTimeout(() => d.remove(), err ? 7000 : 3500);
  }
  function fail(e) { toast(e && e.message ? e.message : String(e), true); if (e && !(e instanceof Core.QMSError)) console.error(e); }
  const STATUS_CLASS = s => /^(Closed|Effective|Approved|Verified|Accepted|Completed|Minutes approved|Achieved|Active|In service|Current|On target)$/.test(s) ? 'good'
    : /^(Cancelled|Obsolete|Retired|Voided|Inactive|Superseded)$/.test(s) ? '' : /^(Rejected|Disapproved|Not achieved|Out of service|Overdue|Off target|Critical|No calibration)$/.test(s) || /^Retraining/.test(s) ? 'crit'
    : /^(Conditional|Due soon|Major|High)$/.test(s) ? 'warn' : 'info';
  const badge = (s, cls) => s === '' || s === undefined || s === null ? '' : '<span class="badge ' + (cls !== undefined ? cls : STATUS_CLASS(s)) + '">' + esc(s) + '</span>';
  const fmtTs = ts => (ts ? esc(ts.slice(0, 10) + ' ' + ts.slice(11, 16)) : '');
  const person = id => { const p = id && store._raw('people', id); return p ? p.data.name : id || ''; };
  const recTitle = (n, id) => { const r = store._raw(n, id); return r ? store.titleOf(n, r) : ''; };
  const recLink = (n, id, withTitle) => { if (!id) return ''; const r = store._raw(n, id); if (!r) return '<span class="muted">' + esc(id) + ' (missing)</span>'; if (n === 'people') return esc(r.data.name); return '<a href="#/rec/' + n + '/' + esc(id) + '">' + esc(id) + '</a>' + (withTitle ? ' <span class="muted">' + esc(store.titleOf(n, r)) + '</span>' : ''); };
  const fmtVal = (fd, v) => {
    if (isEmpty(v)) return '<span class="muted">—</span>';
    if (fd.type === 'ref') return recLink(fd.ref, v, fd.ref !== 'people');
    if (fd.type === 'refs') return v.map(x => recLink(fd.ref, x, true)).join('<br>');
    if (fd.type === 'textarea') return esc(v).replace(/\n/g, '<br>');
    return esc(v);
  };
  function download(name, content, type) {
    const blob = content instanceof Blob ? content : new Blob([content], { type: type || 'text/plain' });
    const url = URL.createObjectURL(blob); const a = document.createElement('a'); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 2000);
  }
  const stamp = () => new Date().toISOString().slice(0, 16).replace(/[:T]/g, '');

  /* dialog: returns object of values, or null if cancelled */
  function ask(o) {
    return new Promise(resolve => {
      const dlg = $('#dlg');
      dlg.innerHTML = '<form method="dialog" novalidate><h2 id="dlgTitle">' + esc(o.title) + '</h2>' + (o.body || '') +
        (o.fields || []).map((f, i) => '<label class="fld"><span class="lbl">' + esc(f.label) + (f.required ? ' <span class="req" aria-hidden="true">*</span>' : '') + '</span>' +
          (f.type === 'textarea' ? '<textarea name="' + f.name + '" ' + (f.required ? 'required' : '') + (i === 0 ? ' autofocus' : '') + '>' + esc(f.value || '') + '</textarea>'
            : '<input type="' + (f.type || 'text') + '" name="' + f.name + '" value="' + esc(f.value || '') + '" ' + (f.required ? 'required' : '') + (i === 0 ? ' autofocus' : '') + ' autocomplete="off">') + (f.hint ? '<span class="hint">' + esc(f.hint) + '</span>' : '') + '</label>').join('') +
        '<p class="dlg-err" role="alert" style="color:var(--critical);margin:0"></p><div class="dlg-foot">' + (o.noCancel ? '' : '<button class="btn" value="cancel" type="button" data-x="cancel">Cancel</button>') + '<button class="btn ' + (o.danger ? 'danger' : 'primary') + '" value="ok" type="submit">' + esc(o.ok || 'OK') + '</button></div></form>';
      const form = $('form', dlg);
      let done = false;
      const finish = v => { if (done) return; done = true; dlg.close(); resolve(v); };
      form.addEventListener('submit', ev => {
        ev.preventDefault();
        const vals = {}; let bad = '';
        (o.fields || []).forEach(f => { const el = form.elements[f.name]; vals[f.name] = el.value.trim(); if (f.required && !vals[f.name]) bad = f.label + ' is required.'; if (f.match && vals[f.name] !== f.match) bad = 'Type ' + f.match + ' exactly to confirm.'; });
        if (bad) { $('.dlg-err', form).textContent = bad; return; }
        finish(vals);
      });
      $('[data-x=cancel]', form) && $('[data-x=cancel]', form).addEventListener('click', () => finish(null));
      dlg.addEventListener('cancel', ev => { ev.preventDefault(); if (!o.noCancel) finish(null); }, { once: true });
      dlg.showModal();
      const af = $('[autofocus]', dlg) || $('button[type=submit]', dlg); af && af.focus();
    });
  }

  /* ------------------------------------------------------------ navigation */
  const GROUPS = ['Planning', 'Support', 'Operation', 'Evaluation', 'Improvement', 'Administration'];
  const NAV_ORDER = { Planning: ['processes', 'risks', 'objectives'], Support: ['documents', 'training', 'equipment', 'calibrations'], Operation: ['complaints', 'ncrs', 'inspPlans', 'inspections', 'suppliers', 'supplierEvals'], Evaluation: ['audits', 'reviews'], Improvement: ['capas'], Administration: ['people'] };
  function route() {
    const h = (location.hash || '#/dashboard').slice(2).split('?');
    const parts = h[0].split('/').map(decodeURIComponent);
    const q = new URLSearchParams(h[1] || '');
    return { view: parts[0] || 'dashboard', a: parts[1], b: parts[2], c: parts[3], q };
  }
  function renderNav() {
    const r = route(); const cur = r.view === 'list' || r.view === 'rec' || r.view === 'new' ? r.a : r.view;
    const openCount = n => store.list(n).filter(x => !E[n].workflow.terminal.includes(x.status)).length;
    const overdueBy = {}; store.dueItems(0).forEach(d => (overdueBy[d.entity] = (overdueBy[d.entity] || 0) + 1));
    const pend = store.pendingApprovals().filter(p => canDecide(p)).length;
    const item = (href, key, label, count, alert) => '<a href="' + href + '"' + (cur === key ? ' aria-current="page"' : '') + '><span>' + esc(label) + '</span>' + (count !== undefined && count !== '' ? '<span class="count' + (alert ? ' alert' : '') + '">' + count + '</span>' : '') + '</a>';
    let html = '<h2>Overview</h2>' + item('#/dashboard', 'dashboard', 'Dashboard') + item('#/work', 'work', 'My work', pend || '', pend > 0) + item('#/reports', 'reports', 'Reports');
    GROUPS.forEach(g => {
      html += '<h2>' + g + '</h2>';
      NAV_ORDER[g].forEach(n => { const od = overdueBy[n]; html += item('#/list/' + n, n, E[n].plural, od ? od + ' overdue' : openCount(n) || '', !!od); });
      if (g === 'Administration') html += item('#/data', 'data', 'Data, backup & integrity');
    });
    $('#side').innerHTML = html;
  }
  function renderUserSel() {
    const people = store.list('people').filter(p => p.status === 'Active');
    $('#userSel').innerHTML = (me() ? '' : '<option value="">Select user…</option>') + people.map(p => '<option value="' + p.id + '"' + (p.id === me() ? ' selected' : '') + '>' + esc(p.data.name) + (p.data.canApprove === 'Yes' ? ' (approver)' : '') + '</option>').join('');
  }
  function renderBrand() { $('#brand').innerHTML = esc(store.data.meta.company) + '<small>Quality management system</small>'; document.title = store.data.meta.company + ' — QMS'; }

  function render() {
    if (!store) return;
    const r = route();
    renderNav(); renderUserSel(); renderBrand();
    document.body.classList.remove('nav-open'); $('#menuBtn').setAttribute('aria-expanded', 'false');
    const main = $('#main');
    let html = '';
    if (startupIntegrity && !startupIntegrity.ok) html += '<div class="banner crit" role="alert"><strong>Integrity check failed at startup:</strong> ' + startupIntegrity.errors.length + ' problem(s). <a href="#/data">Review on the Data page</a>.</div>';
    if (Storage.mode === 'memory') html += '<div class="banner warn">Browser storage is unavailable here, so changes are kept in memory only and are lost when the page closes. Export a backup from <a href="#/data">Data, backup &amp; integrity</a> to keep your work.</div>';
    if (!me() && store.list('people').length) html += '<div class="banner info">Choose who you are acting as (top right) to create, edit or approve records.</div>';
    try {
      switch (r.view) {
        case 'dashboard': html += viewDashboard(); break;
        case 'work': html += viewWork(); break;
        case 'list': html += viewList(r.a); break;
        case 'rec': html += viewRecord(r.a, r.b, r.c || 'details'); break;
        case 'new': html += viewNew(r.a, r.q); break;
        case 'reports': html += viewReports(r.a || 'capa', r.q); break;
        case 'data': html += viewData(); break;
        case 'search': html += viewSearch(r.q.get('q') || ''); break;
        default: html += '<p>Page not found. <a href="#/dashboard">Go to dashboard</a></p>';
      }
    } catch (e) { console.error(e); html += '<div class="banner crit">Could not display this page: ' + esc(e.message) + '</div>'; }
    main.innerHTML = html;
    dirty = false;
    afterRender(r);
  }
  function afterRender(r) {
    if (r.view === 'list') { const s = $('#listSearch'); if (s && prefs['lastFocus'] === 'listSearch') { s.focus(); s.setSelectionRange(s.value.length, s.value.length); } }
    prefs.lastFocus = '';
  }

  /* ------------------------------------------------------------ dashboard */
  function tile(href, v, l, s, bad) { return '<a class="tile" href="' + href + '"><div class="v">' + (v === null || v === undefined ? '—' : esc(v)) + '</div><div class="l">' + esc(l) + '</div>' + (s ? '<div class="s' + (bad ? ' bad' : '') + '">' + esc(s) + '</div>' : '') + '</a>'; }
  function viewDashboard() {
    const k = store.kpis(), s = k.summary;
    const due = store.dueItems(14);
    const ml = k.months.map(m => m.slice(5) === '01' ? m.slice(0, 4) : ['', 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'][+m.slice(5)]);
    let h = '<div class="page-head"><div><h1>Dashboard</h1><div class="sub">Process performance as of ' + esc(store.today()) + '. Figures are calculated live from the records in this system.</div></div><div><a class="btn" href="#/reports">Reports</a></div></div>';
    h += '<div class="tiles">' +
      tile('#/list/capas?open=1', s.capaOpen, 'Open corrective actions', s.capaOverdue ? s.capaOverdue + ' overdue' : 'None overdue', s.capaOverdue > 0) +
      tile('#/list/ncrs?open=1', s.ncrOpen, 'Open nonconformances', s.ncrLast12 + ' raised in 12 months') +
      tile('#/list/complaints?open=1', s.complaintsOpen, 'Open complaints', s.complaintAvgResponseDays !== null ? 'Avg response ' + s.complaintAvgResponseDays + ' days' : '') +
      tile('#/list/inspections', s.firstPassYieldPct !== null ? s.firstPassYieldPct + '%' : null, 'Inspection yield', 'All inspected lots') +
      tile('#/list/equipment', s.calibrationCurrentPct !== null ? s.calibrationCurrentPct + '%' : null, 'Equipment calibrated', s.calibrationOverdue ? s.calibrationOverdue + ' overdue' : 'None overdue', s.calibrationOverdue > 0) +
      tile('#/list/training', s.trainingCompletionPct !== null ? s.trainingCompletionPct + '%' : null, 'Training complete', s.trainingOverdue ? s.trainingOverdue + ' overdue' : 'None overdue', s.trainingOverdue > 0) +
      tile('#/list/suppliers', s.supplierAvgScore, 'Avg supplier score', s.supplierApproved + ' approved suppliers') +
      tile('#/work', s.pendingApprovals, 'Pending approvals', s.overdueItems + ' overdue items overall', s.overdueItems > 0) + '</div>';
    h += '<div class="cols">';
    h += '<section class="panel"><h2>Nonconformances raised per month</h2>' + barChart(ml, k.ncrByMonth, k.months, 'NCRs') + dataTable(['Month', 'NCRs'], k.months.map((m, i) => [m, k.ncrByMonth[i]])) + '</section>';
    const fpyTarget = (k.objectives.find(o => /yield/i.test(o.title)) || {}).target;
    h += '<section class="panel"><h2>Inspection yield by month</h2>' + lineChart(ml, k.yieldByMonth, k.months, fpyTarget, '%') + (fpyTarget ? '<div class="legend"><span><i style="background:var(--series-1)"></i>Yield</span><span><i style="background:none;border-top:2px dashed var(--text-2);height:0;width:14px"></i>Target ' + esc(fpyTarget) + '%</span></div>' : '') + dataTable(['Month', 'Yield %'], k.months.map((m, i) => [m, k.yieldByMonth[i] === null ? '—' : k.yieldByMonth[i]])) + '</section>';
    h += '<section class="panel"><h2>Corrective actions by stage</h2>' + hbarChart(k.capaByStage) + dataTable(['Stage', 'Count'], k.capaByStage) + '</section>';
    h += '<section class="panel"><h2>Quality objectives</h2>' + (k.objectives.length ? k.objectives.map(o => '<div class="obj-row"><div><a href="#/rec/objectives/' + o.id + '">' + esc(o.title) + '</a><div class="muted">Latest ' + esc(o.latest) + esc(o.unit === '%' ? '%' : ' ' + (o.unit || '')) + ' · target ' + (o.direction === 'Lower is better' ? '≤ ' : '≥ ') + esc(o.target) + '</div></div><div>' + badge(o.performance) + '</div><div class="spark">' + sparkline(o.series.map(x => x[1]), o.target) + '</div></div>').join('') : '<p class="empty">No active objectives.</p>') + '</section>';
    h += '<section class="panel"><h2>Risk register — open risks</h2>' + heatmap(k.riskHeat) + '</section>';
    h += '<section class="panel"><h2>Overdue and due in 14 days</h2>' + (due.length ? '<ul class="list-plain">' + due.slice(0, 10).map(d => '<li><span><a href="#/rec/' + d.entity + '/' + d.id + '">' + esc(d.id) + '</a> ' + esc(d.title) + ' <span class="muted">· ' + esc(d.label) + '</span></span><span class="nowrap">' + (d.overdue ? badge(-d.daysLeft + 'd overdue', 'crit') : badge(d.daysLeft === 0 ? 'today' : 'in ' + d.daysLeft + 'd', 'warn')) + '</span></li>').join('') + '</ul>' + (due.length > 10 ? '<p><a href="#/reports/due">All ' + due.length + ' items</a></p>' : '') : '<p class="empty">Nothing due.</p>') + '</section>';
    h += '<section class="panel"><h2>Audit findings by type</h2>' + hbarChart(k.findingsByType) + '<p class="muted" style="font-size:12px;margin:6px 0 0">Audit programme ' + s.auditsCompletedThisYear + ' of ' + s.auditsPlannedThisYear + ' completed this year.</p></section>';
    h += '<section class="panel"><h2>Nonconformances by detection point</h2>' + hbarChart(k.ncrBySource) + '</section>';
    h += '</div>';
    return h;
  }
  function dataTable(head, rows) { return '<details class="data-view"><summary>View data table</summary><table class="grid"><thead><tr>' + head.map((x, i) => '<th' + (i ? ' class="num"' : '') + '>' + esc(x) + '</th>').join('') + '</tr></thead><tbody>' + rows.map(r => '<tr>' + r.map((x, i) => '<td' + (i ? ' class="num"' : '') + '>' + esc(x) + '</td>').join('') + '</tr>').join('') + '</tbody></table></details>'; }
  function niceMax(v) { if (v <= 0) return 1; const p = Math.pow(10, Math.floor(Math.log10(v))); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p; }
  function barChart(labels, vals, keys, unit) {
    const W = 380, H = 170, L = 26, B = 22, T = 12, max = niceMax(Math.max.apply(null, vals.concat([1]))), bw = (W - L) / vals.length;
    let g = '';
    const steps = max < 4 ? max : 4;
    for (let i = 0; i <= steps; i++) { const y = T + (H - T - B) * (1 - i / steps); g += '<line class="grid-line" x1="' + L + '" x2="' + W + '" y1="' + y + '" y2="' + y + '"/><text x="' + (L - 4) + '" y="' + (y + 3) + '" text-anchor="end">' + (+(max * i / steps).toFixed(1)) + '</text>'; }
    const peak = vals.indexOf(Math.max.apply(null, vals));
    vals.forEach((v, i) => {
      const h = (H - T - B) * v / max, x = L + i * bw + bw * 0.2, w = bw * 0.6, y = H - B - h;
      const r = Math.min(4, w / 2, h);
      g += v > 0 ? '<path class="bar" d="M' + x + ',' + (H - B) + 'V' + (y + r) + 'Q' + x + ',' + y + ' ' + (x + r) + ',' + y + 'H' + (x + w - r) + 'Q' + (x + w) + ',' + y + ' ' + (x + w) + ',' + (y + r) + 'V' + (H - B) + 'Z"/>' : '';
      g += '<rect class="hit" x="' + (L + i * bw) + '" y="' + T + '" width="' + bw + '" height="' + (H - T - B) + '" data-tip="' + esc(keys[i] + ': ' + v + ' ' + unit) + '" tabindex="0"/>';
      g += '<text x="' + (x + w / 2) + '" y="' + (H - 6) + '" text-anchor="middle">' + esc(labels[i]) + '</text>';
      if (i === peak && v > 0) g += '<text class="lbl-strong" x="' + (x + w / 2) + '" y="' + (y - 4) + '" text-anchor="middle">' + v + '</text>';
    });
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Bar chart of ' + esc(unit) + ' per month">' + g + '<line class="axis" x1="' + L + '" x2="' + W + '" y1="' + (H - B) + '" y2="' + (H - B) + '"/></svg>';
  }
  function lineChart(labels, vals, keys, target, unit) {
    const W = 380, H = 170, L = 32, B = 22, T = 12, R = 8;
    const present = vals.filter(v => v !== null).concat(target ? [Number(target)] : []);
    if (!present.length) return '<p class="empty">No data yet.</p>';
    let lo = Math.floor(Math.min.apply(null, present) - 0.5), hi = Math.ceil(Math.max.apply(null, present) + 0.3);
    if (hi > 100 && unit === '%') hi = 100; if (hi - lo < 2) lo = hi - 2;
    const sx = i => L + (W - L - R) * (vals.length === 1 ? 0.5 : i / (vals.length - 1)), sy = v => T + (H - T - B) * (1 - (v - lo) / (hi - lo));
    let g = '';
    for (let i = 0; i <= 4; i++) { const v = lo + (hi - lo) * i / 4, y = sy(v); g += '<line class="grid-line" x1="' + L + '" x2="' + (W - R) + '" y1="' + y + '" y2="' + y + '"/><text x="' + (L - 4) + '" y="' + (y + 3) + '" text-anchor="end">' + (+v.toFixed(1)) + '</text>'; }
    if (target) g += '<line class="target" x1="' + L + '" x2="' + (W - R) + '" y1="' + sy(target) + '" y2="' + sy(target) + '"/>';
    let d = '', pen = false;
    vals.forEach((v, i) => { if (v === null) { pen = false; return; } d += (pen ? 'L' : 'M') + sx(i).toFixed(1) + ',' + sy(v).toFixed(1); pen = true; });
    g += '<path class="line" d="' + d + '"/>';
    let lastI = -1; vals.forEach((v, i) => { if (v !== null) lastI = i; });
    vals.forEach((v, i) => {
      g += '<text x="' + sx(i) + '" y="' + (H - 6) + '" text-anchor="middle">' + esc(labels[i]) + '</text>';
      if (v === null) return;
      if (i === lastI) g += '<circle class="dot" cx="' + sx(i) + '" cy="' + sy(v) + '" r="4.5"/><text class="lbl-strong" x="' + (sx(i) - 6) + '" y="' + (sy(v) - 8) + '" text-anchor="end">' + v + esc(unit) + '</text>';
      const bw = (W - L - R) / Math.max(1, vals.length - 1);
      g += '<rect class="hit" x="' + (sx(i) - bw / 2) + '" y="' + T + '" width="' + bw + '" height="' + (H - T - B) + '" data-tip="' + esc(keys[i] + ': ' + v + unit + (target ? ' (target ' + target + unit + ')' : '')) + '" tabindex="0"/>';
    });
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Line chart">' + g + '</svg>';
  }
  function hbarChart(pairs) {
    const W = 380, rowH = 22, L = 130, H = pairs.length * rowH + 4, max = Math.max.apply(null, pairs.map(p => p[1]).concat([1]));
    let g = '';
    pairs.forEach(([lab, v], i) => {
      const y = i * rowH + 4, w = (W - L - 40) * v / max;
      g += '<text x="' + (L - 8) + '" y="' + (y + 14) + '" text-anchor="end">' + esc(lab) + '</text>';
      if (v > 0) { const r = Math.min(4, w); g += '<path class="bar" d="M' + L + ',' + (y + 3) + 'H' + (L + w - r) + 'Q' + (L + w) + ',' + (y + 3) + ' ' + (L + w) + ',' + (y + 3 + r) + 'V' + (y + 17 - r) + 'Q' + (L + w) + ',' + (y + 17) + ' ' + (L + w - r) + ',' + (y + 17) + 'H' + L + 'Z"/>'; }
      g += '<text class="lbl-strong" x="' + (L + w + 6) + '" y="' + (y + 14) + '">' + v + '</text>';
      g += '<rect class="hit" x="0" y="' + y + '" width="' + W + '" height="' + rowH + '" data-tip="' + esc(lab + ': ' + v) + '"/>';
    });
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Horizontal bar chart">' + g + '<line class="axis" x1="' + L + '" x2="' + L + '" y1="0" y2="' + H + '"/></svg>';
  }
  function sparkline(vals, target) {
    if (!vals.length) return '';
    const W = 120, H = 28, all = vals.concat([Number(target)]), lo = Math.min.apply(null, all), hi = Math.max.apply(null, all), span = hi - lo || 1;
    const sx = i => 2 + (W - 8) * (vals.length === 1 ? 0.5 : i / (vals.length - 1)), sy = v => 3 + (H - 6) * (1 - (v - lo) / span);
    return '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true"><line class="target" x1="2" x2="' + (W - 2) + '" y1="' + sy(target) + '" y2="' + sy(target) + '"/><path class="line" d="' + vals.map((v, i) => (i ? 'L' : 'M') + sx(i).toFixed(1) + ',' + sy(v).toFixed(1)).join('') + '"/><circle class="dot" r="3" cx="' + sx(vals.length - 1) + '" cy="' + sy(vals[vals.length - 1]) + '"/></svg>';
  }
  function heatmap(heat) {
    let g = '<div class="heat" role="table" aria-label="Risk heat map: likelihood rows, impact columns">';
    for (let l = 5; l >= 1; l--) {
      g += '<div class="ax" role="rowheader">L' + l + '</div>';
      for (let s = 1; s <= 5; s++) { const n = heat[l + 'x' + s] || 0, z = Core.utils.riskRating(l * s).toLowerCase(); g += '<div role="cell" class="z-' + z + '" data-tip="' + esc('Likelihood ' + l + ' × impact ' + s + ' = ' + l * s + ' (' + z + '): ' + n + ' risk(s)') + '">' + (n ? '<span class="n">' + n + '</span>' : '') + '</div>'; }
    }
    g += '<div></div>' + [1, 2, 3, 4, 5].map(s => '<div class="ax">I' + s + '</div>').join('') + '</div>';
    return g + '<div class="legend"><span><i class="z-low"></i>Low (1-4)</span><span><i class="z-medium"></i>Medium (5-9)</span><span><i class="z-high"></i>High (10-15)</span><span><i class="z-critical"></i>Critical (16-25)</span></div><p class="muted" style="font-size:12px;margin:6px 0 0">Numbers are counts of open risks (inherent rating). <a href="#/list/risks">Open the register</a>.</p>';
  }

  /* ------------------------------------------------------------ my work */
  function canDecide(p) { const u = meRec(); return !!u && u.data.canApprove === 'Yes' && p.pending.requestedBy !== u.id; }
  function viewWork() {
    const u = meRec();
    const pend = store.pendingApprovals();
    const mine = pend.filter(canDecide), myReq = pend.filter(p => u && p.pending.requestedBy === u.id);
    const due = store.dueItems(30), myDue = due.filter(d => u && d.owner === u.id);
    const row = p => '<tr><td><a href="#/rec/' + p.entity + '/' + p.id + '">' + esc(p.id) + '</a></td><td>' + esc(p.title) + '</td><td>' + esc(E[p.entity].label) + '</td><td>' + esc(p.pending.transition) + '</td><td>' + esc(person(p.pending.requestedBy)) + '</td><td class="nowrap">' + fmtTs(p.pending.requestedAt) + '</td></tr>';
    const tbl = rows => rows.length ? '<div class="tbl-wrap"><table class="grid"><thead><tr><th>ID</th><th>Title</th><th>Type</th><th>Requested step</th><th>Requested by</th><th>When</th></tr></thead><tbody>' + rows.map(row).join('') + '</tbody></table></div>' : '<p class="empty">Nothing here.</p>';
    const dueTbl = rows => rows.length ? '<div class="tbl-wrap"><table class="grid"><thead><tr><th>ID</th><th>Title</th><th>Due for</th><th>Date</th><th>Status</th><th>Owner</th></tr></thead><tbody>' + rows.map(d => '<tr><td><a href="#/rec/' + d.entity + '/' + d.id + '">' + esc(d.id) + '</a></td><td>' + esc(d.title) + '</td><td>' + esc(d.label) + '</td><td class="nowrap">' + esc(d.date) + '</td><td>' + (d.overdue ? badge(-d.daysLeft + 'd overdue', 'crit') : badge('in ' + d.daysLeft + 'd', 'warn')) + '</td><td>' + esc(person(d.owner)) + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="empty">Nothing due in the next 30 days.</p>';
    return '<div class="page-head"><div><h1>My work</h1><div class="sub">' + (u ? 'Acting as ' + esc(u.data.name) + (u.data.canApprove === 'Yes' ? ' — approval authority' : ' — no approval authority') : 'Select a user to see personal work.') + '</div></div></div>' +
      '<section class="panel"><h2>Awaiting my approval (' + mine.length + ')</h2>' + tbl(mine) + '</section>' +
      '<section class="panel"><h2>My requests awaiting others (' + myReq.length + ')</h2>' + tbl(myReq) + '</section>' +
      '<section class="panel"><h2>Assigned to me — overdue or due within 30 days (' + myDue.length + ')</h2>' + dueTbl(myDue) + '</section>' +
      '<section class="panel"><h2>All pending approvals (' + pend.length + ')</h2>' + tbl(pend) + '</section>';
  }

  /* ------------------------------------------------------------ list */
  function listColumns(n) {
    const e = E[n];
    const cols = [{ k: 'id', label: 'ID', get: r => r.id, html: r => '<a href="#/rec/' + n + '/' + r.id + '">' + esc(r.id) + '</a>' }];
    e.fields.filter(f => f.list).forEach(f => cols.push({ k: f.k, label: f.label, get: r => f.type === 'ref' ? (f.ref === 'people' ? person(r.data[f.k]) : (r.data[f.k] || '') + ' ' + recTitle(f.ref, r.data[f.k])) : r.data[f.k], html: r => fmtVal(f, r.data[f.k]) }));
    (e.derivedList || []).forEach(([k, label]) => cols.push({ k: 'd.' + k, label, get: r => store.derive(n, r)[k], html: r => { const v = store.derive(n, r)[k]; return /Status|Grade|Rating|Calibration|Currency|Performance/.test(label) || k === 'rating' || k === 'calStatus' || k === 'currency' || k === 'performance' ? badge(v) : esc(v); } }));
    cols.push({ k: 'status', label: 'Status', get: r => r.status + (r.pending ? ' pending' : ''), html: r => badge(r.status) + (r.pending ? ' ' + badge('Awaiting approval', 'warn') : '') });
    if (e.due) cols.push({ k: 'due', label: 'Next due', get: r => { const d = store.dueOf(n, r); return d ? d.date : ''; }, html: r => { const d = store.dueOf(n, r); if (!d || !d.date) return ''; const left = Core.utils.daysBetween(store.today(), d.date); return '<span class="nowrap">' + esc(d.date) + '</span>' + (left < 0 ? ' ' + badge('Overdue', 'crit') : left <= 14 ? ' ' + badge('Due soon', 'warn') : ''); } });
    return cols;
  }
  function viewList(n) {
    const e = E[n]; if (!e) return '<p>Unknown module.</p>';
    const r = route(), lp = prefs['list:' + n] || {};
    const q = lp.q || '', st = lp.status || '', open = r.q.get('open') === '1' ? true : !!lp.open, od = !!lp.overdue, sort = lp.sort || 'id', dir = lp.dir || 'desc';
    const cols = listColumns(n);
    let rows = store.list(n);
    if (q) { const ql = q.toLowerCase(); rows = rows.filter(x => (x.id + ' ' + JSON.stringify(x.data) + ' ' + store.titleOf(n, x) + ' ' + cols.map(c => c.get(x)).join(' ')).toLowerCase().includes(ql)); }
    if (st) rows = rows.filter(x => x.status === st || (st === '__pending' && x.pending));
    if (open) rows = rows.filter(x => !e.workflow.terminal.includes(x.status));
    if (od) rows = rows.filter(x => { const d = store.dueOf(n, x); return d && d.date && d.date < store.today(); });
    const col = cols.find(c => c.k === sort) || cols[0];
    rows.sort((a, b) => { const x = col.get(a), y = col.get(b); const nx = Number(x), ny = Number(y); const c = !isNaN(nx) && !isNaN(ny) && x !== '' && y !== '' ? nx - ny : String(x || '').localeCompare(String(y || '')); return dir === 'asc' ? c : -c; });
    const total = store.list(n).length;
    let h = '<div class="page-head"><div><h1>' + esc(e.plural) + '</h1><div class="sub">ISO 9001:2015 clause ' + esc(e.clause) + ' · ' + rows.length + ' of ' + total + ' shown</div></div><div class="toolbar" style="margin:0"><button class="btn" data-act="csv" data-n="' + n + '">Export CSV</button>' + (me() ? '<a class="btn primary" href="#/new/' + n + '">New ' + esc(e.label.toLowerCase()) + '</a>' : '') + '</div></div>';
    h += '<div class="toolbar" role="search"><label class="sr" for="listSearch">Filter ' + esc(e.plural) + '</label><input type="search" id="listSearch" data-n="' + n + '" placeholder="Filter…" value="' + esc(q) + '">' +
      '<label class="sr" for="statusFilter">Status</label><select id="statusFilter" data-n="' + n + '"><option value="">All statuses</option>' + e.workflow.states.map(s => '<option' + (s === st ? ' selected' : '') + '>' + esc(s) + '</option>').join('') + '<option value="__pending"' + (st === '__pending' ? ' selected' : '') + '>Awaiting approval</option></select>' +
      '<label class="check"><input type="checkbox" id="openOnly" data-n="' + n + '"' + (open ? ' checked' : '') + '> Open only</label>' + (e.due ? '<label class="check"><input type="checkbox" id="overdueOnly" data-n="' + n + '"' + (od ? ' checked' : '') + '> Overdue only</label>' : '') +
      ((q || st || open || od) ? '<button class="btn small ghost" data-act="clearFilters" data-n="' + n + '">Clear filters</button>' : '') + '</div>';
    if (!rows.length) return h + '<div class="panel empty">' + (total ? 'No records match these filters.' : 'No ' + esc(e.plural.toLowerCase()) + ' yet.' + (me() ? ' <a href="#/new/' + n + '">Create the first one</a>.' : '')) + '</div>';
    h += '<div class="tbl-wrap"><table class="grid"><thead><tr>' + cols.map(c => '<th aria-sort="' + (c.k === sort ? (dir === 'asc' ? 'ascending' : 'descending') : 'none') + '"><button class="sort" data-act="sort" data-n="' + n + '" data-k="' + c.k + '">' + esc(c.label) + (c.k === sort ? (dir === 'asc' ? ' ▲' : ' ▼') : '') + '</button></th>').join('') + '</tr></thead><tbody>' +
      rows.map(x => '<tr>' + cols.map(c => '<td>' + c.html(x) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>';
    return h;
  }

  /* ------------------------------------------------------------ forms */
  function refOptions(ref, cur, allowEmpty) {
    let items = store.list(ref);
    if (ref === 'people') items = items.filter(p => p.status === 'Active' || p.id === cur);
    return (allowEmpty !== false ? '<option value="">—</option>' : '') + items.map(x => '<option value="' + x.id + '"' + (x.id === cur ? ' selected' : '') + '>' + esc(ref === 'people' ? x.data.name : x.id + ' · ' + store.titleOf(ref, x)) + '</option>').join('');
  }
  function inputFor(fd, v, editable, id, extra) {
    const dis = editable && !fd.readonly ? '' : ' disabled';
    const req = fd.required ? ' aria-required="true"' : '';
    extra = extra || '';
    switch (fd.type) {
      case 'textarea': return '<textarea id="' + id + '"' + dis + req + extra + ' rows="3">' + esc(v) + '</textarea>';
      case 'select': return '<select id="' + id + '"' + dis + req + extra + '><option value="">—</option>' + fd.options.map(o => '<option' + (o === v ? ' selected' : '') + '>' + esc(o) + '</option>').join('') + '</select>';
      case 'ref': return '<select id="' + id + '"' + dis + req + extra + '>' + refOptions(fd.ref, v) + '</select>';
      case 'date': return '<input type="date" id="' + id + '" value="' + esc(v) + '"' + dis + req + extra + '>';
      case 'number': return '<input type="number" step="any" inputmode="decimal" id="' + id + '" value="' + esc(v) + '"' + (fd.min !== undefined ? ' min="' + fd.min + '"' : '') + (fd.max !== undefined ? ' max="' + fd.max + '"' : '') + dis + req + extra + '>';
      case 'email': return '<input type="email" id="' + id + '" value="' + esc(v) + '"' + dis + req + extra + ' autocomplete="off">';
      default: return '<input type="text" id="' + id + '" value="' + esc(v) + '"' + dis + req + extra + ' autocomplete="off">';
    }
  }
  function tableRow(fd, row, i, editable) {
    return '<tr>' + fd.columns.map(c => '<td>' + inputFor(c, row[c.k], editable, 'f_' + fd.k + '_' + i + '_' + c.k, ' data-col="' + c.k + '" aria-label="' + esc(c.label + ' row ' + (i + 1)) + '"') + (c.type === 'ref' && row[c.k] && !editable ? '' : '') + '</td>').join('') +
      (editable ? '<td><button type="button" class="btn small ghost" data-act="delrow" aria-label="Remove row ' + (i + 1) + '">Remove</button></td>' : '') + '</tr>';
  }
  function fieldHTML(n, fd, rec, editable) {
    const v = rec ? rec.data[fd.k] : fd.default;
    if (!editable) return roFieldHTML(fd, v);
    const id = 'f_' + fd.k;
    const wide = ['textarea', 'table', 'refs'].includes(fd.type) ? ' wide' : '';
    const lbl = '<span class="lbl">' + esc(fd.label) + (fd.required ? ' <span class="req" aria-hidden="true">*</span><span class="sr">(required)</span>' : '') + '</span>';
    if (fd.type === 'table') {
      const rows = (v || []).length ? v : (editable ? [{}] : []);
      return '<div class="fld' + wide + '" data-field="' + fd.k + '" data-type="table">' + lbl + '<div class="subtable"><table><thead><tr>' + fd.columns.map(c => '<th scope="col">' + esc(c.label) + '</th>').join('') + (editable ? '<th><span class="sr">Actions</span></th>' : '') + '</tr></thead><tbody>' + (rows.length ? rows.map((r, i) => tableRow(fd, r, i, editable)).join('') : '<tr><td colspan="' + fd.columns.length + '" class="muted">No rows</td></tr>') + '</tbody></table></div>' +
        (editable ? '<button type="button" class="btn small" data-act="addrow" data-k="' + fd.k + '" style="margin-top:6px">Add row</button>' : '') +
        (!editable ? tableRefLinks(fd, v) : '') + '</div>';
    }
    if (fd.type === 'refs') {
      const items = store.list(fd.ref);
      const sel = v || [];
      if (!editable) return '<div class="fld' + wide + '">' + lbl + '<div>' + fmtVal(fd, sel) + '</div></div>';
      return '<div class="fld' + wide + '" data-field="' + fd.k + '" data-type="refs">' + lbl + '<fieldset class="refs"><legend class="sr">' + esc(fd.label) + '</legend>' + (items.length ? items.map(x => '<label><input type="checkbox" value="' + x.id + '"' + (sel.includes(x.id) ? ' checked' : '') + '> <span>' + esc(x.id + ' · ' + store.titleOf(fd.ref, x)) + '</span></label>').join('') : '<span class="muted">No records available</span>') + '</fieldset></div>';
    }
    const link = fd.type === 'ref' && v && fd.ref !== 'people' ? '<div class="refline">' + recLink(fd.ref, v, false) + ' →</div>' : '';
    return '<div class="fld' + wide + '" data-field="' + fd.k + '" data-type="' + fd.type + '"><label for="' + id + '">' + lbl + '</label>' + inputFor(fd, v, editable, id) + link + (fd.readonly ? '<span class="hint">Set by the workflow</span>' : '') + '</div>';
  }
  function roFieldHTML(fd, v) {
    const wide = ['textarea', 'table', 'refs'].includes(fd.type) ? ' wide' : '';
    let body;
    if (fd.type === 'table') body = (v || []).length ? '<div class="subtable"><table><thead><tr>' + fd.columns.map(c => '<th scope="col">' + esc(c.label) + '</th>').join('') + '</tr></thead><tbody>' + v.map(r => '<tr>' + fd.columns.map(c => '<td>' + (c.k === 'status' ? badge(r[c.k] || '') : fmtVal(c, r[c.k])) + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>' : '<span class="muted">No rows</span>';
    else body = fmtVal(fd, v);
    return '<div class="fld ro' + wide + '"><span class="lbl">' + esc(fd.label) + '</span><div class="ro-val">' + body + '</div></div>';
  }
  function tableRefLinks(fd, v) {
    const refCols = fd.columns.filter(c => c.type === 'ref' && c.ref !== 'people');
    const links = []; (v || []).forEach(r => refCols.forEach(c => { if (r[c.k]) links.push(recLink(c.ref, r[c.k], true)); }));
    return links.length ? '<div class="refline">Linked: ' + links.join(' · ') + '</div>' : '';
  }
  function collect(form, n) {
    const out = {};
    $$('[data-field]', form).forEach(el => {
      const k = el.dataset.field, t = el.dataset.type, fd = E[n].fields.find(f => f.k === k);
      if (!fd || fd.readonly) return;
      if (t === 'table') {
        const rows = [];
        $$('tbody tr', el).forEach(tr => { const row = {}; let any = false; $$('[data-col]', tr).forEach(inp => { if (inp.disabled) return; row[inp.dataset.col] = inp.value; if (inp.value !== '') any = true; }); if (any) rows.push(row); });
        if ($$('[data-col]', el).some(i => !i.disabled) || !$$('[data-col]', el).length) out[k] = rows;
      } else if (t === 'refs') out[k] = $$('input[type=checkbox]:checked', el).map(i => i.value);
      else { const inp = $('#f_' + k, el); if (inp && !inp.disabled) out[k] = inp.value; }
    });
    return out;
  }
  function viewNew(n, q) {
    const e = E[n]; if (!e) return '<p>Unknown module.</p>';
    if (!me()) return '<p>Select who you are acting as before creating records.</p>';
    const pre = { data: {} };
    e.fields.forEach(fd => { if (fd.default !== undefined) pre.data[fd.k] = fd.default; });
    if (q) q.forEach((v, k) => { const fd = e.fields.find(f => f.k === k); if (fd) pre.data[k] = fd.type === 'refs' ? [v] : v; });
    if (e.fields.some(f => f.k === 'owner') && !pre.data.owner) pre.data.owner = me();
    const t = store.today();
    ['openedDate', 'receivedDate', 'detectedDate', 'assignedDate', 'inspDate', 'evalDate', 'calDate'].forEach(k => { if (e.fields.some(f => f.k === k) && !pre.data[k]) pre.data[k] = t; });
    if (n === 'reviews' && !pre.data.inputs) pre.data.inputs = Core.REVIEW_INPUT_TOPICS.map(topic => ({ topic }));
    const fields = e.fields.filter(f => !f.readonly);
    return '<div class="page-head"><div><h1>New ' + esc(e.label.toLowerCase()) + '</h1><div class="sub">Fields marked * are required. The record starts in status "' + esc(e.workflow.initial) + '".</div></div></div>' +
      '<form id="recForm" class="panel" data-n="' + n + '" novalidate><div class="form-grid">' + fields.map(fd => fieldHTML(n, fd, pre, true)).join('') + '</div><div class="form-err" role="alert"></div><div class="form-foot"><button class="btn primary" type="submit">Create</button><a class="btn" href="#/list/' + n + '">Cancel</a></div></form>';
  }

  /* ------------------------------------------------------------ record */
  function viewRecord(n, id, tab) {
    const e = E[n], rec = e && store.get(n, id);
    if (!rec) return '<div class="panel empty">Record ' + esc(id) + ' not found. <a href="#/list/' + esc(n) + '">Back to list</a></div>';
    const locked = store.isLocked(n, id), u = meRec();
    const editable = !locked && !!u;
    const der = store.derive(n, rec), due = store.dueOf(n, rec);
    const rel = store.related(n, id).filter(x => x.entity !== 'people');
    const trs = store.availableTransitions(n, id);
    const states = e.workflow.states.filter(s => !/Cancelled|Voided/.test(s) || s === rec.status);
    const ci = states.indexOf(rec.status);
    let h = '<div class="rec-head"><div><div class="meta"><a href="#/list/' + n + '">' + esc(e.plural) + '</a> / <span class="mono">' + esc(rec.id) + '</span> · clause ' + esc(e.clause) + '</div><h1>' + esc(store.titleOf(n, rec)) + '</h1><div class="meta">' + badge(rec.status) +
      (rec.pending ? badge('Awaiting approval: ' + rec.pending.transition, 'warn') : '') + (n === 'documents' ? badge('Rev ' + rec.data.revision, 'outline') : '') +
      (due && due.date ? '<span>' + esc(due.label) + ' due ' + esc(due.date) + '</span>' + (due.date < store.today() ? badge('Overdue', 'crit') : '') : '') +
      Object.keys(der).filter(k => k !== 'series' && der[k] !== '' && der[k] !== undefined).map(k => '<span>' + esc(k.replace(/([A-Z])/g, ' $1').toLowerCase()) + ': <strong>' + esc(der[k]) + '</strong></span>').join('') +
      (locked && !rec.pending ? badge('Locked', 'outline') : '') + '</div></div><div class="toolbar no-print" style="margin:0"><button class="btn" data-act="print">Print</button></div></div>';
    if (states.length > 2) h += '<nav class="stepper" aria-label="Workflow progress"><ol>' + states.map((s, i) => '<li class="' + (i < ci ? 'done' : i === ci ? 'current' : '') + '"' + (i === ci ? ' aria-current="step"' : '') + '>' + esc(s) + '</li>').join('') + '</ol></nav>';
    if (rec.pending) {
      const p = rec.pending, can = canDecide({ pending: p });
      h += '<div class="banner warn" role="status"><strong>' + esc(person(p.requestedBy)) + '</strong> requested "' + esc(p.transition) + '" on ' + fmtTs(p.requestedAt) + (p.comment ? ' — “' + esc(p.comment) + '”' : '') + '. The record is locked until an approver decides.' +
        '<div class="actions-bar" style="margin:8px 0 0">' + (can ? '<button class="btn primary" data-act="approve" data-n="' + n + '" data-id="' + id + '">Approve</button><button class="btn danger" data-act="reject" data-n="' + n + '" data-id="' + id + '">Reject</button>' : '') +
        (u && p.requestedBy === u.id ? '<button class="btn" data-act="withdraw" data-n="' + n + '" data-id="' + id + '">Withdraw request</button>' : '') +
        (!can && !(u && p.requestedBy === u.id) ? '<span class="muted">' + (u ? (u.data.canApprove !== 'Yes' ? 'You do not have approval authority.' : '') : 'Select an approver to decide.') + '</span>' : '') + '</div></div>';
    } else if (trs.length && u) {
      h += '<div class="actions-bar" role="group" aria-label="Workflow actions">' + trs.map((t, i) => '<div class="act-group"><button class="btn' + (i === 0 && !t.blocked ? ' primary' : '') + '" data-act="go" data-n="' + n + '" data-id="' + id + '" data-to="' + esc(t.to) + '"' + (t.blocked ? ' disabled aria-describedby="blk' + i + '"' : '') + '>' + esc(t.label) + (t.approval ? ' (needs approval)' : '') + '</button>' + (t.blocked ? '<span class="blocked" id="blk' + i + '">' + esc(t.blocked) + '</span>' : '') + '</div>').join('') + '</div>';
    }
    const tabs = [['details', 'Details'], ['related', 'Related (' + rel.length + ')'], ['evidence', 'Evidence (' + rec.attachments.length + ')'], ['history', 'History (' + rec.history.length + ')'], ['approvals', 'Approvals (' + (rec.approvals || []).length + ')']];
    if (n === 'documents') tabs.splice(4, 0, ['revisions', 'Revisions (' + (rec.revisions || []).length + ')']);
    h += '<nav class="tabs" aria-label="Record sections">' + tabs.map(([k, l]) => '<a href="#/rec/' + n + '/' + id + '/' + k + '"' + (k === tab ? ' aria-current="page"' : '') + '>' + esc(l) + '</a>').join('') + '</nav>';
    if (tab === 'details') {
      h += '<form id="recForm" class="panel" data-n="' + n + '" data-id="' + id + '" novalidate><div class="form-grid">' + e.fields.map(fd => fieldHTML(n, fd, rec, editable)).join('') + '</div>' +
        (rec.data.kpiSnapshot ? '<h3>Performance snapshot captured when the meeting was recorded</h3>' + snapshotTable(rec.data.kpiSnapshot) : '') +
        '<div class="form-err" role="alert"></div>' + (editable ? '<div class="form-foot"><button class="btn primary" type="submit" id="saveBtn" disabled>Save changes</button><button type="button" class="btn" data-act="discard" id="discardBtn" disabled>Discard</button><span class="muted" id="dirtyNote"></span></div>' : '<p class="muted" style="margin:12px 0 0">' + (u ? (rec.pending ? 'Editing is disabled while an approval is pending.' : 'This record is ' + esc(rec.status) + ' and locked against editing.' + (e.workflow.transitions.some(t => t.from.includes(rec.status) && t.to === 'Draft') ? ' Use "' + esc(e.workflow.transitions.find(t => t.from.includes(rec.status) && t.to === 'Draft').label) + '" to change it.' : '')) : 'Select a user to edit.') + '</p>') + '</form>';
      h += quickCreate(n, id);
      h += '<section class="panel no-print"><h2>Comments</h2>' + rec.history.filter(x => x.action === 'comment').map(c => '<p style="margin:0 0 8px"><strong>' + esc(person(c.user)) + '</strong> <span class="muted">' + fmtTs(c.ts) + '</span><br>' + esc(c.comment) + '</p>').join('') + (u ? '<form id="commentForm" data-n="' + n + '" data-id="' + id + '"><label class="sr" for="cmt">Add a comment</label><textarea id="cmt" placeholder="Add a comment (recorded in the history)"></textarea><button class="btn" type="submit" style="margin-top:6px">Add comment</button></form>' : '') + '</section>';
    } else if (tab === 'related') h += viewRelated(n, id, rel);
    else if (tab === 'evidence') h += viewEvidence(n, rec, u);
    else if (tab === 'history') h += viewHistory(n, rec);
    else if (tab === 'approvals') h += '<div class="tbl-wrap">' + ((rec.approvals || []).length ? '<table class="grid"><thead><tr><th>Decision</th><th>Step</th><th>Requested by</th><th>Decided by</th><th>When</th><th>Comment</th><th>Signature hash</th></tr></thead><tbody>' + rec.approvals.map(a => '<tr><td>' + badge(a.decision, a.decision === 'Approved' ? 'good' : 'crit') + '</td><td>' + esc(a.transition) + '</td><td>' + esc(person(a.requestedBy)) + '</td><td>' + esc(a.byName) + '</td><td class="nowrap">' + fmtTs(a.at) + '</td><td>' + esc(a.comment) + '</td><td class="mono" title="' + esc(a.signatureHash) + '">' + esc(a.signatureHash.slice(0, 12)) + '…</td></tr>').join('') + '</tbody></table>' : '<p class="empty">No approval decisions recorded.</p>') + '</div>';
    else if (tab === 'revisions') h += '<div class="tbl-wrap">' + ((rec.revisions || []).length ? '<table class="grid"><thead><tr><th>Revision</th><th>Effective</th><th>Approved by</th><th>Change summary</th><th>Content hash</th></tr></thead><tbody>' + rec.revisions.slice().reverse().map(v => '<tr><td>' + esc(v.revision) + '</td><td>' + esc(v.effectiveDate) + '</td><td>' + esc(person(v.approvedBy)) + '</td><td>' + esc(v.changeSummary) + '</td><td class="mono">' + esc(v.contentHash.slice(0, 12)) + '…</td></tr>').join('') + '</tbody></table>' : '<p class="empty">No released revisions yet.</p>') + '</div>' +
      '<section class="panel" style="margin-top:12px"><h2>Training on this document</h2>' + trainingForDoc(id) + '</section>';
    return h;
  }
  function snapshotTable(s) { let o; try { o = JSON.parse(s); } catch (e) { return ''; } return '<div class="tbl-wrap"><table class="grid"><tbody>' + Object.keys(o).map(k => '<tr><td>' + esc(k.replace(/([A-Z])/g, ' $1').replace(/^./, c => c.toUpperCase())) + '</td><td class="num">' + esc(o[k] === null ? '—' : o[k]) + '</td></tr>').join('') + '</tbody></table></div>'; }
  function trainingForDoc(id) {
    const rows = store.list('training').filter(t => t.data.document === id);
    return rows.length ? '<div class="tbl-wrap"><table class="grid"><thead><tr><th>ID</th><th>Employee</th><th>Status</th><th>Revision trained</th><th>Currency</th></tr></thead><tbody>' + rows.map(t => '<tr><td>' + recLink('training', t.id) + '</td><td>' + esc(person(t.data.person)) + '</td><td>' + badge(t.status) + '</td><td>' + esc(t.data.trainedRevision || '—') + '</td><td>' + badge(store.derive('training', t).currency) + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="empty">No training records reference this document.</p>';
  }
  function quickCreate(n, id) {
    if (!me()) return '';
    const links = {
      complaints: [['ncrs', 'complaint', 'Raise NCR from this complaint'], ['capas', null, 'Raise CAPA', { source: 'Customer complaint' }]],
      ncrs: [['capas', null, 'Raise CAPA', { source: 'Nonconformance' }]],
      inspections: [['ncrs', 'inspection', 'Raise NCR for rejected pieces']],
      calibrations: [['ncrs', 'calibration', 'Raise NCR for out-of-tolerance result']],
      suppliers: [['supplierEvals', 'supplier', 'New evaluation'], ['ncrs', 'supplier', 'Raise supplier NCR']],
      equipment: [['calibrations', 'equipment', 'Record calibration']],
      documents: [['training', 'document', 'Assign training']],
      inspPlans: [['inspections', 'plan', 'Record inspection']],
      risks: [['capas', 'risks', 'Raise CAPA linked to this risk', { source: 'Risk review' }]],
      audits: [['capas', null, 'Raise CAPA for a finding', { source: 'Internal audit' }]],
      reviews: [['capas', null, 'Raise CAPA from review', { source: 'Management review' }]],
      people: [['training', 'person', 'Assign training']]
    }[n];
    if (!links) return '';
    return '<div class="toolbar no-print">' + links.map(([target, field, label, extra]) => { const q = new URLSearchParams(extra || {}); if (field) q.set(field, id); return '<a class="btn small" href="#/new/' + target + '?' + q.toString() + '">' + esc(label) + '</a>'; }).join('') + (['complaints', 'ncrs', 'audits', 'reviews'].includes(n) ? '<span class="muted" style="font-size:12px">After creating a CAPA, link it back from this record’s CAPA field.</span>' : '') + '</div>';
  }
  function viewRelated(n, id, rel) {
    const chain = store.traceChain(n, id, 4);
    const direct = rel.length ? '<div class="tbl-wrap"><table class="grid"><thead><tr><th>Direction</th><th>Record</th><th>Type</th><th>Via field</th><th>Status</th></tr></thead><tbody>' + rel.map(x => '<tr><td>' + (x.direction === 'out' ? 'Links to' : 'Linked from') + '</td><td>' + recLink(x.entity, x.record.id, true) + '</td><td>' + esc(E[x.entity].label) + '</td><td>' + esc(x.via) + '</td><td>' + badge(x.record.status) + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="empty">No related records.</p>';
    const tr = chain.length ? '<ul class="trace">' + chain.map(c => '<li style="padding-left:' + ((c.depth - 1) * 20) + 'px">' + (c.depth > 1 ? '<span class="muted">↳ </span>' : '') + recLink(c.entity, c.id, true) + ' <span class="muted">(' + esc(E[c.entity].label) + ', via ' + esc(c.via) + ' from ' + esc(c.from) + ')</span> ' + badge(store._raw(c.entity, c.id).status) + '</li>').join('') + '</ul>' : '<p class="empty">No trace.</p>';
    return '<section class="panel"><h2>Direct relationships</h2>' + direct + '</section><section class="panel"><h2>Traceability chain (up to 4 levels)</h2>' + tr + '</section>';
  }
  function viewEvidence(n, rec, u) {
    const locked = store.isLocked(n, rec.id);
    return '<section class="panel"><h2>Evidence attachments</h2><p class="muted" style="margin-top:0;font-size:12px">Files are stored inside this system’s database (max ' + (Core.MAX_ATTACHMENT_BYTES / 1048576) + ' MB each) with a SHA-256 checksum verified by the integrity check. Attachments can be added at any stage, including after closure.</p>' +
      (rec.attachments.length ? '<div class="tbl-wrap"><table class="grid"><thead><tr><th>File</th><th>Description</th><th class="num">Size</th><th>Added by</th><th>When</th><th>SHA-256</th><th><span class="sr">Actions</span></th></tr></thead><tbody>' + rec.attachments.map(a => '<tr><td>' + esc(a.name) + '</td><td>' + esc(a.description) + '</td><td class="num">' + (a.size > 1024 ? (a.size / 1024).toFixed(1) + ' KB' : a.size + ' B') + '</td><td>' + esc(person(a.addedBy)) + '</td><td class="nowrap">' + fmtTs(a.addedAt) + '</td><td class="mono" title="' + esc(a.sha256) + '">' + esc(a.sha256.slice(0, 12)) + '…</td><td class="nowrap"><button class="btn small" data-act="dl-att" data-n="' + n + '" data-id="' + rec.id + '" data-att="' + a.id + '">Download</button>' + (!locked && u ? ' <button class="btn small ghost" data-act="rm-att" data-n="' + n + '" data-id="' + rec.id + '" data-att="' + a.id + '">Remove</button>' : '') + '</td></tr>').join('') + '</tbody></table></div>' : '<p class="empty">No evidence attached.</p>') +
      (u ? '<form id="attForm" data-n="' + n + '" data-id="' + rec.id + '" style="margin-top:12px"><div class="form-grid"><label class="fld"><span class="lbl">Files</span><input type="file" id="attFile" multiple></label><label class="fld"><span class="lbl">Description (optional)</span><input type="text" id="attDesc" autocomplete="off"></label></div><button class="btn" type="submit" style="margin-top:8px">Attach</button></form>' : '') + '</section>';
  }
  function viewHistory(n, rec) {
    const v = store.verify(n, rec.id);
    const label = k => { const fd = E[n].fields.find(f => f.k === k); return fd ? fd.label : k === 'status' ? 'Status' : k; };
    const short = x => { const s = x === null || x === undefined ? '∅' : typeof x === 'object' ? (Array.isArray(x) ? x.length + ' item(s)' : JSON.stringify(x)) : String(x); return s.length > 90 ? s.slice(0, 90) + '…' : s; };
    return '<div class="banner ' + (v.ok ? 'info' : 'crit') + '">' + (v.ok ? '<strong>History chain verified.</strong> All ' + rec.history.length + ' entries link correctly and the current content matches the last recorded change.' : '<strong>Verification failed:</strong><ul class="err-list">' + v.errors.map(x => '<li>' + esc(x.msg) + '</li>').join('') + '</ul>') + '</div>' +
      '<div class="tbl-wrap"><table class="grid"><thead><tr><th class="num">#</th><th>When</th><th>User</th><th>Action</th><th>Changes</th><th>Comment</th><th>Hash</th></tr></thead><tbody>' + rec.history.slice().reverse().map(x => '<tr><td class="num">' + x.seq + '</td><td class="nowrap">' + fmtTs(x.ts) + '</td><td>' + esc(person(x.user)) + '</td><td>' + esc(x.action.replace(/-/g, ' ')) + (x.transition ? '<br><span class="muted">' + esc(x.transition) + '</span>' : '') + '</td><td>' + (x.changes || []).map(c => '<div><strong>' + esc(label(c.field)) + '</strong>: ' + (x.action === 'created' ? '' : '<span class="muted">' + esc(short(c.from)) + '</span> → ') + esc(short(c.to)) + '</div>').join('') + (x.attachment ? '<div>File: ' + esc(x.attachment.name) + '</div>' : '') + '</td><td>' + esc(x.comment) + '</td><td class="mono" title="' + esc(x.hash) + '">' + esc(x.hash.slice(0, 10)) + '…</td></tr>').join('') + '</tbody></table></div>';
  }

  /* ------------------------------------------------------------ search */
  function viewSearch(q) {
    const ql = q.toLowerCase().trim(); const hits = [];
    if (ql) Object.keys(E).forEach(n => store.list(n).forEach(r => { const t = store.titleOf(n, r); if ((r.id + ' ' + t + ' ' + JSON.stringify(r.data)).toLowerCase().includes(ql)) hits.push([n, r, t]); }));
    return '<div class="page-head"><div><h1>Search</h1><div class="sub">' + hits.length + ' result(s) for “' + esc(q) + '”</div></div></div>' + (hits.length ? '<div class="tbl-wrap"><table class="grid"><thead><tr><th>ID</th><th>Title</th><th>Type</th><th>Status</th></tr></thead><tbody>' + hits.slice(0, 300).map(([n, r, t]) => '<tr><td>' + recLink(n, r.id) + '</td><td>' + esc(n === 'people' ? r.data.name : t) + '</td><td>' + esc(E[n].label) + '</td><td>' + badge(r.status) + '</td></tr>').join('') + '</tbody></table></div>' : '<div class="panel empty">No matches.</div>');
  }

  /* ------------------------------------------------------------ reports */
  const REPORTS = [['capa', 'Corrective action register'], ['due', 'Overdue and upcoming'], ['trace', 'Traceability'], ['training', 'Training matrix'], ['calibration', 'Calibration status'], ['suppliers', 'Supplier performance'], ['audits', 'Audit programme'], ['activity', 'Recent activity']];
  function reportTable(head, rows, id) { return rows.length ? '<div class="tbl-wrap"><table class="grid" id="' + id + '"><thead><tr>' + head.map(x => '<th>' + esc(x) + '</th>').join('') + '</tr></thead><tbody>' + rows.map(r => '<tr>' + r.map(c => '<td>' + c + '</td>').join('') + '</tr>').join('') + '</tbody></table></div>' : '<p class="empty">No data.</p>'; }
  function viewReports(which, q) {
    let body = '';
    const t = store.today();
    if (which === 'capa') {
      body = reportTable(['ID', 'Title', 'Source', 'Linked from', 'Priority', 'Owner', 'Stage', 'Opened', 'Target', 'Days open', 'Result'], store.list('capas').map(r => {
        const src = store.related('capas', r.id).filter(x => x.direction === 'in' && x.entity !== 'people').map(x => recLink(x.entity, x.record.id)).join(' ');
        const closed = r.history.slice().reverse().find(hh => hh.toStatus === 'Closed');
        const end = closed ? closed.ts.slice(0, 10) : t;
        const late = !['Closed', 'Cancelled'].includes(r.status) && r.data.dueDate < t;
        return [recLink('capas', r.id), esc(r.data.title), esc(r.data.source), src || '—', esc(r.data.priority), esc(person(r.data.owner)), badge(r.status) + (r.pending ? ' ' + badge('pending', 'warn') : ''), esc(r.data.openedDate), esc(r.data.dueDate) + (late ? ' ' + badge('Overdue', 'crit') : ''), '<span class="num">' + Core.utils.daysBetween(r.data.openedDate, end) + '</span>', esc(r.data.effectivenessResult || '')];
      }), 'rpt');
    } else if (which === 'due') {
      body = reportTable(['ID', 'Title', 'Type', 'Due for', 'Date', 'Days', 'Owner'], store.dueItems(30).map(d => [recLink(d.entity, d.id), esc(d.title), esc(E[d.entity].label), esc(d.label), esc(d.date), d.overdue ? badge(-d.daysLeft + ' overdue', 'crit') : esc(d.daysLeft), esc(person(d.owner))]), 'rpt');
    } else if (which === 'trace') {
      const sel = q.get('id') || (store.list('capas')[0] || {}).id;
      body = '<div class="toolbar"><label for="traceSel">Corrective action</label><select id="traceSel" style="max-width:420px">' + store.list('capas').map(c => '<option value="' + c.id + '"' + (c.id === sel ? ' selected' : '') + '>' + esc(c.id + ' · ' + c.data.title) + '</option>').join('') + '</select></div>';
      if (sel) {
        const c = store._raw('capas', sel);
        body += '<section class="panel"><h2>' + esc(c.id + ' ' + c.data.title) + '</h2><dl class="kv"><dt>Status</dt><dd>' + badge(c.status) + '</dd><dt>Problem</dt><dd>' + esc(c.data.problem) + '</dd><dt>Containment</dt><dd>' + esc(c.data.containment || '—') + '</dd><dt>Root cause</dt><dd>' + esc(c.data.rootCause || '—') + '</dd><dt>Verification</dt><dd>' + esc(c.data.verification || '—') + '</dd><dt>Effectiveness</dt><dd>' + esc((c.data.effectivenessResult || '—') + (c.data.effectivenessEvidence ? ': ' + c.data.effectivenessEvidence : '')) + '</dd></dl>' +
          '<h3>Actions</h3>' + reportTable(['Action', 'Owner', 'Due', 'Status', 'Completed'], (c.data.actions || []).map(a => [esc(a.action), esc(person(a.owner)), esc(a.due), badge(a.status || 'Open'), esc(a.completedOn || '')]), 'rpt-a') +
          '<h3>Linked records</h3>' + viewRelated('capas', sel, store.related('capas', sel).filter(x => x.entity !== 'people')).replace(/<section class="panel">/g, '<div>').replace(/<\/section>/g, '</div>') +
          '<h3>Lifecycle</h3>' + reportTable(['When', 'User', 'Step', 'Comment'], c.history.filter(hh => hh.toStatus || /approval/.test(hh.action)).map(hh => [fmtTs(hh.ts), esc(person(hh.user)), esc((hh.transition || '') + (hh.toStatus ? ' → ' + hh.toStatus : ' (' + hh.action.replace(/-/g, ' ') + ')')), esc(hh.comment)]), 'rpt-l') + '</section>';
      }
    } else if (which === 'training') {
      const docs = store.list('documents').filter(d => d.status === 'Effective' && store.list('training').some(tr => tr.data.document === d.id));
      const ppl = store.list('people').filter(p => p.status === 'Active' && store.list('training').some(tr => tr.data.person === p.id && docs.some(d => d.id === tr.data.document)));
      body = reportTable(['Employee'].concat(docs.map(d => d.data.docNumber + ' rev ' + d.data.revision)), ppl.map(p => [esc(p.data.name)].concat(docs.map(d => {
        const recs = store.list('training').filter(tr => tr.data.person === p.id && tr.data.document === d.id && tr.status !== 'Cancelled');
        if (!recs.length) return '<span class="muted">—</span>';
        if (recs.some(tr => ['Completed', 'Verified'].includes(tr.status) && tr.data.trainedRevision === d.data.revision)) return badge('Current', 'good');
        if (recs.some(tr => tr.status === 'Assigned')) { const a = recs.find(tr => tr.status === 'Assigned'); return badge(a.data.dueDate < t ? 'Overdue' : 'Assigned', a.data.dueDate < t ? 'crit' : 'info'); }
        return badge('Retrain', 'crit');
      }))), 'rpt') + '<p class="muted" style="font-size:12px">Columns are effective documents that have training records. "Retrain" means the person was trained on an earlier revision.</p>';
    } else if (which === 'calibration') {
      body = reportTable(['Asset', 'Description', 'Location', 'Interval (days)', 'Last calibrated', 'Next due', 'Status', 'Equipment status'], store.list('equipment').map(r => { const d = store.derive('equipment', r); return [recLink('equipment', r.id) + ' ' + esc(r.data.assetTag), esc(r.data.name), esc(r.data.location), esc(r.data.intervalDays), esc(d.lastCal), esc(d.nextDue), badge(d.calStatus), badge(r.status)]; }), 'rpt');
    } else if (which === 'suppliers') {
      body = reportTable(['Supplier', 'Category', 'Criticality', 'Status', 'Evaluations', 'Latest score', 'Grade', 'NCRs', 'Next evaluation'], store.list('suppliers').map(s => { const d = store.derive('suppliers', s); const ev = store.list('supplierEvals').filter(e => e.data.supplier === s.id && e.status === 'Completed'); return [recLink('suppliers', s.id) + ' ' + esc(s.data.name), esc(s.data.category), esc(s.data.criticality), badge(s.status), esc(ev.map(e => store.derive('supplierEvals', e).overall).join(' → ')), esc(d.lastScore), esc(d.lastGrade), esc(store.list('ncrs').filter(x => x.data.supplier === s.id).length), esc(s.data.nextEvaluation || '')]; }), 'rpt');
    } else if (which === 'audits') {
      body = reportTable(['ID', 'Audit', 'Type', 'Clauses', 'Lead auditor', 'Planned', 'Actual', 'Status', 'Findings', 'CAPAs'], store.list('audits').map(a => [recLink('audits', a.id), esc(a.data.title), esc(a.data.auditType), esc(a.data.clauses), esc(person(a.data.leadAuditor)), esc(a.data.plannedDate) + (a.status === 'Planned' && a.data.plannedDate < t ? ' ' + badge('Overdue', 'crit') : ''), esc(a.data.actualDate || ''), badge(a.status), esc((a.data.findings || []).map(f => f.type).join(', ')), (a.data.findings || []).filter(f => f.capa).map(f => recLink('capas', f.capa)).join(' ')]), 'rpt');
    } else if (which === 'activity') {
      const ev = []; Object.keys(E).forEach(n => store.list(n).forEach(r => r.history.forEach(hh => ev.push([hh.ts, n, r.id, hh]))));
      ev.sort((a, b) => (a[0] < b[0] ? 1 : -1));
      body = reportTable(['When', 'Record', 'User', 'Action', 'Comment'], ev.slice(0, 200).map(([ts, n, id, hh]) => [fmtTs(ts), recLink(n, id, true), esc(person(hh.user)), esc(hh.action.replace(/-/g, ' ') + (hh.transition ? ': ' + hh.transition : '')), esc(hh.comment)]), 'rpt') + '<p class="muted" style="font-size:12px">Latest 200 events. Export the full audit trail from the Data page.</p>';
    }
    return '<div class="page-head"><div><h1>Reports</h1><div class="sub">' + esc(store.data.meta.company) + ' · generated ' + esc(new Date().toISOString().slice(0, 16).replace('T', ' ')) + '</div></div><div class="toolbar no-print" style="margin:0"><button class="btn" data-act="rpt-csv" data-r="' + which + '">Export table as CSV</button><button class="btn" data-act="print">Print / save as PDF</button></div></div>' +
      '<nav class="tabs" aria-label="Report">' + REPORTS.map(([k, l]) => '<a href="#/reports/' + k + '"' + (k === which ? ' aria-current="page"' : '') + '>' + esc(l) + '</a>').join('') + '</nav><h2 style="font-size:16px;margin:0 0 8px">' + esc((REPORTS.find(x => x[0] === which) || ['', ''])[1]) + '</h2>' + body;
  }
  function tableToCSV(tbl) {
    const cell = s => { s = s.replace(/\s+/g, ' ').trim(); if (/^[=+\-@]/.test(s)) s = "'" + s; return /[",\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; };
    return '﻿' + $$('tr', tbl).map(tr => $$('th,td', tr).map(c => cell(c.textContent)).join(',')).join('\r\n') + '\r\n';
  }

  /* ------------------------------------------------------------ data & admin */
  function viewData() {
    const u = meRec(), admin = u && u.data.isAdmin === 'Yes';
    const ic = window.QMSApp.lastIntegrity;
    const clauseRows = Object.keys(E).map(n => [esc(E[n].clause), '<a href="#/list/' + n + '">' + esc(E[n].plural) + '</a>', esc(E[n].group), store.list(n).length]);
    let counts = 0; Object.keys(E).forEach(n => (counts += store.list(n).length));
    return '<div class="page-head"><div><h1>Data, backup &amp; integrity</h1><div class="sub">' + counts + ' records · storage: ' + esc({ indexeddb: 'browser IndexedDB (persistent)', localstorage: 'browser localStorage (persistent, ~5 MB limit)', memory: 'memory only (not persistent)' }[Storage.mode]) + ' · schema v' + Core.SCHEMA_VERSION + '</div></div></div>' +
      '<div class="cols"><section class="panel"><h2>Integrity check</h2><p style="margin-top:0">Verifies every record’s hash-chained history, that content matches the last recorded change, all cross-references resolve, IDs and statuses are valid, unique fields are unique, and evidence files match their checksums.</p><button class="btn primary" data-act="integrity">Run integrity check</button>' +
      (ic ? '<div class="banner ' + (ic.ok ? 'info' : 'crit') + '" style="margin-top:10px">' + (ic.ok ? '<strong>Passed.</strong> ' + ic.count + ' records verified at ' + fmtTs(ic.checkedAt) + '.' : '<strong>' + ic.errors.length + ' problem(s)</strong> in ' + ic.count + ' records:<ul class="err-list">' + ic.errors.slice(0, 50).map(x => '<li><span class="mono">' + esc(x.where) + '</span> — ' + esc(x.msg) + '</li>').join('') + '</ul>') + '</div>' : '') + '</section>' +
      '<section class="panel"><h2>Backup</h2><p style="margin-top:0">A backup is one JSON file containing all records, histories, approvals and evidence, with a SHA-256 checksum. Keep backups off this computer.</p><div class="toolbar"><button class="btn primary" data-act="backup">Download backup</button></div>' +
      '<h3>Restore</h3><p style="margin-top:0;font-size:13px">The file is checked (format, checksum, schema, full integrity) before anything is replaced. The current database is kept as an undo point.</p>' + (admin ? '<label class="sr" for="restoreFile">Backup file</label><input type="file" id="restoreFile" accept=".json,application/json">' + (hasUndo ? '<div style="margin-top:8px"><button class="btn" data-act="undoRestore">Undo last restore</button></div>' : '') : '<p class="muted">Restore requires a user with system administrator rights.</p>') + '</section>' +
      '<section class="panel"><h2>Exports</h2><p style="margin-top:0;font-size:13px">CSV files open in any spreadsheet. Cells beginning with = + - @ are prefixed with an apostrophe to prevent formula execution.</p><div class="toolbar"><button class="btn" data-act="auditcsv">Full audit trail (CSV)</button><button class="btn" data-act="allcsv">All modules (one CSV each)</button></div><div class="toolbar">' + Object.keys(E).map(n => '<button class="btn small" data-act="csv" data-n="' + n + '">' + esc(E[n].plural) + '</button>').join('') + '</div></section>' +
      '<section class="panel"><h2>Organization and database</h2>' + (admin ? '<form id="companyForm"><label class="fld"><span class="lbl">Organization name</span><input type="text" id="companyName" value="' + esc(store.data.meta.company) + '" autocomplete="organization"></label><button class="btn" type="submit" style="margin-top:6px">Save name</button></form><h3>Reset</h3><div class="toolbar"><button class="btn danger" data-act="loadDemo">Replace with demonstration data</button><button class="btn danger" data-act="startEmpty">Start a new empty system</button></div><p class="muted" style="font-size:12px">Both options replace the current database. Download a backup first.</p>' : '<p class="muted">Administration requires a system administrator.</p>') + '</section></div>' +
      '<section class="panel" style="margin-top:12px"><h2>Module map to ISO 9001:2015 clauses</h2><p style="margin-top:0;font-size:13px">Clause numbers indicate where each module supports the standard’s requirements. Consult your licensed copy of ISO 9001:2015 for the requirement text.</p>' + reportTable(['Clause', 'Module', 'Group', 'Records'], clauseRows, 'clauses') + '</section>' +
      '<section class="panel"><h2>Important notice</h2><p style="margin:0">This software supports a quality management system aligned with ISO 9001:2015 principles. Using it does not by itself make an organization conform to the standard, and it does not guarantee certification; certification is decided by an accredited certification body after auditing how the organization actually operates. User selection in this offline app is not authentication: anyone with access to this browser profile can act as any user. See the documentation for controls appropriate to your context.</p></section>' +
      '<section class="panel"><h2>System event log</h2>' + reportTable(['When', 'User', 'Event', 'Detail'], store.data.meta.events.slice().reverse().slice(0, 50).map(x => [fmtTs(x.ts), esc(person(x.user)), esc(x.event), esc(x.detail)]), 'events') + '</section>';
  }
  function viewSetup() {
    $('#side').innerHTML = ''; $('#userSel').innerHTML = '';
    $('#brand').textContent = 'Offline QMS';
    $('#main').innerHTML = '<div class="setup panel"><h1 style="font-size:20px;margin-top:0">Set up your quality management system</h1><p>Everything runs in this browser with no network connection. Data is stored locally; download backups regularly.</p>' +
      '<h2>Explore with demonstration data</h2><p style="margin-top:0">A fictional machining company with 122 linked records, including a corrective action traced from customer complaint through to verified effectiveness.</p><button class="btn primary" data-act="setupDemo">Load demonstration data</button>' +
      '<h2 style="margin-top:24px">Or start empty</h2><form id="setupForm" novalidate><div class="form-grid"><label class="fld"><span class="lbl">Organization name *</span><input type="text" id="s_org" required autocomplete="organization"></label><label class="fld"><span class="lbl">Your name *</span><input type="text" id="s_name" required autocomplete="name"></label><label class="fld"><span class="lbl">Email</span><input type="email" id="s_email" autocomplete="email"></label></div><div class="form-err" role="alert"></div><button class="btn" type="submit" style="margin-top:8px">Create empty system</button></form>' +
      '<h2 style="margin-top:24px">Or restore a backup</h2><input type="file" id="setupRestore" accept=".json,application/json"></div>';
  }

  /* ------------------------------------------------------------ actions */
  async function doTransition(n, id, to) {
    if (dirty) { const form = $('#recForm'); if (!(await saveForm(form, true))) return; }
    const t = store.availableTransitions(n, id).find(x => x.to === to); if (!t) return;
    if (t.blocked) { toast(t.blocked, true); return; }
    let comment = '';
    if (t.comment || t.approval) {
      const v = await ask({ title: t.label + (t.approval ? ' — request approval' : ''), body: t.approval ? '<p style="margin:0">This step needs a decision from a different user with approval authority. The record is locked until then.</p>' : '', fields: [{ name: 'c', label: t.comment ? 'Comment (required)' : 'Note to approver (optional)', type: 'textarea', required: t.comment }], ok: t.approval ? 'Request approval' : t.label });
      if (!v) return; comment = v.c;
    }
    try { const r = store.transition(n, id, to, me(), comment); toast(r.pendingApproval ? 'Approval requested.' : id + ' moved to ' + r.record.status + '.'); render(); } catch (e) { fail(e); }
  }
  async function saveForm(form, quiet) {
    const n = form.dataset.n, id = form.dataset.id, errBox = $('.form-err', form);
    errBox.innerHTML = '';
    const vals = collect(form, n);
    try {
      if (id) { const r = store.update(n, id, vals, me()); dirty = false; if (!quiet) toast(r.changes.length ? 'Saved ' + r.changes.length + ' change(s).' : 'No changes.'); if (quiet) return true; }
      else { const r = store.create(n, vals, me()); dirty = false; toast(r.id + ' created.'); location.hash = '#/rec/' + n + '/' + r.id; return true; }
      render(); return true;
    } catch (e) {
      errBox.innerHTML = '<div class="banner crit"><strong>' + esc(e.message) + '</strong>' + (e.details && e.details.length > 1 ? '<ul class="err-list">' + e.details.map(x => '<li>' + esc(x) + '</li>').join('') + '</ul>' : '') + '</div>';
      errBox.scrollIntoView({ block: 'nearest' });
      return false;
    }
  }
  const readFile = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsDataURL(f); });
  const readText = f => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = () => rej(r.error); r.readAsText(f); });
  async function restoreFrom(file, fromSetup) {
    let txt; try { txt = await readText(file); } catch (e) { return fail(e); }
    const tmp = store || Core.createStore();
    const rep = tmp.inspectBackup(txt);
    if (!rep.ok) { await ask({ title: 'Backup rejected', body: '<p>The file was not restored. Nothing has changed.</p><ul class="err-list">' + rep.problems.map(p => '<li>' + esc(p) + '</li>').join('') + '</ul>', ok: 'Close', noCancel: true }); return; }
    const ok = await ask({ title: 'Restore this backup?', body: '<dl class="kv"><dt>Exported</dt><dd>' + fmtTs(rep.exportedAt) + '</dd><dt>Records</dt><dd>' + rep.recordCount + '</dd><dt>Checks</dt><dd>Format, checksum, schema and integrity passed</dd></dl><p>The current database will be replaced. ' + (fromSetup ? '' : 'You can undo this from the Data page until the next restore.') + '</p>', ok: 'Restore', danger: true });
    if (!ok) return;
    try {
      if (store && !fromSetup) { await Storage.set('pre-restore', store.serialize()); hasUndo = true; }
      const s = store && !fromSetup ? store : Core.createStore();
      const res = s.restore(txt, me() || '');
      if (s !== store) attachStore(s);
      await Storage.set(KEY, store.serialize());
      window.QMSApp.lastIntegrity = store.integrityCheck(); startupIntegrity = null;
      toast('Restored ' + res.recordCount + ' records.');
      location.hash = '#/data'; render();
    } catch (e) { fail(e); }
  }
  async function replaceDb(fn, label) {
    const ok = await ask({ title: label, body: '<p>This replaces every record in the current database. Download a backup first if you need it.</p>', fields: [{ name: 'c', label: 'Type REPLACE to confirm', required: true, match: 'REPLACE' }], ok: label, danger: true });
    if (!ok) return;
    try { await Storage.set('pre-restore', store.serialize()); hasUndo = true; const s = Core.createStore(); fn(s); attachStore(s); await Storage.set(KEY, s.serialize()); prefs.user = s.list('people')[0] ? s.list('people')[0].id : ''; savePrefs(); location.hash = '#/dashboard'; render(); toast('Database replaced. Undo is available on the Data page.'); } catch (e) { fail(e); }
  }

  document.addEventListener('click', async ev => {
    const a = ev.target.closest('[data-act]'); if (!a) return;
    const d = a.dataset, act = d.act;
    try {
      if (act === 'go') doTransition(d.n, d.id, d.to);
      else if (act === 'approve') { const v = await ask({ title: 'Approve: ' + store._raw(d.n, d.id).pending.transition, body: '<p style="margin:0">Your approval is recorded with your name, time and a hash of the record content as approved.</p>', fields: [{ name: 'c', label: 'Comment (optional)', type: 'textarea' }], ok: 'Approve' }); if (v) { store.approve(d.n, d.id, me(), v.c); toast('Approved.'); render(); } }
      else if (act === 'reject') { const v = await ask({ title: 'Reject request', fields: [{ name: 'c', label: 'Reason (required)', type: 'textarea', required: true }], ok: 'Reject', danger: true }); if (v) { store.reject(d.n, d.id, me(), v.c); toast('Rejected; the requester can revise and resubmit.'); render(); } }
      else if (act === 'withdraw') { store.withdraw(d.n, d.id, me(), 'Withdrawn by requester'); toast('Request withdrawn.'); render(); }
      else if (act === 'sort') { const lp = prefs['list:' + d.n] = prefs['list:' + d.n] || {}; if (lp.sort === d.k) lp.dir = lp.dir === 'asc' ? 'desc' : 'asc'; else { lp.sort = d.k; lp.dir = 'asc'; } savePrefs(); render(); }
      else if (act === 'clearFilters') { prefs['list:' + d.n] = { sort: (prefs['list:' + d.n] || {}).sort, dir: (prefs['list:' + d.n] || {}).dir }; savePrefs(); location.hash = '#/list/' + d.n; render(); }
      else if (act === 'csv') download(d.n + '_' + stamp() + '.csv', store.toCSV(d.n), 'text/csv;charset=utf-8');
      else if (act === 'auditcsv') download('audit_trail_' + stamp() + '.csv', store.auditTrailCSV(), 'text/csv;charset=utf-8');
      else if (act === 'allcsv') { for (const n of Object.keys(E)) { download(n + '_' + stamp() + '.csv', store.toCSV(n), 'text/csv;charset=utf-8'); await new Promise(r => setTimeout(r, 120)); } }
      else if (act === 'rpt-csv') { const t = $('#rpt'); if (t) download('report_' + d.r + '_' + stamp() + '.csv', tableToCSV(t), 'text/csv;charset=utf-8'); else toast('No table to export.', true); }
      else if (act === 'print') window.print();
      else if (act === 'integrity') { window.QMSApp.lastIntegrity = store.integrityCheck(); toast(window.QMSApp.lastIntegrity.ok ? 'Integrity check passed.' : 'Integrity problems found.', !window.QMSApp.lastIntegrity.ok); render(); }
      else if (act === 'backup') { const b = store.backup(me() || ''); scheduleSave(); download('qms_backup_' + stamp() + '.json', JSON.stringify(b), 'application/json'); toast('Backup downloaded (' + b.recordCount + ' records).'); }
      else if (act === 'undoRestore') { const prev = await Storage.get('pre-restore'); if (!prev) return toast('No undo point.', true); const ok = await ask({ title: 'Undo last restore or reset?', body: '<p>The database returns to the state before the last restore or reset.</p>', ok: 'Undo', danger: true }); if (!ok) return; const cur = store.serialize(); const s = Core.createStore({ data: JSON.parse(prev) }); attachStore(s); await Storage.set(KEY, prev); await Storage.set('pre-restore', cur); toast('Previous database restored.'); render(); }
      else if (act === 'loadDemo') replaceDb(s => Seed.seed(s), 'Replace with demonstration data');
      else if (act === 'startEmpty') { const v = await ask({ title: 'Start a new empty system', body: '<p>This replaces every record. You will be the first user with approval and administrator rights.</p>', fields: [{ name: 'org', label: 'Organization name', required: true }, { name: 'name', label: 'Your name', required: true }, { name: 'c', label: 'Type REPLACE to confirm', required: true, match: 'REPLACE' }], ok: 'Start empty', danger: true }); if (v) { await Storage.set('pre-restore', store.serialize()); hasUndo = true; const s = Core.createStore(); s.setCompany(v.org, ''); const p = s.create('people', { name: v.name, canApprove: 'Yes', isAdmin: 'Yes', department: 'Quality' }, ''); attachStore(s); prefs.user = p.id; savePrefs(); await Storage.set(KEY, s.serialize()); location.hash = '#/dashboard'; render(); } }
      else if (act === 'setupDemo') { const s = Core.createStore(); Seed.seed(s); attachStore(s); prefs.user = 'PER-0001'; savePrefs(); await Storage.set(KEY, s.serialize()); location.hash = '#/dashboard'; render(); toast('Demonstration data loaded. You are acting as Dana Whitfield (Quality Manager).'); }
      else if (act === 'addrow') { const wrap = a.closest('[data-field]'), fd = E[$('#recForm').dataset.n].fields.find(f => f.k === d.k); const tb = $('tbody', wrap); const empty = $('td.muted', tb); if (empty) empty.parentNode.remove(); const i = $$('tr', tb).length; tb.insertAdjacentHTML('beforeend', tableRow(fd, {}, i, true)); markDirty(); const first = $('tr:last-child [data-col]', tb); first && first.focus(); }
      else if (act === 'delrow') { a.closest('tr').remove(); markDirty(); }
      else if (act === 'discard') render();
      else if (act === 'dl-att') { const r = store._raw(d.n, d.id), at = r.attachments.find(x => x.id === d.att); const bin = atob(at.data), u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); download(at.name, new Blob([u8], { type: at.type })); }
      else if (act === 'rm-att') { const v = await ask({ title: 'Remove evidence', body: '<p style="margin:0">The removal and your reason are recorded in the history.</p>', fields: [{ name: 'c', label: 'Reason', required: true }], ok: 'Remove', danger: true }); if (v) { store.removeAttachment(d.n, d.id, d.att, me(), v.c); render(); } }
    } catch (e) { fail(e); }
  });
  function markDirty() {
    dirty = true; const b = $('#saveBtn'), x = $('#discardBtn'); if (b) b.disabled = false; if (x) x.disabled = false; const nt = $('#dirtyNote'); if (nt) nt.textContent = 'Unsaved changes';
    // Workflow buttons may become valid once edits are saved: enable them; clicking saves first, then re-checks.
    $$('button[data-act=go][disabled]').forEach(btn => { btn.disabled = false; btn.removeAttribute('aria-describedby'); });
    $$('.actions-bar .blocked').forEach(el => { el.textContent = 'Your edits will be saved first, then this step is checked.'; });
  }
  document.addEventListener('input', ev => {
    if (ev.target.closest('#recForm')) markDirty();
    if (ev.target.id === 'listSearch') { const n = ev.target.dataset.n; (prefs['list:' + n] = prefs['list:' + n] || {}).q = ev.target.value; savePrefs(); clearTimeout(window.__lt); window.__lt = setTimeout(() => { prefs.lastFocus = 'listSearch'; render(); }, 180); }
  });
  document.addEventListener('change', async ev => {
    const t = ev.target;
    if (t.closest('#recForm')) markDirty();
    if (t.id === 'statusFilter' || t.id === 'openOnly' || t.id === 'overdueOnly') {
      const n = t.dataset.n, lp = prefs['list:' + n] = prefs['list:' + n] || {};
      if (t.id === 'statusFilter') lp.status = t.value; if (t.id === 'openOnly') lp.open = t.checked; if (t.id === 'overdueOnly') lp.overdue = t.checked;
      savePrefs(); if (location.hash.includes('open=1') && t.id === 'openOnly') location.hash = '#/list/' + n; else render();
    }
    if (t.id === 'userSel') { prefs.user = t.value; savePrefs(); render(); }
    if (t.id === 'traceSel') location.hash = '#/reports/trace?id=' + encodeURIComponent(t.value);
    if (t.id === 'restoreFile' && t.files[0]) restoreFrom(t.files[0], false);
    if (t.id === 'setupRestore' && t.files[0]) restoreFrom(t.files[0], true);
  });
  document.addEventListener('submit', async ev => {
    const f = ev.target;
    if (f.id === 'recForm') { ev.preventDefault(); if (!me()) return toast('Select a user first.', true); saveForm(f); }
    else if (f.id === 'commentForm') { ev.preventDefault(); try { store.comment(f.dataset.n, f.dataset.id, me(), $('#cmt').value); render(); } catch (e) { fail(e); } }
    else if (f.id === 'attForm') {
      ev.preventDefault();
      const files = Array.from($('#attFile').files); if (!files.length) return toast('Choose at least one file.', true);
      for (const file of files) {
        try { const url = await readFile(file); store.addAttachment(f.dataset.n, f.dataset.id, { name: file.name, type: file.type, size: file.size, data: String(url).split(',')[1] || '', description: $('#attDesc').value }, me()); toast('Attached ' + file.name); } catch (e) { fail(e); }
      }
      render();
    } else if (f.id === 'companyForm') { ev.preventDefault(); store.setCompany($('#companyName').value, me()); scheduleSave(); render(); toast('Saved.'); }
    else if (f.id === 'setupForm') {
      ev.preventDefault();
      const org = $('#s_org').value.trim(), name = $('#s_name').value.trim(), email = $('#s_email').value.trim();
      if (!org || !name) { $('.form-err', f).innerHTML = '<div class="banner crit" style="margin-top:8px">Organization and your name are required.</div>'; return; }
      try { const s = Core.createStore(); s.setCompany(org, ''); const p = s.create('people', Object.assign({ name, canApprove: 'Yes', isAdmin: 'Yes', department: 'Quality' }, email ? { email } : {}), ''); attachStore(s); prefs.user = p.id; savePrefs(); await Storage.set(KEY, s.serialize()); location.hash = '#/list/people'; render(); toast('System created. Add colleagues next: approvals need a second person with approval authority.'); }
      catch (e) { $('.form-err', f).innerHTML = '<div class="banner crit" style="margin-top:8px">' + esc(e.message) + '</div>'; }
    }
  });
  // navigation guard for unsaved edits
  let lastHash = location.hash;
  window.addEventListener('hashchange', async () => {
    if (dirty) {
      const target = location.hash; history.replaceState(null, '', lastHash || '#/dashboard');
      const ok = await ask({ title: 'Discard unsaved changes?', body: '<p style="margin:0">You have edits on this record that have not been saved.</p>', ok: 'Discard and leave', danger: true });
      if (!ok) return; dirty = false; location.hash = target; return;
    }
    lastHash = location.hash; if (store) render(); $('#main').focus({ preventScroll: true }); $('#main').scrollTop = 0;
  });
  window.addEventListener('beforeunload', ev => { if (dirty) { ev.preventDefault(); ev.returnValue = ''; } });
  // global search, keyboard
  $('#globalSearch').addEventListener('keydown', ev => { if (ev.key === 'Enter') location.hash = '#/search?q=' + encodeURIComponent(ev.target.value); });
  document.addEventListener('keydown', ev => {
    if (ev.key === '/' && !/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName) && !$('#dlg').open) { ev.preventDefault(); const s = $('#listSearch') || $('#globalSearch'); s.focus(); }
    if (ev.key === 'Escape' && document.body.classList.contains('nav-open')) { document.body.classList.remove('nav-open'); $('#menuBtn').setAttribute('aria-expanded', 'false'); $('#menuBtn').focus(); }
  });
  $('#menuBtn').addEventListener('click', () => { const o = document.body.classList.toggle('nav-open'); $('#menuBtn').setAttribute('aria-expanded', String(o)); if (o) { const l = $('#side a'); l && l.focus(); } });
  // theme
  function applyTheme() { const t = prefs.theme || (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'); document.documentElement.dataset.theme = t; $('#themeBtn').setAttribute('aria-label', 'Switch to ' + (t === 'dark' ? 'light' : 'dark') + ' theme'); }
  $('#themeBtn').addEventListener('click', () => { prefs.theme = document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark'; savePrefs(); applyTheme(); });
  // tooltips for chart marks
  const tip = $('#tip');
  const showTip = (el, x, y) => { tip.textContent = el.dataset.tip; tip.style.display = 'block'; const w = tip.offsetWidth; tip.style.left = Math.min(window.innerWidth - w - 8, x + 12) + 'px'; tip.style.top = (y - 32) + 'px'; };
  document.addEventListener('mousemove', ev => { const el = ev.target.closest && ev.target.closest('[data-tip]'); if (el) showTip(el, ev.clientX, ev.clientY); else tip.style.display = 'none'; });
  document.addEventListener('focusin', ev => { const el = ev.target.closest && ev.target.closest('[data-tip]'); if (el) { const r = el.getBoundingClientRect(); showTip(el, r.left + r.width / 2, r.top); } else tip.style.display = 'none'; });

  /* ------------------------------------------------------------ boot */
  window.QMSApp = { get store() { return store; }, set store(s) { store = s; }, Storage, render, lastIntegrity: null };
  async function boot() {
    applyTheme();
    await Storage.init();
    let raw = null; try { raw = await Storage.get(KEY); } catch (e) { raw = null; }
    try { hasUndo = !!(await Storage.get('pre-restore')); } catch (e) { hasUndo = false; }
    if (raw) {
      try { attachStore(Core.createStore({ data: JSON.parse(raw) })); startupIntegrity = store.integrityCheck(); window.QMSApp.lastIntegrity = startupIntegrity; }
      catch (e) { $('#main').innerHTML = '<div class="banner crit">The stored database could not be read (' + esc(e.message) + '). Restore a backup below.</div>'; store = null; }
    }
    setSaveState(Storage.mode === 'memory' ? 'Not persisted' : 'Saved locally');
    if (!store) { viewSetup(); return; }
    if (!me()) { const first = store.list('people').find(p => p.status === 'Active' && p.data.isAdmin === 'Yes'); if (first && !prefs.user) { prefs.user = first.id; savePrefs(); } }
    render();
  }
  boot();
})();
