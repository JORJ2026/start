/*
 * Synthetic demonstration data for a fictional company, "Halvorsen Precision Machining".
 * All names, customers and suppliers are invented. Every record is created through the
 * public store API with a scripted clock, so histories, approvals and hash chains are genuine.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory(require('./core.js'));
  else root.QMSSeed = factory(root.QMSCore);
})(typeof self !== 'undefined' ? self : this, function (Core) {
  'use strict';

  function seed(store) {
    let t = new Date('2026-01-05T09:00:00Z');
    store.setClock(() => new Date(t));
    const at = d => { t = new Date(d + 'T09:00:00Z'); };
    const tick = () => { t = new Date(t.getTime() + 7 * 60000); };
    const C = (e, v, u) => { tick(); return store.create(e, v, u).id; };
    const U = (e, id, v, u, c) => { tick(); store.update(e, id, v, u, c); };
    const G = (e, id, to, u, c) => { tick(); return store.transition(e, id, to, u, c); };
    const A = (e, id, u, c) => { tick(); store.approve(e, id, u, c || 'Reviewed and approved.'); };
    const R = (e, id, u, c) => { tick(); store.reject(e, id, u, c); };
    const GA = (e, id, to, u, appr, c, ac) => { const r = G(e, id, to, u, c); if (r.pendingApproval) A(e, id, appr, ac); };
    const att = (e, id, name, text, u) => { tick(); store.addAttachment(e, id, { name, type: 'text/plain', data: b64(text) }, u); };
    const note = (e, id, u, text) => { tick(); store.comment(e, id, u, text); };
    const b64 = s => (typeof btoa !== 'undefined' ? btoa(unescape(encodeURIComponent(s))) : Buffer.from(s, 'utf8').toString('base64'));

    store.setCompany('Halvorsen Precision Machining (demo)', '');

    /* ---------------- people ---------------- */
    at('2026-01-05');
    const P = {};
    [['dana', 'Dana Whitfield', 'Quality Manager', 'Quality', 'Yes', 'Yes'],
     ['marcus', 'Marcus Oyelaran', 'Operations Manager', 'Operations', 'Yes', 'No'],
     ['priya', 'Priya Raman', 'Quality Engineer', 'Quality', 'No', 'No'],
     ['tomas', 'Tomás Ferreira', 'CNC Supervisor', 'Operations', 'No', 'No'],
     ['helen', 'Helen Kowalski', 'Purchasing Lead', 'Purchasing', 'No', 'No'],
     ['jordan', 'Jordan Lee', 'Quality Inspector', 'Quality', 'No', 'No'],
     ['samira', 'Samira Haddad', 'General Manager', 'Executive', 'Yes', 'No'],
     ['kevin', 'Kevin Brandt', 'CNC Machinist', 'Operations', 'No', 'No'],
     ['aisha', 'Aisha Mensah', 'Engineering Manager', 'Engineering', 'Yes', 'No'],
     ['luis', 'Luis Ortega', 'Maintenance Technician', 'Maintenance', 'No', 'No'],
     ['nina', 'Nina Petrova', 'CNC Machinist', 'Operations', 'No', 'No'],
     ['owen', 'Owen Castillo', 'Sales Coordinator', 'Sales', 'No', 'No']].forEach(([k, name, jobTitle, department, canApprove, isAdmin], i) => {
      P[k] = C('people', { name, jobTitle, department, canApprove, isAdmin, email: k + '@halvorsen.example' }, i === 0 ? '' : P.dana);
    });
    const D = P.dana, S = P.samira, M = P.marcus, PR = P.priya, TF = P.tomas;

    /* ---------------- processes ---------------- */
    const PRC = {};
    [['sales', 'Sales and contract review', P.owen, 'Confirm customer requirements can be met before acceptance.', 'RFQs, drawings, purchase orders', 'Reviewed and accepted orders', 'Quote turnaround, order review errors'],
     ['purch', 'Purchasing and supplier control', P.helen, 'Obtain conforming materials and services from approved suppliers.', 'Material requirements, approved supplier list', 'Purchase orders, received goods', 'Supplier score, receiving rejects'],
     ['cnc', 'CNC machining', TF, 'Produce machined components to drawing.', 'Released routers, material, programs', 'Machined parts', 'First pass yield, scrap cost'],
     ['insp', 'Inspection and release', PR, 'Verify product conformity before release.', 'Inspection plans, parts', 'Released product, inspection records', 'Escapes, inspection yield'],
     ['ship', 'Packaging and shipping', M, 'Deliver conforming product on time and undamaged.', 'Released product, orders', 'Shipments, certificates of conformity', 'On-time delivery'],
     ['qms', 'Quality system management', D, 'Plan, monitor and improve the management system.', 'Objectives, audit results, feedback', 'Reviews, improvement actions', 'Objectives achieved, CAPA on-time'],
     ['maint', 'Maintenance and calibration', P.luis, 'Keep equipment and measuring devices fit for purpose.', 'Equipment register, schedules', 'Maintained and calibrated equipment', 'Calibration on-time, downtime']].forEach(([k, name, owner, purpose, inputs, outputs, measures]) => {
      PRC[k] = C('processes', { name, owner, purpose, inputs, outputs, measures }, D);
    });

    /* ---------------- documents ---------------- */
    const DOC = {};
    const docDefs = [
      ['qm', 'QM-001', 'Quality Manual', 'Quality manual', PRC.qms, D, 'Describes scope, process interactions, and how the organization meets its quality management system requirements. Exclusion: design and development (build-to-print only).'],
      ['dc', 'QP-701', 'Control of Documented Information', 'Procedure', PRC.qms, D, 'Defines numbering, review, approval, revision, distribution and retention of documents and records.'],
      ['ncp', 'QP-850', 'Control of Nonconforming Output', 'Procedure', PRC.insp, PR, 'Identification, segregation, review and disposition of nonconforming product, including concessions.'],
      ['cap', 'QP-1020', 'Corrective Action', 'Procedure', PRC.qms, D, 'Containment, root cause analysis, action planning, verification and effectiveness review of corrective actions.'],
      ['sup', 'QP-840', 'Supplier Selection and Monitoring', 'Procedure', PRC.purch, P.helen, 'Supplier approval, scoring method (quality 50%, delivery 30%, responsiveness 20%) and re-evaluation interval.'],
      ['cal', 'QP-715', 'Calibration of Monitoring and Measuring Equipment', 'Procedure', PRC.maint, P.luis, 'Calibration intervals, status identification, out-of-tolerance impact assessment and recall.'],
      ['wi14', 'WI-CNC-014', '5-Axis Setup and First-Piece Verification', 'Work instruction', PRC.cnc, TF, 'Machine warm-up, work offset setting, tool length verification and first-piece inspection for 5-axis cells.'],
      ['wi3', 'WI-INS-003', 'Final Inspection of Manifold Blocks', 'Work instruction', PRC.insp, PR, 'Final inspection sequence for HX-series manifold blocks, including CMM program selection and visual criteria.'],
      ['f850', 'F-850-01', 'Nonconformance Report Form', 'Form', PRC.insp, PR, 'Paper fallback form for recording nonconformances when the system is unavailable.']];
    docDefs.forEach(([k, docNumber, title, docType, process, owner, content]) => {
      DOC[k] = C('documents', { docNumber, title, docType, process, owner, content, reviewIntervalMonths: 24 }, owner);
      GA('documents', DOC[k], 'Effective', owner, owner === D ? S : D, '', 'Approved for release.');
    });
    att('documents', DOC.qm, 'QM-001_revA_signed-cover.txt', 'QM-001 Quality Manual — Revision A\nApproved by Samira Haddad, General Manager\n(Synthetic demonstration evidence)', D);

    /* ---------------- suppliers & evaluations ---------------- */
    at('2026-01-12');
    const SUP = {};
    [['ridge', 'Ridgeline Metals Supply', 'Raw material', 'High', '6061-T6 and 7075-T6 aluminium bar and plate with mill certificates', 'ISO 9001 certificate on file'],
     ['corvane', 'Corvane Anodizing Ltd', 'Surface treatment', 'High', 'Type II and Type III anodizing, chem-film', 'ISO 9001 certificate on file'],
     ['metrix', 'Metrix Calibration Labs', 'Calibration service', 'Medium', 'Dimensional calibration of hand tools, gauges and CMM verification', 'ISO/IEC 17025 accreditation on file'],
     ['brite', 'Brightpack Packaging Co', 'Packaging', 'Low', 'Custom foam inserts and corrugated cartons', 'None declared']].forEach(([k, name, category, criticality, scope, certifications]) => {
      SUP[k] = C('suppliers', { name, category, criticality, scope, certifications, contact: 'quality@' + k + '.example', evalIntervalMonths: 12 }, P.helen);
    });
    const ev = (sup, period, date, q, d, r, ppm, comments, appr) => {
      at(date);
      const id = C('supplierEvals', { supplier: sup, period, evaluator: P.helen, evalDate: date, qualityScore: q, deliveryScore: d, responsivenessScore: r, ppm, comments }, P.helen);
      GA('supplierEvals', id, 'Completed', P.helen, appr || D);
      return id;
    };
    ev(SUP.ridge, '2025 annual', '2026-01-14', 96, 92, 90, 120, 'Consistent certs; two late deliveries in Q4.');
    GA('suppliers', SUP.ridge, 'Approved', P.helen, D);
    ev(SUP.corvane, '2025 annual', '2026-01-14', 88, 85, 80, 2400, 'Acceptable; coating thickness drift noted twice.');
    GA('suppliers', SUP.corvane, 'Approved', P.helen, D);
    ev(SUP.metrix, '2025 annual', '2026-01-15', 98, 95, 94, 0, 'Accredited scope covers all our gauge types.');
    GA('suppliers', SUP.metrix, 'Approved', P.helen, D);

    /* ---------------- equipment & calibration ---------------- */
    const EQ = {};
    [['cal1', 'CAL-0412', '150 mm digital caliper', 'Caliper', 'Cell 2', '0-150 mm / 0.01 mm', 365],
     ['mic1', 'MIC-0107', '0-25 mm outside micrometer', 'Micrometer', 'Inspection lab', '0-25 mm / 0.001 mm', 365],
     ['cmm', 'CMM-01', 'Bridge CMM 700x1000x600', 'CMM', 'Inspection lab', 'MPE 2.2+L/300 µm', 365],
     ['tw', 'TW-0033', 'Torque wrench 5-25 N·m', 'Torque wrench', 'Assembly', '5-25 N·m', 180],
     ['pin', 'PG-0210', 'Pin gauge set 1.00-6.00 mm', 'Pin gauge set', 'Cell 2', '0.01 mm steps', 365],
     ['hg', 'HG-0003', '600 mm digital height gauge', 'Height gauge', 'Inspection lab', '0-600 mm / 0.001 mm', 365]].forEach(([k, assetTag, name, equipType, location, range, intervalDays]) => {
      EQ[k] = C('equipment', { assetTag, name, equipType, location, range, intervalDays, owner: P.luis, provider: SUP.metrix }, P.luis);
    });
    const cal = (eq, date, cert, result, asFound, impact) => {
      at(date);
      const id = C('calibrations', { equipment: eq, calDate: date, performedBy: SUP.metrix, certificateNo: cert, result, asFound, asLeft: 'Within tolerance', impactAssessment: impact || '' }, P.luis);
      att('calibrations', id, cert + '.txt', 'Calibration certificate ' + cert + '\nIssued by Metrix Calibration Labs (fictional)\nResult: ' + result, P.luis);
      return id;
    };
    const calOK = (eq, date, cert, result, asFound, impact) => { const id = cal(eq, date, cert, result, asFound, impact); GA('calibrations', id, 'Approved', P.luis, D); return id; };
    calOK(EQ.cal1, '2026-01-20', 'MCL-26-0141', 'Pass', 'All points within ±0.02 mm');
    calOK(EQ.mic1, '2026-01-20', 'MCL-26-0142', 'Pass', 'All points within ±0.002 mm');
    calOK(EQ.cmm, '2026-02-03', 'MCL-26-0198', 'Pass after adjustment', 'Length error 2.9 µm at 600 mm (limit 4.2 µm); probe requalified', 'As-found within MPE; adjustment was preventive. No impact on released product.');
    calOK(EQ.tw, '2026-04-10', 'MCL-26-0377', 'Pass', 'Within ±4% at 20/60/100% of range');
    calOK(EQ.pin, '2026-01-21', 'MCL-26-0150', 'Pass', 'All pins within class ZZ');
    calOK(EQ.hg, '2025-12-02', 'MCL-25-1820', 'Pass', 'Within ±0.004 mm');

    /* ---------------- risks ---------------- */
    at('2026-01-26');
    const RK = {};
    [['bore', 'Tool wear causing oversize bores on manifold ports', 'Risk', PRC.cnc, 'Bore diameter drifts as boring tools wear during long runs.', '3', '4', 'First-piece check; operator visual checks', TF],
     ['anod', 'Anodize thickness variation from outsourced coating', 'Risk', PRC.purch, 'Coating thickness outside drawing limits affects fit of mating parts.', '3', '3', 'Supplier certificate of conformance', P.helen],
     ['single', 'Single source for 7075-T6 plate', 'Risk', PRC.purch, 'Only one approved source; disruption would stop aerospace bracket orders.', '2', '4', 'Two-week safety stock', P.helen],
     ['cmmcap', 'CMM capacity constraint at month end', 'Risk', PRC.insp, 'Final inspection queue delays shipments in the last week of each month.', '4', '2', 'Overtime authorisation', PR],
     ['auto', 'Automate in-process probing on 5-axis cells', 'Opportunity', PRC.cnc, 'Spindle probing could replace manual bore checks and reduce cycle time.', '3', '3', '', M],
     ['know', 'Loss of key CNC programming knowledge', 'Risk', PRC.cnc, 'Two programmers hold most knowledge of legacy programs.', '2', '3', 'Program backups', M]].forEach(([k, title, kind, process, description, likelihood, severity, controls, owner]) => {
      RK[k] = C('risks', { title, kind, process, description, likelihood, severity, controls, owner, reviewDate: k === 'know' ? '2026-10-30' : k === 'cmmcap' ? '2026-12-11' : '2027-01-29' }, owner);
    });
    U('risks', RK.single, { treatment: 'Qualify a second plate supplier by Q3.' }, P.helen);
    G('risks', RK.single, 'Treatment', P.helen);
    U('risks', RK.cmmcap, { treatment: 'Level-load CMM by releasing inspection programs earlier; cross-train a second operator.' }, PR);
    G('risks', RK.cmmcap, 'Treatment', PR);

    /* ---------------- objectives ---------------- */
    const OBJ = {};
    OBJ.cmp = C('objectives', { title: 'Reduce customer complaints', process: PRC.qms, owner: D, metric: 'Customer complaints per month', unit: 'complaints', direction: 'Lower is better', baseline: 2, target: 1, targetDate: '2026-12-31', plan: 'Strengthen in-process controls on high-volume parts; close complaint CAPAs on time.' }, D);
    OBJ.fpy = C('objectives', { title: 'Improve first pass yield', process: PRC.cnc, owner: TF, metric: 'First pass yield at final inspection', unit: '%', direction: 'Higher is better', baseline: 97.2, target: 98.5, targetDate: '2026-12-31', plan: 'Tool-life management and in-process bore verification.' }, D);
    OBJ.otd = C('objectives', { title: 'On-time delivery', process: PRC.ship, owner: M, metric: 'Orders shipped on or before promise date', unit: '%', direction: 'Higher is better', baseline: 91, target: 95, targetDate: '2026-12-31', plan: 'Weekly capacity review; CMM level-loading.' }, D);
    OBJ.capa = C('objectives', { title: 'Close corrective actions on time', process: PRC.qms, owner: D, metric: 'CAPAs closed by target date', unit: '%', direction: 'Higher is better', baseline: 60, target: 80, targetDate: '2026-12-31', plan: 'Fortnightly CAPA review in the quality meeting.' }, D);

    /* ---------------- inspection plans ---------------- */
    at('2026-01-28');
    const IPL = {};
    IPL.hx = C('inspPlans', { title: 'HX-2210 manifold final inspection', partNumber: 'HX-2210', stage: 'Final', process: PRC.insp, document: DOC.wi3, sampling: 'AQL 1.0, general level II; critical bores 100%', characteristics: [
      { characteristic: 'Port bore Ø12.000', spec: '+0.018 / 0', method: 'Bore gauge / CMM', gauge: EQ.cmm, frequency: 'Every part' },
      { characteristic: 'Overall length', spec: '120.00 ±0.10', method: 'Caliper', gauge: EQ.cal1, frequency: 'Sample' },
      { characteristic: 'Thread M8x1.25 depth', spec: '≥ 14 mm', method: 'Thread gauge', gauge: EQ.pin, frequency: 'Sample' },
      { characteristic: 'Surface finish sealing face', spec: 'Ra ≤ 0.8', method: 'Profilometer', frequency: 'Sample' }] }, PR);
    GA('inspPlans', IPL.hx, 'Approved', PR, D);
    IPL.bar = C('inspPlans', { title: '6061-T6 bar receiving inspection', partNumber: 'RM-6061-BAR', stage: 'Receiving', process: PRC.purch, sampling: 'Verify certificate every lot; dimensional 3 pieces per lot', characteristics: [
      { characteristic: 'Mill certificate', spec: 'Matches PO grade and temper', method: 'Document review', frequency: 'Every lot' },
      { characteristic: 'Diameter', spec: 'Ø50.0 ±0.15', method: 'Caliper', gauge: EQ.cal1, frequency: '3 pcs' }] }, PR);
    GA('inspPlans', IPL.bar, 'Approved', PR, D);
    IPL.bk = C('inspPlans', { title: 'BK-118 bracket anodize check', partNumber: 'BK-118', stage: 'Receiving', process: PRC.insp, sampling: '5 pieces per lot', characteristics: [
      { characteristic: 'Anodize thickness', spec: '10-25 µm', method: 'Eddy current gauge', frequency: '5 pcs' },
      { characteristic: 'Hole Ø6.00', spec: '+0.05 / 0 after coating', method: 'Pin gauge', gauge: EQ.pin, frequency: '5 pcs' }] }, PR);
    GA('inspPlans', IPL.bk, 'Approved', PR, D);

    /* ---------------- training (initial) ---------------- */
    const trn = (person, course, document, method, assigned, due, completed, trainer, assessment, approver) => {
      at(assigned);
      const id = C('training', { person, course, document, method, assignedDate: assigned, dueDate: due }, D);
      if (completed) {
        at(completed);
        U('training', id, { completedDate: completed }, person);
        G('training', id, 'Completed', person);
        if (trainer) { U('training', id, { trainer, assessment }, trainer); GA('training', id, 'Verified', trainer, approver || D); }
      }
      return id;
    };
    trn(P.kevin, 'WI-CNC-014 setup and first-piece', DOC.wi14, 'On-the-job', '2026-01-19', '2026-01-30', '2026-01-23', TF, 'Observed two complete setups without error.');
    trn(P.nina, 'WI-INS-003 final inspection', DOC.wi3, 'Read and acknowledge', '2026-01-19', '2026-01-30', '2026-01-22', PR, 'Quiz 9/10; observed one inspection.');
    trn(P.jordan, 'WI-INS-003 final inspection', DOC.wi3, 'Classroom', '2026-01-19', '2026-01-30', '2026-01-21', PR, 'Practical assessment passed.');
    trn(P.jordan, 'QP-850 nonconforming output', DOC.ncp, 'Read and acknowledge', '2026-02-02', '2026-02-13', '2026-02-05', PR, 'Acknowledged; walkthrough of NCR entry.');
    trn(P.helen, 'QP-840 supplier monitoring', DOC.sup, 'Read and acknowledge', '2026-02-02', '2026-02-13', '2026-02-04', D, 'Acknowledged.', S);
    trn(P.aisha, 'Internal auditor refresher', '', 'External course', '2026-02-02', '2026-03-31', '2026-03-12', D, 'Certificate of completion attached to personnel file.', S);

    /* ---------------- monthly inspections & NCRs ---------------- */
    const NCR = {};
    const ncr = (k, vals, owner) => { NCR[k] = C('ncrs', Object.assign({ owner, dueDate: Core.utils.addDays(vals.detectedDate, 10) }, vals), owner); return NCR[k]; };
    const closeNcr = (id, owner, disposition, notes, approver) => {
      G('ncrs', id, 'Under review', owner);
      U('ncrs', id, { disposition, dispositionNotes: notes }, owner);
      GA('ncrs', id, 'Dispositioned', owner, approver || D);
      G('ncrs', id, 'Closed', owner);
    };
    const months = [['01', 210, 4], ['02', 225, 5], ['03', 240, 9], ['04', 230, 6], ['05', 236, 3], ['06', 228, 2], ['07', 245, 3], ['08', 238, 2], ['09', 250, 2], ['10', 244, 3], ['11', 232, 1]];
    const insp = {};
    months.forEach(([m, q, rj], i) => {
      const date = '2026-' + m + '-1' + (i % 9);
      at(date);
      const id = C('inspections', { plan: IPL.hx, inspDate: date, lot: 'L26' + m + '-1' + String(10 + i), inspector: P.jordan, qtyInspected: q, qtyRejected: rj, notes: 'CMM program HX2210_R3. ' + (rj ? rj + ' parts segregated.' : '') }, P.jordan);
      insp[m] = id;
      if (rj) {
        const nid = ncr('ins' + m, { title: 'HX-2210 final inspection rejects lot L26' + m, detectedDate: date, detectedAt: 'Final inspection', partNumber: 'HX-2210', lot: 'L26' + m + '-1' + String(10 + i), qtyAffected: rj, severity: 'Minor', description: rj + ' parts outside drawing at final inspection (mixed: bore, burrs, thread depth).', inspection: id }, PR);
        if (m !== '11') closeNcr(nid, PR, rj > 4 ? 'Scrap' : 'Rework', rj > 4 ? 'Bores oversize; cannot be recovered.' : 'Deburr and re-tap; re-inspect 100%.');
      }
      G('inspections', id, 'Accepted', P.jordan);
    });
    // Receiving inspections of bar stock (all good)
    ['2026-02-09', '2026-05-11', '2026-08-10'].forEach((d, i) => { at(d); const id = C('inspections', { plan: IPL.bar, inspDate: d, lot: 'RM-H' + (4410 + i), inspector: P.jordan, qtyInspected: 3, qtyRejected: 0, notes: 'Cert verified.' }, P.jordan); G('inspections', id, 'Accepted', P.jordan); });

    /* ================= FLAGSHIP: complete corrective-action lifecycle =================
       Complaint CMP-0001 -> NCR -> CAPA-0001 -> document revision + training + plan update + risk update -> closed effective */
    at('2026-03-04');
    const CMP = {};
    CMP.bore = C('complaints', { title: 'HX-2210 port bores oversize', customer: 'Aldane Fluid Systems', contact: 'R. Okafor, Supplier Quality', receivedDate: '2026-03-04', channel: 'Portal', partNumber: 'HX-2210', lot: 'L2602-111', category: 'Dimensional', severity: 'Major', description: '12 of 200 manifolds rejected at incoming: port bore Ø12 measured 12.024-12.031 (max 12.018). Parts leak at O-ring.', owner: PR, responseDue: '2026-03-18' }, D);
    att('complaints', CMP.bore, 'Aldane_SCAR-2026-031.txt', 'Supplier corrective action request SCAR-2026-031 (fictional)\nPart HX-2210, lot L2602-111, 12/200 rejected for oversize bore.', PR);
    G('complaints', CMP.bore, 'Investigation', PR);
    at('2026-03-05');
    NCR.cust = C('ncrs', { title: 'Customer return: HX-2210 oversize port bores', detectedDate: '2026-03-05', detectedAt: 'Customer', partNumber: 'HX-2210', lot: 'L2602-111', qtyAffected: 12, severity: 'Major', description: '12 returned parts confirmed oversize at bore Ø12 (12.024-12.031). Remaining stock in finished goods: 64 pcs from same lot.', complaint: CMP.bore, owner: PR, dueDate: '2026-03-12' }, PR);
    at('2026-03-05');
    const CAPA = {};
    CAPA.bore = C('capas', { title: 'Oversize port bores on HX-2210 reached customer', source: 'Customer complaint', priority: 'High', owner: PR, process: PRC.cnc, openedDate: '2026-03-05', dueDate: '2026-06-30', problem: 'Port bores on HX-2210 lot L2602-111 were machined oversize (up to +0.013 mm over limit) and 12 parts escaped final inspection sampling to Aldane Fluid Systems, causing O-ring leaks.' }, PR);
    U('ncrs', NCR.cust, { capa: CAPA.bore }, PR);
    U('complaints', CMP.bore, { capa: CAPA.bore }, PR);
    G('ncrs', NCR.cust, 'Under review', PR);
    G('capas', CAPA.bore, 'Containment', PR);
    at('2026-03-06');
    U('capas', CAPA.bore, { containment: 'Quarantined 64 pcs finished goods and 140 pcs WIP. 100% bore check by CMM: 3 more oversize found and scrapped; remainder released. Interim 100% bore gauging at final inspection from 2026-03-06.' }, PR);
    att('capas', CAPA.bore, 'containment_sort_results.txt', 'Sort results 2026-03-06\nFG: 64 checked, 2 oversize\nWIP: 140 checked, 1 oversize\nAll rejects tagged and moved to MRB cage.', PR);
    G('capas', CAPA.bore, 'Root cause', PR);
    U('ncrs', NCR.cust, { disposition: 'Scrap', dispositionNotes: 'Oversize bores cannot be reworked. Replacement lot shipped 2026-03-09 after 100% bore check.' }, PR);
    GA('ncrs', NCR.cust, 'Dispositioned', PR, D);
    at('2026-03-12');
    U('capas', CAPA.bore, { rootCauseMethod: '5 Whys', rootCause: 'Why oversize? Boring bar insert wore beyond its compensation range. Why not detected? Wear offset was only adjusted at setup. Why? WI-CNC-014 has no tool-life limit or in-cycle bore check for finishing tools. Why did it escape? Final inspection sampled bores at AQL 1.0 instead of 100% for a sealing feature. Root causes: (1) no tool-life control for finishing boring tools, (2) inspection plan treated a critical sealing bore as a sampled characteristic.' }, PR);
    G('capas', CAPA.bore, 'Action plan', PR);
    U('capas', CAPA.bore, { risks: [RK.bore], actions: [
      { action: 'Revise WI-CNC-014: tool-life limit of 400 bores per finishing insert and bore check after every insert change', owner: TF, due: '2026-03-27', status: 'Open' },
      { action: 'Change HX-2210 inspection plan: port bore 100% on CMM', owner: PR, due: '2026-03-20', status: 'Open' },
      { action: 'Train all 5-axis machinists on WI-CNC-014 rev B', owner: TF, due: '2026-04-10', status: 'Open' },
      { action: 'Update risk register entry for tool wear with new controls', owner: PR, due: '2026-04-10', status: 'Open' }] }, PR);
    at('2026-03-13');
    G('capas', CAPA.bore, 'Implementation', PR);
    R('capas', CAPA.bore, D, 'Add an action to evaluate spindle probing (see opportunity register) and confirm insert life with data, not estimate.');
    U('capas', CAPA.bore, { actions: [
      { action: 'Revise WI-CNC-014: tool-life limit per finishing insert (validated by wear study) and bore check after every insert change', owner: TF, due: '2026-03-27', status: 'Open' },
      { action: 'Change HX-2210 inspection plan: port bore 100% on CMM', owner: PR, due: '2026-03-20', status: 'Open' },
      { action: 'Train all 5-axis machinists on WI-CNC-014 rev B', owner: TF, due: '2026-04-10', status: 'Open' },
      { action: 'Update risk register entry for tool wear with new controls', owner: PR, due: '2026-04-10', status: 'Open' },
      { action: 'Evaluate in-process spindle probing for bore diameter', owner: M, due: '2026-04-30', status: 'Open' }] }, PR, 'Revised per reviewer comments');
    G('capas', CAPA.bore, 'Implementation', PR);
    A('capas', CAPA.bore, D, 'Action plan approved.');
    // Action 2: inspection plan revision
    at('2026-03-18');
    G('inspPlans', IPL.hx, 'Draft', PR, 'CAPA-0001 action 2: bore to 100%');
    U('inspPlans', IPL.hx, { sampling: 'AQL 1.0, general level II; port bores 100% on CMM (CAPA-0001)', characteristics: [
      { characteristic: 'Port bore Ø12.000', spec: '+0.018 / 0', method: 'CMM', gauge: EQ.cmm, frequency: '100%' },
      { characteristic: 'Overall length', spec: '120.00 ±0.10', method: 'Caliper', gauge: EQ.cal1, frequency: 'Sample' },
      { characteristic: 'Thread M8x1.25 depth', spec: '≥ 14 mm', method: 'Thread gauge', gauge: EQ.pin, frequency: 'Sample' },
      { characteristic: 'Surface finish sealing face', spec: 'Ra ≤ 0.8', method: 'Profilometer', frequency: 'Sample' }] }, PR);
    GA('inspPlans', IPL.hx, 'Approved', PR, D);
    // Response to customer
    at('2026-03-16');
    U('complaints', CMP.bore, { investigation: 'Confirmed oversize bores caused by finishing insert wear without tool-life control; sampling at final inspection allowed escape. See CAPA-0001.', response: '8D report sent: containment (100% sort, replacement lot shipped 9 Mar), root cause, and permanent actions with dates.' }, PR);
    G('complaints', CMP.bore, 'Response sent', PR);
    att('complaints', CMP.bore, '8D_report_SCAR-2026-031.txt', '8D report D1-D8 summary for SCAR-2026-031 (synthetic).', PR);
    // Action 1: document revision
    at('2026-03-23');
    G('documents', DOC.wi14, 'Draft', TF, 'CAPA-0001 action 1');
    U('documents', DOC.wi14, { capa: CAPA.bore, changeSummary: 'Added tool-life limit of 350 bores per finishing insert (wear study WS-26-04) and mandatory bore check after every insert change. Ref CAPA-0001.', content: 'Machine warm-up, work offset setting, tool length verification, first-piece inspection, finishing tool-life limits and post-change bore verification for 5-axis cells.' }, TF);
    att('documents', DOC.wi14, 'wear_study_WS-26-04.txt', 'Wear study WS-26-04: 6 inserts run to 600 bores; diameter growth +0.011 mm at 400, +0.004 at 350. Limit set at 350.', TF);
    G('documents', DOC.wi14, 'Effective', TF);
    A('documents', DOC.wi14, D, 'Rev B approved.');
    // Action 3: training on rev B
    trn(P.kevin, 'WI-CNC-014 rev B tool-life control', DOC.wi14, 'Classroom', '2026-03-25', '2026-04-10', '2026-03-31', TF, 'Demonstrated insert change and bore check at machine.');
    trn(P.nina, 'WI-CNC-014 rev B tool-life control', DOC.wi14, 'Classroom', '2026-03-25', '2026-04-10', '2026-04-01', TF, 'Demonstrated insert change and bore check at machine.');
    trn(TF, 'WI-CNC-014 rev B tool-life control', DOC.wi14, 'Read and acknowledge', '2026-03-25', '2026-04-10', '2026-03-26', D, 'Author; acknowledged.', S);
    // Action 4: risk update
    at('2026-04-08');
    U('risks', RK.bore, { treatment: 'Tool-life limit and post-change bore check (WI-CNC-014 rev B); 100% CMM bore check at final (IPL-0001).', owner: PR }, PR);
    G('risks', RK.bore, 'Treatment', PR);
    U('risks', RK.bore, { residualLikelihood: '1', residualSeverity: '4' }, PR);
    G('risks', RK.bore, 'Monitoring', PR);
    // Close complaint
    at('2026-03-30');
    U('complaints', CMP.bore, { satisfaction: 'Yes' }, PR);
    GA('complaints', CMP.bore, 'Closed', PR, D, '', 'Customer accepted 8D on 2026-03-28.');
    G('ncrs', NCR.cust, 'Closed', PR);
    // Action 5 + complete actions
    at('2026-04-28');
    U('risks', RK.auto, { treatment: 'Trial Renishaw-style spindle probe on cell 2 in Q3 (capital request CR-26-07).' }, M);
    G('risks', RK.auto, 'Treatment', M);
    U('capas', CAPA.bore, { actions: [
      { action: 'Revise WI-CNC-014: tool-life limit per finishing insert (validated by wear study) and bore check after every insert change', owner: TF, due: '2026-03-27', status: 'Done', completedOn: '2026-03-24' },
      { action: 'Change HX-2210 inspection plan: port bore 100% on CMM', owner: PR, due: '2026-03-20', status: 'Done', completedOn: '2026-03-18' },
      { action: 'Train all 5-axis machinists on WI-CNC-014 rev B', owner: TF, due: '2026-04-10', status: 'Done', completedOn: '2026-04-01' },
      { action: 'Update risk register entry for tool wear with new controls', owner: PR, due: '2026-04-10', status: 'Done', completedOn: '2026-04-08' },
      { action: 'Evaluate in-process spindle probing for bore diameter', owner: M, due: '2026-04-30', status: 'Done', completedOn: '2026-04-28' }] }, PR);
    G('capas', CAPA.bore, 'Verification', PR);
    at('2026-05-04');
    U('capas', CAPA.bore, { verification: 'Verified on the floor 2026-05-04: tool-life counters active on cells 1-3; bore check records present for every insert change since 2026-04-01; IPL-0001 shows 100% bore on CMM; training TRN records verified.' }, D);
    G('capas', CAPA.bore, 'Effectiveness review', D);
    U('capas', CAPA.bore, { effectivenessDue: '2026-06-26' }, D);
    note('capas', CAPA.bore, D, 'Effectiveness criterion: zero bore-related escapes and no bore rejects at final inspection over at least 10 production lots.');
    at('2026-06-26');
    U('capas', CAPA.bore, { effectivenessResult: 'Effective', effectivenessEvidence: '14 lots (3,180 parts) produced 2026-04-01 to 2026-06-24: 0 bore rejects at final, 0 customer complaints for bores. Aldane incoming data shows 0 rejects for HX-2210 since April.' }, PR);
    att('capas', CAPA.bore, 'effectiveness_data_Q2.txt', 'Lot,Parts,Bore rejects\nL2604-112,230,0\nL2605-113,236,0\nL2606-114,228,0\n... 14 lots total, 0 bore rejects (synthetic).', PR);
    G('capas', CAPA.bore, 'Closed', PR);
    A('capas', CAPA.bore, S, 'Closed as effective. Good use of a wear study to set the limit.');

    /* ---------------- Internal audits ---------------- */
    at('2026-02-16');
    const AUD = {};
    AUD.prod = C('audits', { title: 'Production and release process audit', auditType: 'Process', process: PRC.cnc, clauses: '8.5.1, 8.5.2, 8.6', leadAuditor: P.aisha, auditee: TF, plannedDate: '2026-02-24', scope: 'Cell 1-3 setup, traceability and release of HX and BK part families. Criteria: QM-001, WI-CNC-014, WI-INS-003.' }, D);
    at('2026-02-24');
    G('audits', AUD.prod, 'In progress', P.aisha);
    at('2026-02-26');
    U('audits', AUD.prod, { summary: 'Setups follow WI-CNC-014; traceability good. One minor NC: two travellers missing lot number transfer at deburr. One OFI on tool-life tracking.', findings: [
      { type: 'Minor NC', clause: '8.5.2', description: 'Lot number not transferred to traveller at deburr for 2 of 15 jobs sampled' },
      { type: 'Opportunity', clause: '8.5.1', description: 'No tool-life tracking for finishing tools (later confirmed as root cause in CAPA-0001)' }] }, P.aisha);
    G('audits', AUD.prod, 'Report issued', P.aisha);
    CAPA.trace = C('capas', { title: 'Lot number not transferred at deburr', source: 'Internal audit', priority: 'Low', owner: TF, process: PRC.cnc, openedDate: '2026-02-27', dueDate: '2026-04-30', problem: 'Audit AUD-0001: 2 of 15 travellers missing lot number entry at deburr station.' }, P.aisha);
    U('audits', AUD.prod, { findings: [
      { type: 'Minor NC', clause: '8.5.2', description: 'Lot number not transferred to traveller at deburr for 2 of 15 jobs sampled', capa: CAPA.trace },
      { type: 'Opportunity', clause: '8.5.1', description: 'No tool-life tracking for finishing tools (later confirmed as root cause in CAPA-0001)' }] }, P.aisha);
    G('capas', CAPA.trace, 'Containment', TF);
    U('capas', CAPA.trace, { containment: 'Checked all open travellers at deburr (23); 1 more missing lot number corrected from router record.' }, TF);
    G('capas', CAPA.trace, 'Root cause', TF);
    at('2026-03-10');
    U('capas', CAPA.trace, { rootCauseMethod: 'Is / Is-not', rootCause: 'Deburr traveller field is on the back page and not part of the station sign-off box.' }, TF);
    G('capas', CAPA.trace, 'Action plan', TF);
    U('capas', CAPA.trace, { actions: [{ action: 'Move lot number field into deburr sign-off box on traveller template', owner: TF, due: '2026-03-31', status: 'Open' }] }, TF);
    GA('capas', CAPA.trace, 'Implementation', TF, D);
    at('2026-03-30');
    U('capas', CAPA.trace, { actions: [{ action: 'Move lot number field into deburr sign-off box on traveller template', owner: TF, due: '2026-03-31', status: 'Done', completedOn: '2026-03-30' }] }, TF);
    G('capas', CAPA.trace, 'Verification', TF);
    U('capas', CAPA.trace, { verification: 'New traveller template in use from 2026-04-01.' }, D);
    G('capas', CAPA.trace, 'Effectiveness review', D);
    at('2026-05-20');
    U('capas', CAPA.trace, { effectivenessResult: 'Effective', effectivenessEvidence: 'Sample of 30 travellers in May: 30/30 with lot number at deburr.' }, D);
    GA('capas', CAPA.trace, 'Closed', D, S);
    GA('audits', AUD.prod, 'Closed', P.aisha, D);

    at('2026-09-14');
    AUD.cal = C('audits', { title: 'Monitoring and measuring resources audit', auditType: 'Process', process: PRC.maint, clauses: '7.1.5', leadAuditor: P.aisha, auditee: P.luis, plannedDate: '2026-09-22', scope: 'Calibration register, status labels, out-of-tolerance handling.' }, D);
    at('2026-09-22');
    G('audits', AUD.cal, 'In progress', P.aisha);

    /* Height gauge fails calibration -> NCR -> CAPA in effectiveness review */
    at('2026-09-23');
    const calFail = cal(EQ.hg, '2026-09-23', 'MCL-26-1544', 'Fail', 'As-found error +0.021 mm at 450 mm (limit ±0.005 mm). Column damage suspected.', 'Height gauge used for BK-118 hole position checks since last cal (2025-12-02). Reviewed 41 lots: CMM data available for 38 lots; 3 lots re-measured from retained samples, all conforming. No product recall needed.');
    NCR.hg = C('ncrs', { title: 'Height gauge HG-0003 out of tolerance at calibration', detectedDate: '2026-09-23', detectedAt: 'Calibration', partNumber: 'Gauge HG-0003', qtyAffected: 1, severity: 'Major', description: 'As-found error +0.021 mm. Gauge removed from service; impact on product assessed in calibration record.', calibration: calFail, owner: P.luis, dueDate: '2026-10-02' }, P.luis);
    G('equipment', EQ.hg, 'Out of service', P.luis, 'Failed calibration MCL-26-1544');
    GA('calibrations', calFail, 'Approved', P.luis, D);
    CAPA.hg = C('capas', { title: 'Height gauge damaged in use; out-of-tolerance not detected between calibrations', source: 'Calibration failure', priority: 'Medium', owner: P.luis, process: PRC.maint, openedDate: '2026-09-24', dueDate: '2026-11-30', problem: 'HG-0003 found +0.021 mm out at annual calibration. Damage likely occurred months earlier; no interim check exists to detect it.' }, P.luis);
    U('ncrs', NCR.hg, { capa: CAPA.hg }, P.luis);
    closeNcr(NCR.hg, P.luis, 'Repair', 'Returned to Metrix for column replacement; recalibration required before use.');
    G('capas', CAPA.hg, 'Containment', P.luis);
    U('capas', CAPA.hg, { containment: 'Gauge quarantined; BK-118 hole checks moved to CMM; product impact assessment completed (no escapes).' }, P.luis);
    G('capas', CAPA.hg, 'Root cause', P.luis);
    at('2026-09-30');
    U('capas', CAPA.hg, { rootCauseMethod: 'Cause-and-effect diagram', rootCause: 'Gauge stored on open bench edge and knocked over (operator interview). No intermediate check with gauge blocks between annual calibrations.' }, P.luis);
    G('capas', CAPA.hg, 'Action plan', P.luis);
    U('capas', CAPA.hg, { actions: [
      { action: 'Install dedicated gauge cabinet in inspection lab', owner: P.luis, due: '2026-10-15', status: 'Open' },
      { action: 'Add weekly gauge-block check for height gauges to QP-715', owner: P.luis, due: '2026-10-20', status: 'Open' }] }, P.luis);
    GA('capas', CAPA.hg, 'Implementation', P.luis, D);
    at('2026-10-02');
    calOK(EQ.hg, '2026-10-02', 'MCL-26-1601', 'Pass', 'After column replacement: within ±0.003 mm');
    G('equipment', EQ.hg, 'In service', P.luis);
    at('2026-10-19');
    U('capas', CAPA.hg, { actions: [
      { action: 'Install dedicated gauge cabinet in inspection lab', owner: P.luis, due: '2026-10-15', status: 'Done', completedOn: '2026-10-12' },
      { action: 'Add weekly gauge-block check for height gauges to QP-715', owner: P.luis, due: '2026-10-20', status: 'Done', completedOn: '2026-10-19' }] }, P.luis);
    G('capas', CAPA.hg, 'Verification', P.luis);
    U('capas', CAPA.hg, { verification: 'Cabinet installed; weekly check log started 2026-10-19 (QP-715 rev B).' }, D);
    G('capas', CAPA.hg, 'Effectiveness review', D);
    U('capas', CAPA.hg, { effectivenessDue: '2026-12-18' }, D);
    // QP-715 revision B
    G('documents', DOC.cal, 'Draft', P.luis, 'CAPA-0003 action 2');
    U('documents', DOC.cal, { capa: CAPA.hg, changeSummary: 'Added weekly gauge-block verification for height gauges and storage requirement. Ref CAPA-0003.' }, P.luis);
    GA('documents', DOC.cal, 'Effective', P.luis, D);

    // Audit of calibration area records a finding -> CAPA in implementation
    at('2026-09-25');
    U('audits', AUD.cal, { actualDate: '2026-09-22', summary: 'Register complete and labels correct. Minor NC: torque wrench TW-0033 calibration due 2026-10-07 has no booking with provider; two other gauges were booked late in 2026.' }, P.aisha);
    CAPA.sched = C('capas', { title: 'Calibration bookings made late; risk of overdue gauges', source: 'Internal audit', priority: 'Medium', owner: P.luis, process: PRC.maint, openedDate: '2026-09-25', dueDate: '2026-11-20', problem: 'Calibration bookings rely on monthly manual review; TW-0033 not booked two weeks before due date.' }, P.aisha);
    U('audits', AUD.cal, { findings: [{ type: 'Minor NC', clause: '7.1.5.2', description: 'Calibration bookings late; TW-0033 not scheduled', capa: CAPA.sched }, { type: 'Observation', clause: '7.1.5.1', description: 'Status labels on pin gauge case worn but legible' }] }, P.aisha);
    G('audits', AUD.cal, 'Report issued', P.aisha);
    G('capas', CAPA.sched, 'Containment', P.luis);
    U('capas', CAPA.sched, { containment: 'Reviewed register for all items due in next 60 days; booked 3 with Metrix.' }, P.luis);
    G('capas', CAPA.sched, 'Root cause', P.luis);
    U('capas', CAPA.sched, { rootCauseMethod: '5 Whys', rootCause: 'Booking lead time at Metrix grew from 1 to 4 weeks in 2026; review cadence (monthly) was never adjusted.' }, P.luis);
    G('capas', CAPA.sched, 'Action plan', P.luis);
    U('capas', CAPA.sched, { actions: [
      { action: 'Use the QMS due list (30-day horizon) in the weekly maintenance meeting', owner: P.luis, due: '2026-10-09', status: 'Done', completedOn: '2026-10-08' },
      { action: 'Agree standing quarterly booking slots with Metrix', owner: P.helen, due: '2026-11-13', status: 'Open' }] }, P.luis);
    GA('capas', CAPA.sched, 'Implementation', P.luis, D);

    /* Supplier anodizing problem -> NCR -> CAPA at root cause; supplier conditional */
    at('2026-10-06');
    const bkIns = C('inspections', { plan: IPL.bk, inspDate: '2026-10-06', lot: 'BK-26-0931', inspector: P.jordan, qtyInspected: 5, qtyRejected: 5, notes: 'Thickness 28-31 µm on all 5 samples; Ø6.00 holes undersize after coating.' }, P.jordan);
    NCR.anod = C('ncrs', { title: 'BK-118 anodize thickness over limit (Corvane lot)', detectedDate: '2026-10-06', detectedAt: 'Receiving inspection', partNumber: 'BK-118', lot: 'BK-26-0931', qtyAffected: 400, severity: 'Major', description: 'Coating 28-31 µm vs 10-25 µm; holes undersize, pins do not enter.', supplier: SUP.corvane, inspection: bkIns, owner: P.helen, dueDate: '2026-10-16' }, P.jordan);
    G('inspections', bkIns, 'Rejected', P.jordan);
    att('ncrs', NCR.anod, 'thickness_readings_BK-26-0931.txt', 'Sample,Thickness µm\n1,28.4\n2,29.9\n3,31.2\n4,28.8\n5,30.1', P.jordan);
    G('ncrs', NCR.anod, 'Under review', P.helen);
    U('ncrs', NCR.anod, { disposition: 'Return to supplier', dispositionNotes: 'Return lot to Corvane for strip and re-anodize at their cost; expedite requested.' }, P.helen);
    GA('ncrs', NCR.anod, 'Dispositioned', P.helen, D);
    CAPA.anod = C('capas', { title: 'Supplier coating thickness out of specification', source: 'Supplier issue', priority: 'High', owner: P.helen, process: PRC.purch, openedDate: '2026-10-07', dueDate: '2026-12-15', problem: 'Corvane lot BK-26-0931 anodize 28-31 µm (limit 25). Second thickness issue from this supplier in 2026.' }, P.helen);
    U('ncrs', NCR.anod, { capa: CAPA.anod }, P.helen);
    G('ncrs', NCR.anod, 'Closed', P.helen);
    U('capas', CAPA.anod, { risks: [RK.anod] }, P.helen);
    G('capas', CAPA.anod, 'Containment', P.helen);
    U('capas', CAPA.anod, { containment: '100% thickness check on next 3 Corvane lots; SCAR issued to Corvane 2026-10-08.' }, P.helen);
    G('capas', CAPA.anod, 'Root cause', P.helen);
    note('capas', CAPA.anod, P.helen, 'Waiting for Corvane 8D. They report a rectifier controller fault; requested evidence of tank time logs.');
    at('2026-10-14');
    ev(SUP.corvane, '2026 Q3 review', '2026-10-14', 62, 80, 75, 18000, 'Two thickness escapes in 2026; SCAR open.');
    G('suppliers', SUP.corvane, 'Conditional', P.helen, 'Conditional pending SCAR closure and 3 clean lots.');
    A('suppliers', SUP.corvane, D, 'Agreed — conditional status until CAPA-0005 closed.');

    /* CAPA with failed effectiveness -> loop back, now awaiting action plan approval */
    at('2026-05-11');
    NCR.burr = C('ncrs', { title: 'Burrs in cross-drilled holes, HX-2210', detectedDate: '2026-05-11', detectedAt: 'In-process', partNumber: 'HX-2210', lot: 'L2605-113', qtyAffected: 18, severity: 'Major', description: 'Burrs at intersection of cross-drilled holes found at wash station; risk of contamination in hydraulic circuit.', owner: TF, dueDate: '2026-05-21' }, P.kevin);
    CAPA.burr = C('capas', { title: 'Internal burrs at cross-hole intersections', source: 'Nonconformance', priority: 'Medium', owner: TF, process: PRC.cnc, openedDate: '2026-05-12', dueDate: '2026-09-30', problem: 'Recurring burrs at cross-drilled hole intersections on HX-2210 (3 occurrences Feb-May).' }, TF);
    U('ncrs', NCR.burr, { capa: CAPA.burr }, TF);
    closeNcr(NCR.burr, TF, 'Rework', 'Manual deburr with flexible brush; 100% borescope inspection.');
    G('capas', CAPA.burr, 'Containment', TF);
    U('capas', CAPA.burr, { containment: 'Added 100% borescope check of cross holes at wash.' }, TF);
    G('capas', CAPA.burr, 'Root cause', TF);
    U('capas', CAPA.burr, { rootCauseMethod: '5 Whys', rootCause: 'Manual deburr depends on operator technique; no defined tool or check.' }, TF);
    G('capas', CAPA.burr, 'Action plan', TF);
    U('capas', CAPA.burr, { actions: [{ action: 'Define brush type and passes in deburr instruction', owner: TF, due: '2026-06-05', status: 'Open' }] }, TF);
    GA('capas', CAPA.burr, 'Implementation', TF, D);
    at('2026-06-05');
    U('capas', CAPA.burr, { actions: [{ action: 'Define brush type and passes in deburr instruction', owner: TF, due: '2026-06-05', status: 'Done', completedOn: '2026-06-05' }] }, TF);
    G('capas', CAPA.burr, 'Verification', TF);
    U('capas', CAPA.burr, { verification: 'Instruction posted at deburr bench; operators briefed.' }, D);
    G('capas', CAPA.burr, 'Effectiveness review', D);
    at('2026-08-17');
    U('capas', CAPA.burr, { effectivenessResult: 'Not effective', effectivenessEvidence: 'Burrs found again on lots L2607-116 and L2608-117 (borescope).' }, D);
    G('capas', CAPA.burr, 'Root cause', D, 'Recurrence after action; manual method still technique-dependent. Reinvestigate.');
    at('2026-08-24');
    U('capas', CAPA.burr, { rootCause: 'Manual deburr cannot reach the far side of the intersection reliably. Program uses a drill exit at full feed, producing a large exit burr that manual methods do not fully remove.', rootCauseMethod: 'Fault tree' }, TF);
    G('capas', CAPA.burr, 'Action plan', TF);
    U('capas', CAPA.burr, { dueDate: '2026-12-18', actions: [
      { action: 'Reduce feed 50% for final 1 mm of cross-hole drill exit (program change HX2210_OP20 rev F)', owner: TF, due: '2026-12-04', status: 'Open' },
      { action: 'Add back-deburr tool cycle in OP20', owner: TF, due: '2026-12-11', status: 'Open' },
      { action: 'Borescope 100% for 5 lots then return to sample', owner: PR, due: '2026-12-18', status: 'Open' }] }, TF, 'Revised plan after failed effectiveness check');
    at('2026-11-24');
    G('capas', CAPA.burr, 'Implementation', TF);

    /* New, overdue open CAPA (in containment) from a recent complaint */
    at('2026-10-20');
    CMP.pack = C('complaints', { title: 'Parts scratched in transit', customer: 'Norvell Instruments', contact: 'J. Varga, Purchasing', receivedDate: '2026-10-20', channel: 'Email', partNumber: 'BK-118', lot: 'BK-26-0907', category: 'Packaging', severity: 'Minor', description: '30 brackets with scratches on anodized face; cartons arrived crushed on one corner.', owner: M, responseDue: '2026-11-03' }, P.owen);
    G('complaints', CMP.pack, 'Investigation', M);
    at('2026-11-05');
    CAPA.pack = C('capas', { title: 'Packaging does not protect anodized faces in transit', source: 'Customer complaint', priority: 'Low', owner: M, process: PRC.ship, openedDate: '2026-11-05', dueDate: '2026-11-25', problem: 'Single-wall cartons with loose fill allow parts to contact each other.' }, M);
    U('complaints', CMP.pack, { capa: CAPA.pack }, M);
    G('capas', CAPA.pack, 'Containment', M);
    at('2026-11-09');
    CMP.doc = C('complaints', { title: 'Certificate of conformity missing heat number', customer: 'Aldane Fluid Systems', contact: 'R. Okafor, Supplier Quality', receivedDate: '2026-11-09', channel: 'Portal', partNumber: 'HX-2210', lot: 'L2611-120', category: 'Documentation', severity: 'Minor', description: 'CoC lists material grade but not the heat number.', owner: PR, responseDue: '2026-11-23' }, P.owen);
    at('2026-11-12');
    // November rejects NCR still open
    G('ncrs', NCR.ins11, 'Under review', PR);

    /* ---------------- supplier Brightpack pending; second ridgeline eval ---------------- */
    at('2026-11-16');
    C('supplierEvals', { supplier: SUP.brite, period: 'Initial qualification', evaluator: P.helen, evalDate: '2026-11-16', qualityScore: 85, deliveryScore: 90, responsivenessScore: 88, ppm: 0, comments: 'Sample cartons passed drop test; awaiting completion sign-off.' }, P.helen);

    /* ---------------- WI-INS-003 revision -> retraining needed for Nina ---------------- */
    at('2026-10-26');
    G('documents', DOC.wi3, 'Draft', PR, 'Add visual criteria for anodized faces');
    U('documents', DOC.wi3, { changeSummary: 'Added visual acceptance criteria and lighting requirement for anodized faces.' }, PR);
    GA('documents', DOC.wi3, 'Effective', PR, D);
    trn(P.jordan, 'WI-INS-003 rev B visual criteria', DOC.wi3, 'Classroom', '2026-10-28', '2026-11-13', '2026-11-04', PR, 'Graded 10 boundary samples correctly.');
    trn(P.nina, 'WI-INS-003 rev B visual criteria', DOC.wi3, 'Classroom', '2026-10-28', '2026-11-13');

    /* Draft document under approval */
    at('2026-11-18');
    const docPack = C('documents', { docNumber: 'WI-SHP-002', title: 'Packaging of Anodized Components', docType: 'Work instruction', process: PRC.ship, owner: M, content: 'Double-wall cartons, individual foam cavities, no part-to-part contact, corner protectors.' }, M);
    G('documents', docPack, 'Effective', M);

    /* ---------------- management review ---------------- */
    at('2026-07-15');
    const topics = Core.REVIEW_INPUT_TOPICS;
    const mr1 = C('reviews', { title: 'Management review — mid-year 2026', scheduledDate: '2026-07-21', chair: S, inputs: topics.map(topic => ({ topic })) }, D);
    at('2026-07-21');
    U('reviews', mr1, { heldDate: '2026-07-21', attendees: 'S. Haddad (chair), D. Whitfield, M. Oyelaran, A. Mensah, H. Kowalski, T. Ferreira', inputs: [
      { topic: topics[0], summary: 'First review of 2026; no prior open actions.' },
      { topic: topics[1], summary: 'New hydraulic customer program expected Q4; 7075 lead times rising.' },
      { topic: topics[2], summary: 'One major complaint (CMP-0001) closed with 8D accepted.' },
      { topic: topics[3], summary: 'FPY trending up since April; complaints on target since April.' },
      { topic: topics[4], summary: 'Bore-related rejects eliminated after CAPA-0001.' },
      { topic: topics[5], summary: '2 CAPAs closed effective; 1 in effectiveness review.' },
      { topic: topics[7], summary: 'AUD-0001 closed; audit programme on schedule.' },
      { topic: topics[8], summary: 'Corvane coating drift remains a watch item.' },
      { topic: topics[9], summary: 'CMM capacity tight at month end.' },
      { topic: topics[11], summary: 'Spindle probing trial proposed.' }] }, D);
    G('reviews', mr1, 'Held', D);
    U('reviews', mr1, { decisions: [
      { decision: 'Approve capital request CR-26-07 for spindle probe trial', owner: M, due: '2026-09-30', status: 'Done' },
      { decision: 'Cross-train second CMM operator', owner: PR, due: '2026-10-31', status: 'Done' },
      { decision: 'Increase Corvane monitoring: thickness data with every lot', owner: P.helen, due: '2026-08-15', status: 'Done' }],
      conclusion: 'The QMS remains suitable, adequate and effective. Resource decisions recorded above.' }, D);
    GA('reviews', mr1, 'Minutes approved', D, S);
    at('2026-11-02');
    C('reviews', { title: 'Management review — year-end 2026', scheduledDate: '2026-12-15', chair: S, inputs: topics.map(topic => ({ topic })) }, D);

    /* ---------------- audits planned ---------------- */
    at('2026-08-03');
    C('audits', { title: 'Document control and records audit', auditType: 'System', process: PRC.qms, clauses: '7.5', leadAuditor: P.aisha, auditee: D, plannedDate: '2026-11-17', scope: 'Document approval, revision and access; record retention.' }, D);
    C('audits', { title: 'Purchasing and supplier control audit', auditType: 'Process', process: PRC.purch, clauses: '8.4', leadAuditor: D, auditee: P.helen, plannedDate: '2026-12-08', scope: 'Supplier approval, evaluation records, purchase order requirements.' }, D);

    /* ---------------- objective measurements ---------------- */
    at('2026-11-20');
    const per = ['2026-01', '2026-02', '2026-03', '2026-04', '2026-05', '2026-06', '2026-07', '2026-08', '2026-09', '2026-10'];
    const series = { cmp: [2, 1, 1, 0, 0, 0, 0, 0, 0, 1], fpy: [98.1, 97.8, 96.3, 97.4, 98.7, 99.1, 98.8, 99.2, 99.2, 98.8], otd: [90, 92, 88, 93, 94, 95, 96, 94, 96, 95], capa: [50, 50, 67, 67, 75, 75, 75, 75, 75, 75] };
    Object.keys(series).forEach(k => U('objectives', OBJ[k], { measurements: per.map((p, i) => ({ period: p, value: series[k][i] })) }, D));

    /* ---------------- open approval waiting for decision ---------------- */
    at('2026-11-25');
    store.setClock(() => new Date());
    return { P, CAPA, NCR, CMP, DOC, SUP, EQ, RK, AUD };
  }

  return { seed };
});
