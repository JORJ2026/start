/*
 * Offline QMS — core engine
 * Pure JavaScript, no dependencies. Runs in the browser (window.QMSCore) and in Node (module.exports).
 * Responsibilities: schema, validation, workflows + approvals, revision history (hash-chained),
 * relationships, integrity verification, CSV/JSON export, backup + restore, KPIs.
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.QMSCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  /* ------------------------------------------------------------------ SHA-256 */
  const K = new Uint32Array([
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2]);
  function utf8(str) {
    if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(str);
    return Uint8Array.from(Buffer.from(str, 'utf8'));
  }
  function sha256(input) {
    const msg = typeof input === 'string' ? utf8(input) : input;
    const l = msg.length, bitLenHi = Math.floor(l / 0x20000000), bitLenLo = (l << 3) >>> 0;
    const n = ((l + 9 + 63) >> 6) << 6;
    const buf = new Uint8Array(n); buf.set(msg); buf[l] = 0x80;
    const dv = new DataView(buf.buffer);
    dv.setUint32(n - 8, bitLenHi); dv.setUint32(n - 4, bitLenLo);
    const H = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
    const W = new Uint32Array(64);
    for (let off = 0; off < n; off += 64) {
      for (let i = 0; i < 16; i++) W[i] = dv.getUint32(off + i * 4);
      for (let i = 16; i < 64; i++) {
        const a = W[i - 15], b = W[i - 2];
        const s0 = ((a >>> 7) | (a << 25)) ^ ((a >>> 18) | (a << 14)) ^ (a >>> 3);
        const s1 = ((b >>> 17) | (b << 15)) ^ ((b >>> 19) | (b << 13)) ^ (b >>> 10);
        W[i] = (W[i - 16] + s0 + W[i - 7] + s1) | 0;
      }
      let a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
      for (let i = 0; i < 64; i++) {
        const S1 = ((e >>> 6) | (e << 26)) ^ ((e >>> 11) | (e << 21)) ^ ((e >>> 25) | (e << 7));
        const t1 = (h + S1 + ((e & f) ^ (~e & g)) + K[i] + W[i]) | 0;
        const S0 = ((a >>> 2) | (a << 30)) ^ ((a >>> 13) | (a << 19)) ^ ((a >>> 22) | (a << 10));
        const t2 = (S0 + ((a & b) ^ (a & c) ^ (b & c))) | 0;
        h = g; g = f; f = e; e = (d + t1) | 0; d = c; c = b; b = a; a = (t1 + t2) | 0;
      }
      H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
    }
    let out = '';
    for (let i = 0; i < 8; i++) out += H[i].toString(16).padStart(8, '0');
    return out;
  }

  /* ------------------------------------------------------------------ helpers */
  function canonical(v) {
    if (v === null || typeof v !== 'object') return JSON.stringify(v === undefined ? null : v);
    if (Array.isArray(v)) return '[' + v.map(canonical).join(',') + ']';
    return '{' + Object.keys(v).sort().filter(k => v[k] !== undefined)
      .map(k => JSON.stringify(k) + ':' + canonical(v[k])).join(',') + '}';
  }
  const clone = v => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
  const isEmpty = v => v === undefined || v === null || v === '' || (Array.isArray(v) && v.length === 0);
  const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
  function validDate(s) {
    if (!DATE_RE.test(s)) return false;
    const d = new Date(s + 'T00:00:00Z');
    return !isNaN(d) && d.toISOString().slice(0, 10) === s;
  }
  const isoDate = d => d.toISOString().slice(0, 10);
  function addDays(dateStr, days) {
    const d = new Date(dateStr + 'T00:00:00Z'); d.setUTCDate(d.getUTCDate() + Number(days)); return isoDate(d);
  }
  function daysBetween(a, b) { return Math.round((new Date(b + 'T00:00:00Z') - new Date(a + 'T00:00:00Z')) / 86400000); }
  function nextRev(rev) {
    if (!rev) return 'A';
    let s = rev.split(''), i = s.length - 1;
    while (i >= 0) { if (s[i] === 'Z') { s[i] = 'A'; i--; } else { s[i] = String.fromCharCode(s[i].charCodeAt(0) + 1); return s.join(''); } }
    return 'A' + s.join('');
  }
  class QMSError extends Error {
    constructor(msg, details) { super(msg); this.name = 'QMSError'; this.details = details || []; }
  }

  /* ------------------------------------------------------------------ schema */
  const f = (k, label, type, o) => Object.assign({ k, label, type: type || 'text' }, o || {});
  const OWNER = f('owner', 'Owner', 'ref', { ref: 'people', list: true });
  const PROCESS = f('process', 'Process', 'ref', { ref: 'processes' });
  const SEV = ['Minor', 'Major', 'Critical'];
  const LS = ['1', '2', '3', '4', '5'];

  function riskRating(score) { return score >= 16 ? 'Critical' : score >= 10 ? 'High' : score >= 5 ? 'Medium' : 'Low'; }

  const ENTITIES = {
    people: {
      label: 'Person', plural: 'People', prefix: 'PER', group: 'Administration', clause: '7.1.2 / 7.2', titleField: 'name',
      fields: [
        f('name', 'Full name', 'text', { required: true, list: true }),
        f('jobTitle', 'Job title', 'text', { list: true }),
        f('department', 'Department', 'select', { options: ['Quality', 'Operations', 'Engineering', 'Purchasing', 'Sales', 'Executive', 'Maintenance'], list: true }),
        f('email', 'Email', 'email'),
        f('canApprove', 'Approval authority', 'select', { options: ['No', 'Yes'], list: true, default: 'No' }),
        f('isAdmin', 'System administrator', 'select', { options: ['No', 'Yes'], default: 'No' })
      ],
      workflow: { initial: 'Active', states: ['Active', 'Inactive'], terminal: [], transitions: [
        { from: ['Active'], to: 'Inactive', label: 'Deactivate', comment: true },
        { from: ['Inactive'], to: 'Active', label: 'Reactivate' }] },
      lockedStates: []
    },
    processes: {
      label: 'Process', plural: 'Processes', prefix: 'PRC', group: 'Planning', clause: '4.4', titleField: 'name',
      fields: [
        f('name', 'Process name', 'text', { required: true, list: true }),
        OWNER,
        f('purpose', 'Purpose', 'textarea'),
        f('inputs', 'Inputs', 'textarea'),
        f('outputs', 'Outputs', 'textarea'),
        f('measures', 'Performance measures', 'textarea')
      ],
      workflow: { initial: 'Active', states: ['Active', 'Retired'], terminal: ['Retired'], transitions: [
        { from: ['Active'], to: 'Retired', label: 'Retire', approval: true, comment: true }] },
      lockedStates: ['Retired']
    },
    documents: {
      label: 'Document', plural: 'Documents', prefix: 'DOC', group: 'Support', clause: '7.5', titleField: 'title',
      fields: [
        f('docNumber', 'Document number', 'text', { required: true, unique: true, list: true }),
        f('title', 'Title', 'text', { required: true, list: true }),
        f('docType', 'Type', 'select', { options: ['Quality manual', 'Policy', 'Procedure', 'Work instruction', 'Form', 'Specification', 'Record template'], required: true, list: true }),
        f('revision', 'Revision', 'text', { readonly: true, list: true }),
        PROCESS, OWNER,
        f('changeSummary', 'Change summary', 'textarea'),
        f('capa', 'Change driven by CAPA', 'ref', { ref: 'capas' }),
        f('content', 'Content / scope', 'textarea'),
        f('reviewIntervalMonths', 'Review interval (months)', 'number', { min: 1, max: 60, default: 24 }),
        f('effectiveDate', 'Effective date', 'date', { readonly: true, list: true }),
        f('nextReview', 'Next review', 'date', { readonly: true })
      ],
      workflow: { initial: 'Draft', states: ['Draft', 'Effective', 'Obsolete'], terminal: ['Obsolete'], transitions: [
        { from: ['Draft'], to: 'Effective', label: 'Submit for approval', approval: true, requires: ['owner', 'content'],
          guard: r => (r.data.revision !== 'A' && isEmpty(r.data.changeSummary)) ? 'A change summary is required for revisions after A.' : null,
          effect: (r, c) => {
            r.data.effectiveDate = c.today;
            const m = Number(r.data.reviewIntervalMonths || 24);
            const d = new Date(c.today + 'T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + m); r.data.nextReview = isoDate(d);
            r.revisions = r.revisions || [];
            r.revisions.push({ revision: r.data.revision, effectiveDate: c.today, approvedBy: c.approver || c.user, changeSummary: r.data.changeSummary || 'Initial release', contentHash: sha256(r.data.content || '') });
          } },
        { from: ['Effective'], to: 'Draft', label: 'Start revision', comment: true,
          effect: r => { r.data.revision = nextRev(r.data.revision); r.data.changeSummary = ''; r.data.effectiveDate = ''; } },
        { from: ['Effective', 'Draft'], to: 'Obsolete', label: 'Make obsolete', approval: true, comment: true }] },
      lockedStates: ['Effective', 'Obsolete'],
      onCreate: r => { r.data.revision = 'A'; },
      due: r => r.status === 'Effective' && r.data.nextReview ? { date: r.data.nextReview, label: 'Periodic review' } : null
    },
    audits: {
      label: 'Internal audit', plural: 'Internal audits', prefix: 'AUD', group: 'Evaluation', clause: '9.2', titleField: 'title',
      fields: [
        f('title', 'Audit title', 'text', { required: true, list: true }),
        f('auditType', 'Audit type', 'select', { options: ['Process', 'System', 'Product', 'Layered process'], required: true }),
        PROCESS,
        f('clauses', 'Requirement areas (clause refs)', 'text'),
        f('leadAuditor', 'Lead auditor', 'ref', { ref: 'people', required: true, list: true }),
        f('auditee', 'Auditee', 'ref', { ref: 'people' }),
        f('plannedDate', 'Planned date', 'date', { required: true, list: true }),
        f('actualDate', 'Actual date', 'date'),
        f('scope', 'Scope and criteria', 'textarea'),
        f('summary', 'Summary of results', 'textarea'),
        f('findings', 'Findings', 'table', { columns: [
          f('type', 'Type', 'select', { options: ['Major NC', 'Minor NC', 'Observation', 'Opportunity'] }),
          f('clause', 'Clause', 'text'),
          f('description', 'Finding', 'text'),
          f('capa', 'CAPA', 'ref', { ref: 'capas' })] })
      ],
      workflow: { initial: 'Planned', states: ['Planned', 'In progress', 'Report issued', 'Closed', 'Cancelled'], terminal: ['Closed', 'Cancelled'], transitions: [
        { from: ['Planned'], to: 'In progress', label: 'Start audit', effect: (r, c) => { if (!r.data.actualDate) r.data.actualDate = c.today; } },
        { from: ['In progress'], to: 'Report issued', label: 'Issue report', requires: ['actualDate', 'summary'] },
        { from: ['Report issued'], to: 'Closed', label: 'Close audit', approval: true,
          guard: r => (r.data.findings || []).some(x => /NC$/.test(x.type) && !x.capa) ? 'Every nonconformity finding must be linked to a CAPA before closure.' : null },
        { from: ['Planned'], to: 'Cancelled', label: 'Cancel', comment: true, approval: true }] },
      lockedStates: ['Closed', 'Cancelled'],
      due: r => r.status === 'Planned' ? { date: r.data.plannedDate, label: 'Audit planned' } : null
    },
    capas: {
      label: 'Corrective action', plural: 'Corrective actions', prefix: 'CAPA', group: 'Improvement', clause: '10.2', titleField: 'title',
      fields: [
        f('title', 'Title', 'text', { required: true, list: true }),
        f('source', 'Source', 'select', { options: ['Customer complaint', 'Nonconformance', 'Internal audit', 'Supplier issue', 'Risk review', 'Management review', 'Calibration failure'], required: true, list: true }),
        f('priority', 'Priority', 'select', { options: ['Low', 'Medium', 'High'], required: true, list: true, default: 'Medium' }),
        OWNER, PROCESS,
        f('openedDate', 'Opened', 'date', { required: true }),
        f('dueDate', 'Target closure', 'date', { required: true, list: true }),
        f('problem', 'Problem statement', 'textarea', { required: true }),
        f('containment', 'Containment actions', 'textarea'),
        f('rootCauseMethod', 'Root cause method', 'select', { options: ['5 Whys', 'Cause-and-effect diagram', 'Fault tree', 'Is / Is-not', 'Other'] }),
        f('rootCause', 'Root cause', 'textarea'),
        f('actions', 'Action plan', 'table', { columns: [
          f('action', 'Action', 'text'),
          f('owner', 'Owner', 'ref', { ref: 'people' }),
          f('due', 'Due', 'date'),
          f('status', 'Status', 'select', { options: ['Open', 'Done'] }),
          f('completedOn', 'Completed', 'date')] }),
        f('risks', 'Risk register entries updated', 'refs', { ref: 'risks' }),
        f('verification', 'Implementation verification', 'textarea'),
        f('effectivenessDue', 'Effectiveness check due', 'date'),
        f('effectivenessResult', 'Effectiveness result', 'select', { options: ['Effective', 'Not effective'] }),
        f('effectivenessEvidence', 'Effectiveness evidence', 'textarea')
      ],
      workflow: { initial: 'Open', states: ['Open', 'Containment', 'Root cause', 'Action plan', 'Implementation', 'Verification', 'Effectiveness review', 'Closed', 'Cancelled'], terminal: ['Closed', 'Cancelled'], transitions: [
        { from: ['Open'], to: 'Containment', label: 'Begin containment', requires: ['owner', 'problem'] },
        { from: ['Containment'], to: 'Root cause', label: 'Containment complete', requires: ['containment'] },
        { from: ['Root cause'], to: 'Action plan', label: 'Root cause identified', requires: ['rootCauseMethod', 'rootCause'] },
        { from: ['Action plan'], to: 'Implementation', label: 'Approve action plan', approval: true, requires: ['actions'],
          guard: r => (r.data.actions || []).some(a => !a.action || !a.owner || !a.due) ? 'Each action needs a description, owner and due date.' : null },
        { from: ['Implementation'], to: 'Verification', label: 'Actions complete',
          guard: r => (r.data.actions || []).some(a => a.status !== 'Done' || !a.completedOn) ? 'All actions must be Done with a completion date.' : null },
        { from: ['Verification'], to: 'Effectiveness review', label: 'Implementation verified', requires: ['verification'],
          effect: (r, c) => { if (!r.data.effectivenessDue) r.data.effectivenessDue = addDays(c.today, 60); } },
        { from: ['Effectiveness review'], to: 'Closed', label: 'Close as effective', approval: true, requires: ['effectivenessEvidence'],
          guard: r => r.data.effectivenessResult !== 'Effective' ? 'Effectiveness result must be "Effective" to close.' : null },
        { from: ['Effectiveness review'], to: 'Root cause', label: 'Not effective — reinvestigate', comment: true,
          guard: r => r.data.effectivenessResult !== 'Not effective' ? 'Set the effectiveness result to "Not effective" first.' : null,
          effect: r => { r.data.effectivenessResult = ''; r.data.effectivenessDue = ''; } },
        { from: ['Open', 'Containment', 'Root cause', 'Action plan'], to: 'Cancelled', label: 'Cancel', approval: true, comment: true }] },
      lockedStates: ['Closed', 'Cancelled'],
      due: r => {
        if (['Closed', 'Cancelled'].includes(r.status)) return null;
        if (r.status === 'Effectiveness review' && r.data.effectivenessDue) return { date: r.data.effectivenessDue, label: 'Effectiveness check' };
        return { date: r.data.dueDate, label: 'Target closure' };
      }
    },
    ncrs: {
      label: 'Nonconformance', plural: 'Nonconformances', prefix: 'NCR', group: 'Operation', clause: '8.7', titleField: 'title',
      fields: [
        f('title', 'Title', 'text', { required: true, list: true }),
        f('detectedDate', 'Detected', 'date', { required: true, list: true }),
        f('detectedAt', 'Detection point', 'select', { options: ['Receiving inspection', 'In-process', 'Final inspection', 'Customer', 'Internal audit', 'Calibration'], required: true, list: true }),
        f('partNumber', 'Part / product', 'text', { required: true }),
        f('lot', 'Lot / batch', 'text'),
        f('qtyAffected', 'Quantity affected', 'number', { min: 0 }),
        f('severity', 'Severity', 'select', { options: SEV, required: true, list: true }),
        f('description', 'Description', 'textarea', { required: true }),
        f('supplier', 'Supplier', 'ref', { ref: 'suppliers' }),
        f('complaint', 'Customer complaint', 'ref', { ref: 'complaints' }),
        f('inspection', 'Inspection record', 'ref', { ref: 'inspections' }),
        f('calibration', 'Calibration record', 'ref', { ref: 'calibrations' }),
        OWNER,
        f('disposition', 'Disposition', 'select', { options: ['Rework', 'Repair', 'Scrap', 'Return to supplier', 'Use as is (concession)'] }),
        f('dispositionNotes', 'Disposition rationale', 'textarea'),
        f('capa', 'CAPA', 'ref', { ref: 'capas', list: true }),
        f('dueDate', 'Disposition due', 'date')
      ],
      workflow: { initial: 'Open', states: ['Open', 'Under review', 'Dispositioned', 'Closed', 'Cancelled'], terminal: ['Closed', 'Cancelled'], transitions: [
        { from: ['Open'], to: 'Under review', label: 'Start review', requires: ['owner'] },
        { from: ['Under review'], to: 'Dispositioned', label: 'Record disposition', requires: ['disposition', 'dispositionNotes'],
          approval: r => r.data.disposition === 'Use as is (concession)' || r.data.severity === 'Critical' },
        { from: ['Dispositioned'], to: 'Closed', label: 'Close',
          guard: r => (r.data.severity !== 'Minor' && !r.data.capa) ? 'Major and critical nonconformances need a linked CAPA before closure.' : null },
        { from: ['Open', 'Under review'], to: 'Cancelled', label: 'Cancel (raised in error)', comment: true, approval: true }] },
      lockedStates: ['Closed', 'Cancelled'],
      due: r => ['Open', 'Under review'].includes(r.status) && r.data.dueDate ? { date: r.data.dueDate, label: 'Disposition' } : null
    },
    complaints: {
      label: 'Customer complaint', plural: 'Customer complaints', prefix: 'CMP', group: 'Operation', clause: '8.2.1 / 9.1.2', titleField: 'title',
      fields: [
        f('title', 'Title', 'text', { required: true, list: true }),
        f('customer', 'Customer', 'text', { required: true, list: true }),
        f('contact', 'Customer contact', 'text'),
        f('receivedDate', 'Received', 'date', { required: true, list: true }),
        f('channel', 'Channel', 'select', { options: ['Email', 'Phone', 'Portal', 'Field visit', 'Returned goods'] }),
        f('partNumber', 'Part / product', 'text'),
        f('lot', 'Lot / batch', 'text'),
        f('category', 'Category', 'select', { options: ['Dimensional', 'Cosmetic', 'Functional', 'Delivery', 'Documentation', 'Packaging'], required: true }),
        f('severity', 'Severity', 'select', { options: SEV, required: true, list: true }),
        f('description', 'Customer description', 'textarea', { required: true }),
        OWNER,
        f('responseDue', 'Response due', 'date', { required: true }),
        f('investigation', 'Investigation summary', 'textarea'),
        f('response', 'Response to customer', 'textarea'),
        f('responseDate', 'Response sent', 'date'),
        f('capa', 'CAPA', 'ref', { ref: 'capas', list: true }),
        f('satisfaction', 'Customer accepted response', 'select', { options: ['Yes', 'No', 'No reply'] })
      ],
      workflow: { initial: 'Received', states: ['Received', 'Investigation', 'Response sent', 'Closed', 'Cancelled'], terminal: ['Closed', 'Cancelled'], transitions: [
        { from: ['Received'], to: 'Investigation', label: 'Start investigation', requires: ['owner'] },
        { from: ['Investigation'], to: 'Response sent', label: 'Send response', requires: ['investigation', 'response'],
          effect: (r, c) => { if (!r.data.responseDate) r.data.responseDate = c.today; } },
        { from: ['Response sent'], to: 'Closed', label: 'Close', requires: ['satisfaction'], approval: true,
          guard: r => (r.data.severity !== 'Minor' && !r.data.capa) ? 'Major and critical complaints need a linked CAPA.' : null },
        { from: ['Received'], to: 'Cancelled', label: 'Cancel (not a complaint)', comment: true, approval: true }] },
      lockedStates: ['Closed', 'Cancelled'],
      due: r => ['Received', 'Investigation'].includes(r.status) ? { date: r.data.responseDue, label: 'Customer response' } : null
    },
    risks: {
      label: 'Risk / opportunity', plural: 'Risk register', prefix: 'RSK', group: 'Planning', clause: '6.1', titleField: 'title',
      fields: [
        f('title', 'Title', 'text', { required: true, list: true }),
        f('kind', 'Type', 'select', { options: ['Risk', 'Opportunity'], required: true, default: 'Risk', list: true }),
        PROCESS,
        f('description', 'Description', 'textarea', { required: true }),
        f('likelihood', 'Likelihood (1-5)', 'select', { options: LS, required: true }),
        f('severity', 'Impact (1-5)', 'select', { options: LS, required: true }),
        f('controls', 'Existing controls', 'textarea'),
        f('treatment', 'Treatment plan', 'textarea'),
        OWNER,
        f('reviewDate', 'Next review', 'date', { required: true, list: true }),
        f('residualLikelihood', 'Residual likelihood', 'select', { options: LS }),
        f('residualSeverity', 'Residual impact', 'select', { options: LS })
      ],
      workflow: { initial: 'Open', states: ['Open', 'Treatment', 'Monitoring', 'Closed'], terminal: ['Closed'], transitions: [
        { from: ['Open'], to: 'Treatment', label: 'Plan treatment', requires: ['treatment', 'owner'] },
        { from: ['Treatment'], to: 'Monitoring', label: 'Treatment implemented', requires: ['residualLikelihood', 'residualSeverity'] },
        { from: ['Monitoring'], to: 'Treatment', label: 'Re-treat', comment: true },
        { from: ['Open', 'Monitoring'], to: 'Closed', label: 'Close', approval: true, comment: true }] },
      lockedStates: ['Closed'],
      derive: r => {
        const s = Number(r.data.likelihood || 0) * Number(r.data.severity || 0);
        const rs = Number(r.data.residualLikelihood || 0) * Number(r.data.residualSeverity || 0);
        return { score: s, rating: s ? riskRating(s) : '', residualScore: rs || '', residualRating: rs ? riskRating(rs) : '' };
      },
      derivedList: [['score', 'Score'], ['rating', 'Rating']],
      due: r => r.status !== 'Closed' ? { date: r.data.reviewDate, label: 'Risk review' } : null
    },
    suppliers: {
      label: 'Supplier', plural: 'Suppliers', prefix: 'SUP', group: 'Operation', clause: '8.4', titleField: 'name',
      fields: [
        f('name', 'Supplier name', 'text', { required: true, unique: true, list: true }),
        f('category', 'Category', 'select', { options: ['Raw material', 'Machined components', 'Surface treatment', 'Heat treatment', 'Calibration service', 'Packaging', 'Logistics'], required: true, list: true }),
        f('criticality', 'Criticality', 'select', { options: ['Low', 'Medium', 'High'], required: true, list: true }),
        f('scope', 'Scope of supply', 'textarea'),
        f('contact', 'Contact', 'text'),
        f('certifications', 'Certifications held', 'text'),
        f('evalIntervalMonths', 'Evaluation interval (months)', 'number', { min: 1, max: 36, default: 12 }),
        f('nextEvaluation', 'Next evaluation', 'date', { list: true })
      ],
      workflow: { initial: 'Pending', states: ['Pending', 'Approved', 'Conditional', 'Disapproved'], terminal: [], transitions: [
        { from: ['Pending', 'Conditional'], to: 'Approved', label: 'Approve supplier', approval: true, guard: (r, db) => db.related('suppliers', r.id).some(x => x.entity === 'supplierEvals' && x.record.status === 'Completed') ? null : 'At least one completed evaluation is required.' },
        { from: ['Pending', 'Approved'], to: 'Conditional', label: 'Set conditional', approval: true, comment: true },
        { from: ['Pending', 'Approved', 'Conditional'], to: 'Disapproved', label: 'Disapprove', approval: true, comment: true },
        { from: ['Disapproved'], to: 'Pending', label: 'Re-evaluate', comment: true }] },
      lockedStates: [],
      derive: (r, db) => {
        const ev = db.list('supplierEvals').filter(e => e.data.supplier === r.id && e.status === 'Completed').sort((a, b) => (a.data.evalDate < b.data.evalDate ? 1 : -1))[0];
        return { lastScore: ev ? ENTITIES.supplierEvals.derive(ev).overall : '', lastGrade: ev ? ENTITIES.supplierEvals.derive(ev).grade : '' };
      },
      derivedList: [['lastScore', 'Score'], ['lastGrade', 'Grade']],
      due: r => r.status !== 'Disapproved' && r.data.nextEvaluation ? { date: r.data.nextEvaluation, label: 'Supplier evaluation' } : null
    },
    supplierEvals: {
      label: 'Supplier evaluation', plural: 'Supplier evaluations', prefix: 'SEV', group: 'Operation', clause: '8.4.1', titleField: 'period',
      fields: [
        f('supplier', 'Supplier', 'ref', { ref: 'suppliers', required: true, list: true }),
        f('period', 'Period', 'text', { required: true, list: true }),
        f('evaluator', 'Evaluator', 'ref', { ref: 'people', required: true }),
        f('evalDate', 'Evaluation date', 'date', { required: true, list: true }),
        f('qualityScore', 'Quality score (0-100)', 'number', { min: 0, max: 100, required: true }),
        f('deliveryScore', 'On-time delivery (0-100)', 'number', { min: 0, max: 100, required: true }),
        f('responsivenessScore', 'Responsiveness (0-100)', 'number', { min: 0, max: 100, required: true }),
        f('ppm', 'Defect rate (PPM)', 'number', { min: 0 }),
        f('comments', 'Comments', 'textarea')
      ],
      workflow: { initial: 'Draft', states: ['Draft', 'Completed'], terminal: ['Completed'], transitions: [
        { from: ['Draft'], to: 'Completed', label: 'Complete evaluation', approval: true,
          effect: (r, c) => {
            const s = c.db._raw('suppliers', r.data.supplier);
            if (s) c.touch('suppliers', s, sup => {
              const m = Number(sup.data.evalIntervalMonths || 12);
              const d = new Date(r.data.evalDate + 'T00:00:00Z'); d.setUTCMonth(d.getUTCMonth() + m); sup.data.nextEvaluation = isoDate(d);
            }, 'Next evaluation scheduled from ' + r.id);
          } }] },
      lockedStates: ['Completed'],
      derive: r => {
        const o = Math.round(Number(r.data.qualityScore || 0) * 0.5 + Number(r.data.deliveryScore || 0) * 0.3 + Number(r.data.responsivenessScore || 0) * 0.2);
        return { overall: o, grade: o >= 90 ? 'A' : o >= 75 ? 'B' : o >= 60 ? 'C' : 'D' };
      },
      derivedList: [['overall', 'Score'], ['grade', 'Grade']]
    },
    equipment: {
      label: 'Equipment', plural: 'Equipment', prefix: 'EQP', group: 'Support', clause: '7.1.5', titleField: 'name',
      fields: [
        f('assetTag', 'Asset tag', 'text', { required: true, unique: true, list: true }),
        f('name', 'Description', 'text', { required: true, list: true }),
        f('equipType', 'Type', 'select', { options: ['Caliper', 'Micrometer', 'Height gauge', 'CMM', 'Torque wrench', 'Pin gauge set', 'Surface plate', 'Hardness tester', 'Thread gauge'] }),
        f('location', 'Location', 'text', { list: true }),
        OWNER,
        f('range', 'Range / resolution', 'text'),
        f('intervalDays', 'Calibration interval (days)', 'number', { min: 1, max: 1825, required: true, default: 365 }),
        f('provider', 'Calibration provider', 'ref', { ref: 'suppliers' })
      ],
      workflow: { initial: 'In service', states: ['In service', 'Out of service', 'Retired'], terminal: ['Retired'], transitions: [
        { from: ['In service'], to: 'Out of service', label: 'Remove from service', comment: true },
        { from: ['Out of service'], to: 'In service', label: 'Return to service', guard: (r, db, now) => { const d = ENTITIES.equipment.derive(r, db, now); return d.calStatus === 'Overdue' || !d.lastCal ? 'A current passing calibration is required.' : null; } },
        { from: ['In service', 'Out of service'], to: 'Retired', label: 'Retire', comment: true }] },
      lockedStates: ['Retired'],
      derive: (r, db, now) => {
        const cal = db.list('calibrations').filter(c => c.data.equipment === r.id && c.status === 'Approved' && c.data.result !== 'Fail')
          .sort((a, b) => (a.data.calDate < b.data.calDate ? 1 : -1))[0];
        if (!cal) return { lastCal: '', nextDue: '', calStatus: 'No calibration' };
        const nextDue = addDays(cal.data.calDate, r.data.intervalDays || 365);
        const today = isoDate(now || new Date());
        const left = daysBetween(today, nextDue);
        return { lastCal: cal.data.calDate, nextDue, calStatus: left < 0 ? 'Overdue' : left <= 30 ? 'Due soon' : 'Current' };
      },
      derivedList: [['nextDue', 'Next due'], ['calStatus', 'Calibration']],
      due: (r, db, now) => { if (r.status !== 'In service') return null; const d = ENTITIES.equipment.derive(r, db, now); return d.nextDue ? { date: d.nextDue, label: 'Calibration' } : null; }
    },
    calibrations: {
      label: 'Calibration record', plural: 'Calibration records', prefix: 'CAL', group: 'Support', clause: '7.1.5.2', titleField: 'certificateNo',
      fields: [
        f('equipment', 'Equipment', 'ref', { ref: 'equipment', required: true, list: true }),
        f('calDate', 'Calibration date', 'date', { required: true, list: true }),
        f('performedBy', 'Performed by', 'ref', { ref: 'suppliers' }),
        f('certificateNo', 'Certificate number', 'text', { required: true, list: true }),
        f('result', 'Result', 'select', { options: ['Pass', 'Pass after adjustment', 'Fail'], required: true, list: true }),
        f('asFound', 'As-found data', 'textarea'),
        f('asLeft', 'As-left data', 'textarea'),
        f('impactAssessment', 'Impact assessment on prior measurements', 'textarea')
      ],
      workflow: { initial: 'Draft', states: ['Draft', 'Approved', 'Voided'], terminal: ['Approved', 'Voided'], transitions: [
        { from: ['Draft'], to: 'Approved', label: 'Approve record', approval: true,
          guard: r => (r.data.result !== 'Pass' && isEmpty(r.data.impactAssessment)) ? 'An impact assessment is required when the as-found result was out of tolerance.' : null },
        { from: ['Draft'], to: 'Voided', label: 'Void', comment: true }] },
      lockedStates: ['Approved', 'Voided']
    },
    training: {
      label: 'Training record', plural: 'Training records', prefix: 'TRN', group: 'Support', clause: '7.2 / 7.3', titleField: 'course',
      fields: [
        f('person', 'Employee', 'ref', { ref: 'people', required: true, list: true }),
        f('course', 'Training topic', 'text', { required: true, list: true }),
        f('document', 'Controlled document', 'ref', { ref: 'documents' }),
        f('method', 'Method', 'select', { options: ['Read and acknowledge', 'Classroom', 'On-the-job', 'External course', 'E-learning'], required: true }),
        f('assignedDate', 'Assigned', 'date', { required: true }),
        f('dueDate', 'Due', 'date', { required: true, list: true }),
        f('completedDate', 'Completed', 'date'),
        f('trainer', 'Trainer / assessor', 'ref', { ref: 'people' }),
        f('assessment', 'Competence evidence', 'textarea'),
        f('trainedRevision', 'Document revision trained', 'text', { readonly: true }),
        f('expiryDate', 'Retraining due', 'date')
      ],
      workflow: { initial: 'Assigned', states: ['Assigned', 'Completed', 'Verified', 'Cancelled'], terminal: ['Verified', 'Cancelled'], transitions: [
        { from: ['Assigned'], to: 'Completed', label: 'Mark completed', requires: ['completedDate'],
          effect: (r, c) => { if (r.data.document) { const d = c.db._raw('documents', r.data.document); if (d) r.data.trainedRevision = d.data.revision; } } },
        { from: ['Completed'], to: 'Verified', label: 'Verify competence', approval: true, requires: ['assessment', 'trainer'] },
        { from: ['Assigned'], to: 'Cancelled', label: 'Cancel', comment: true }] },
      lockedStates: ['Verified', 'Cancelled'],
      derive: (r, db) => {
        if (!r.data.document || !r.data.trainedRevision) return { currency: r.status === 'Verified' ? 'Current' : '' };
        const d = db._raw('documents', r.data.document);
        if (!d || d.status !== 'Effective' || d.data.revision === r.data.trainedRevision) return { currency: 'Current' };
        const newer = db.list('training').some(o => o.id !== r.id && o.data.person === r.data.person && o.data.document === r.data.document && o.data.trainedRevision === d.data.revision && ['Completed', 'Verified'].includes(o.status));
        return { currency: newer ? 'Superseded' : 'Retraining needed (rev ' + d.data.revision + ')' };
      },
      derivedList: [['currency', 'Currency']],
      due: r => r.status === 'Assigned' ? { date: r.data.dueDate, label: 'Training' } : (r.status === 'Verified' && r.data.expiryDate ? { date: r.data.expiryDate, label: 'Retraining' } : null)
    },
    inspPlans: {
      label: 'Inspection plan', plural: 'Inspection plans', prefix: 'IPL', group: 'Operation', clause: '8.5.1 / 8.6', titleField: 'title',
      fields: [
        f('title', 'Plan title', 'text', { required: true, list: true }),
        f('partNumber', 'Part number', 'text', { required: true, list: true }),
        f('stage', 'Stage', 'select', { options: ['Receiving', 'First article', 'In-process', 'Final'], required: true, list: true }),
        PROCESS,
        f('document', 'Governing document', 'ref', { ref: 'documents' }),
        f('sampling', 'Sampling rule', 'text'),
        f('characteristics', 'Characteristics', 'table', { columns: [
          f('characteristic', 'Characteristic', 'text'),
          f('spec', 'Specification', 'text'),
          f('method', 'Method', 'text'),
          f('gauge', 'Gauge', 'ref', { ref: 'equipment' }),
          f('frequency', 'Frequency', 'text')] })
      ],
      workflow: { initial: 'Draft', states: ['Draft', 'Approved', 'Obsolete'], terminal: ['Obsolete'], transitions: [
        { from: ['Draft'], to: 'Approved', label: 'Submit for approval', approval: true, requires: ['characteristics'] },
        { from: ['Approved'], to: 'Draft', label: 'Revise plan', comment: true },
        { from: ['Draft', 'Approved'], to: 'Obsolete', label: 'Make obsolete', approval: true, comment: true }] },
      lockedStates: ['Approved', 'Obsolete']
    },
    inspections: {
      label: 'Inspection record', plural: 'Inspection records', prefix: 'INS', group: 'Operation', clause: '8.6', titleField: 'lot',
      fields: [
        f('plan', 'Inspection plan', 'ref', { ref: 'inspPlans', required: true, list: true }),
        f('inspDate', 'Date', 'date', { required: true, list: true }),
        f('lot', 'Lot / batch', 'text', { required: true, list: true }),
        f('inspector', 'Inspector', 'ref', { ref: 'people', required: true }),
        f('qtyInspected', 'Quantity inspected', 'number', { min: 1, required: true }),
        f('qtyRejected', 'Quantity rejected', 'number', { min: 0, required: true, default: 0 }),
        f('notes', 'Notes / measurements', 'textarea')
      ],
      workflow: { initial: 'Open', states: ['Open', 'Accepted', 'Rejected'], terminal: ['Accepted', 'Rejected'], transitions: [
        { from: ['Open'], to: 'Accepted', label: 'Accept lot',
          guard: (r, db) => {
            const p = db._raw('inspPlans', r.data.plan); if (p && p.status !== 'Approved') return 'The inspection plan is not approved.';
            return Number(r.data.qtyRejected) > 0 && !db.related('inspections', r.id).some(x => x.entity === 'ncrs') ? 'Rejected pieces must be covered by an NCR that references this inspection.' : null; } },
        { from: ['Open'], to: 'Rejected', label: 'Reject entire lot',
          guard: (r, db) => db.related('inspections', r.id).some(x => x.entity === 'ncrs') ? null : 'Raise an NCR that references this inspection first.' }] },
      lockedStates: ['Accepted', 'Rejected'],
      validate: r => Number(r.data.qtyRejected) > Number(r.data.qtyInspected) ? 'Rejected quantity cannot exceed inspected quantity.' : null,
      derive: r => ({ yield: r.data.qtyInspected ? (100 * (1 - Number(r.data.qtyRejected || 0) / Number(r.data.qtyInspected))).toFixed(1) + '%' : '' }),
      derivedList: [['yield', 'Yield']]
    },
    objectives: {
      label: 'Quality objective', plural: 'Quality objectives', prefix: 'OBJ', group: 'Planning', clause: '6.2', titleField: 'title',
      fields: [
        f('title', 'Objective', 'text', { required: true, list: true }),
        PROCESS, OWNER,
        f('metric', 'Metric', 'text', { required: true }),
        f('unit', 'Unit', 'text'),
        f('direction', 'Direction', 'select', { options: ['Higher is better', 'Lower is better'], required: true }),
        f('baseline', 'Baseline', 'number'),
        f('target', 'Target', 'number', { required: true, list: true }),
        f('targetDate', 'Target date', 'date', { required: true }),
        f('plan', 'How it will be achieved', 'textarea'),
        f('measurements', 'Measurements', 'table', { columns: [f('period', 'Period (YYYY-MM)', 'text'), f('value', 'Value', 'number'), f('note', 'Note', 'text')] })
      ],
      workflow: { initial: 'Active', states: ['Active', 'Achieved', 'Not achieved', 'Retired'], terminal: ['Achieved', 'Not achieved', 'Retired'], transitions: [
        { from: ['Active'], to: 'Achieved', label: 'Mark achieved', approval: true },
        { from: ['Active'], to: 'Not achieved', label: 'Mark not achieved', approval: true, comment: true },
        { from: ['Active'], to: 'Retired', label: 'Retire', comment: true }] },
      lockedStates: ['Achieved', 'Not achieved', 'Retired'],
      derive: r => {
        const m = (r.data.measurements || []).filter(x => x.value !== '' && x.value !== null && x.value !== undefined).sort((a, b) => (a.period < b.period ? -1 : 1));
        const last = m.length ? Number(m[m.length - 1].value) : null;
        const hi = r.data.direction !== 'Lower is better';
        const ok = last === null ? null : (hi ? last >= Number(r.data.target) : last <= Number(r.data.target));
        return { latest: last === null ? '' : last, performance: last === null ? 'No data' : ok ? 'On target' : 'Off target', series: m.map(x => [x.period, Number(x.value)]) };
      },
      derivedList: [['latest', 'Latest'], ['performance', 'Performance']],
      due: r => r.status === 'Active' ? { date: r.data.targetDate, label: 'Objective target date' } : null
    },
    reviews: {
      label: 'Management review', plural: 'Management reviews', prefix: 'MR', group: 'Evaluation', clause: '9.3', titleField: 'title',
      fields: [
        f('title', 'Title', 'text', { required: true, list: true }),
        f('scheduledDate', 'Scheduled', 'date', { required: true, list: true }),
        f('heldDate', 'Held on', 'date'),
        f('chair', 'Chair', 'ref', { ref: 'people', required: true, list: true }),
        f('attendees', 'Attendees', 'text'),
        f('inputs', 'Review inputs', 'table', { columns: [f('topic', 'Topic', 'text'), f('summary', 'Summary', 'text')] }),
        f('decisions', 'Decisions and actions', 'table', { columns: [
          f('decision', 'Decision / action', 'text'), f('owner', 'Owner', 'ref', { ref: 'people' }), f('due', 'Due', 'date'), f('capa', 'CAPA', 'ref', { ref: 'capas' }), f('status', 'Status', 'select', { options: ['Open', 'Done'] })] }),
        f('conclusion', 'Conclusion on QMS suitability, adequacy and effectiveness', 'textarea')
      ],
      workflow: { initial: 'Planned', states: ['Planned', 'Held', 'Minutes approved'], terminal: ['Minutes approved'], transitions: [
        { from: ['Planned'], to: 'Held', label: 'Record meeting held', requires: ['heldDate', 'attendees', 'inputs'],
          effect: (r, c) => { r.data.kpiSnapshot = canonical(c.db.kpis(c.now).summary); } },
        { from: ['Held'], to: 'Minutes approved', label: 'Approve minutes', approval: true, requires: ['decisions', 'conclusion'] }] },
      lockedStates: ['Minutes approved'],
      due: r => r.status === 'Planned' ? { date: r.data.scheduledDate, label: 'Management review' } : null
    }
  };

  // Recommended inputs list for management reviews (wording is this application's own summary).
  const REVIEW_INPUT_TOPICS = [
    'Status of actions from previous reviews', 'Changes in external and internal issues',
    'Customer satisfaction and feedback', 'Quality objectives performance', 'Process performance and product conformity',
    'Nonconformities and corrective actions', 'Monitoring and measurement results', 'Audit results',
    'External provider performance', 'Adequacy of resources', 'Effectiveness of risk and opportunity actions', 'Improvement opportunities'];

  const TRACE_HUBS = ['processes', 'suppliers', 'inspPlans', 'people'];
  const SCHEMA_VERSION = 1;
  const BACKUP_FORMAT = 'offline-qms-backup';
  const MAX_ATTACHMENT_BYTES = 3 * 1024 * 1024;
  const RESERVED = ['id', 'status', 'data', 'history', 'attachments', 'approvals', 'pending', 'revisions', 'created', 'createdBy'];

  /* ------------------------------------------------------------------ store */
  function emptyData(now) {
    const records = {}; Object.keys(ENTITIES).forEach(k => (records[k] = {}));
    return { meta: { schemaVersion: SCHEMA_VERSION, createdAt: now.toISOString(), seq: {}, company: 'Your organization', events: [] }, records };
  }

  function createStore(opts) {
    opts = opts || {};
    let clock = opts.clock || (() => new Date());
    let data = opts.data ? clone(opts.data) : emptyData(clock());
    const listeners = [];

    const now = () => clock();
    const today = () => isoDate(now());
    const ent = name => { const e = ENTITIES[name]; if (!e) throw new QMSError('Unknown record type: ' + name); return e; };
    const raw = (name, id) => (data.records[name] || {})[id] || null;
    const list = name => Object.values(data.records[name] || {}).sort((a, b) => (a.id < b.id ? -1 : 1));
    function user(id) {
      const p = raw('people', id);
      if (!p) throw new QMSError('Unknown user: ' + id);
      if (p.status !== 'Active') throw new QMSError(p.data.name + ' is inactive and cannot act in the system.');
      return p;
    }
    function emit(evt) { listeners.forEach(fn => { try { fn(evt); } catch (e) { /* listener errors must not break writes */ } }); }

    function snapshotOf(rec) {
      const s = clone(rec); delete s.history;
      if (s.attachments) s.attachments = s.attachments.map(a => { const m = Object.assign({}, a); delete m.data; return m; });
      return s;
    }
    function diff(before, after) {
      const changes = [];
      const keys = new Set([...Object.keys(before.data || {}), ...Object.keys(after.data || {})]);
      keys.forEach(k => {
        const a = canonical(before.data[k]), b = canonical(after.data[k]);
        if (a !== b) changes.push({ field: k, from: before.data[k] === undefined ? null : before.data[k], to: after.data[k] === undefined ? null : after.data[k] });
      });
      if (before.status !== after.status) changes.push({ field: 'status', from: before.status || null, to: after.status });
      return changes;
    }
    function appendHistory(rec, entry) {
      rec.history = rec.history || [];
      const prev = rec.history.length ? rec.history[rec.history.length - 1].hash : 'GENESIS';
      entry.seq = rec.history.length + 1;
      entry.snapshotHash = sha256(canonical(snapshotOf(rec)));
      entry.prevHash = prev;
      const body = Object.assign({}, entry); delete body.hash;
      entry.hash = sha256(prev + canonical(body));
      rec.history.push(entry);
    }

    function validateValues(name, values, rec) {
      const e = ent(name), errs = [];
      const check = (fd, v, path) => {
        if (isEmpty(v)) return;
        switch (fd.type) {
          case 'date': if (typeof v !== 'string' || !validDate(v)) errs.push(path + ': invalid date (YYYY-MM-DD)'); break;
          case 'number': {
            const n = Number(v);
            if (typeof v === 'boolean' || !isFinite(n)) errs.push(path + ': must be a number');
            else { if (fd.min !== undefined && n < fd.min) errs.push(path + ': minimum ' + fd.min); if (fd.max !== undefined && n > fd.max) errs.push(path + ': maximum ' + fd.max); }
            break; }
          case 'select': if (!fd.options.includes(v)) errs.push(path + ': "' + v + '" is not an allowed value'); break;
          case 'email': if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) errs.push(path + ': invalid email'); break;
          case 'ref': if (!raw(fd.ref, v)) errs.push(path + ': ' + v + ' does not exist'); break;
          case 'refs': if (!Array.isArray(v)) errs.push(path + ': must be a list'); else v.forEach(x => { if (!raw(fd.ref, x)) errs.push(path + ': ' + x + ' does not exist'); }); break;
          case 'table':
            if (!Array.isArray(v)) { errs.push(path + ': must be a list of rows'); break; }
            if (v.length > 500) errs.push(path + ': too many rows');
            v.forEach((row, i) => { if (!row || typeof row !== 'object') { errs.push(path + ' row ' + (i + 1) + ': invalid'); return; }
              Object.keys(row).forEach(ck => { if (!fd.columns.some(c => c.k === ck)) errs.push(path + ' row ' + (i + 1) + ': unknown column ' + ck); });
              fd.columns.forEach(c => check(c, row[c.k], fd.label + ' row ' + (i + 1) + ' / ' + c.label)); });
            break;
          default: if (typeof v !== 'string') errs.push(path + ': must be text'); else if (v.length > 20000) errs.push(path + ': too long');
        }
      };
      Object.keys(values).forEach(k => {
        const fd = e.fields.find(x => x.k === k);
        if (!fd && k !== 'kpiSnapshot') errs.push('Unknown field: ' + k);
        else if (fd) check(fd, values[k], fd.label);
      });
      const merged = Object.assign({}, rec ? rec.data : {}, values);
      e.fields.forEach(fd => {
        if (fd.required && isEmpty(merged[fd.k])) errs.push(fd.label + ' is required');
        if (fd.unique && !isEmpty(merged[fd.k])) {
          const norm = String(merged[fd.k]).trim().toLowerCase();
          if (list(name).some(o => (!rec || o.id !== rec.id) && String(o.data[fd.k] || '').trim().toLowerCase() === norm)) errs.push(fd.label + ' "' + merged[fd.k] + '" is already used');
        }
      });
      if (e.validate) { const m = e.validate({ data: merged }); if (m) errs.push(m); }
      return errs;
    }
    function normalize(name, values) {
      const e = ent(name), out = {};
      Object.keys(values || {}).forEach(k => {
        let v = values[k];
        const fd = e.fields.find(x => x.k === k);
        if (fd && fd.type === 'number' && v !== '' && v !== null && v !== undefined && !isNaN(Number(v))) v = Number(v);
        if (typeof v === 'string') v = v.trim();
        if (fd && fd.type === 'table' && Array.isArray(v)) v = v.filter(row => row && Object.values(row).some(x => !isEmpty(x))).map(row => {
          const r2 = {}; fd.columns.forEach(c => { let cv = row[c.k]; if (typeof cv === 'string') cv = cv.trim(); if (c.type === 'number' && cv !== '' && cv !== undefined && cv !== null && !isNaN(Number(cv))) cv = Number(cv); if (!isEmpty(cv)) r2[c.k] = cv; }); return r2; });
        out[k] = v;
      });
      return out;
    }

    // Generic guarded mutation: everything that changes a record passes through here.
    function mutate(name, rec, userId, action, comment, fn, extra) {
      const before = clone(rec);
      fn(rec);
      const changes = diff(before, rec);
      appendHistory(rec, Object.assign({ ts: now().toISOString(), user: userId, action, changes, comment: comment || '' }, extra || {}));
      return changes;
    }
    const ctx = (userId, approver) => ({
      today: today(), now: now(), user: userId, approver, db: api,
      touch: (n, r, fn, comment) => mutate(n, r, userId, 'system-update', comment, fn)
    });

    function create(name, values, userId) {
      const e = ent(name);
      if (name !== 'people' || list('people').length) user(userId);
      values = normalize(name, values);
      e.fields.forEach(fd => { if (fd.default !== undefined && isEmpty(values[fd.k])) values[fd.k] = fd.default; });
      e.fields.forEach(fd => { if (fd.readonly) delete values[fd.k]; });
      const errs = validateValues(name, values, null);
      if (errs.length) throw new QMSError('Cannot save ' + e.label.toLowerCase() + ': ' + errs[0], errs);
      const seq = (data.meta.seq[name] || 0) + 1;
      const id = e.prefix + '-' + String(seq).padStart(4, '0');
      if (raw(name, id)) throw new QMSError('ID collision: ' + id);
      const rec = { id, status: e.workflow.initial, data: {}, attachments: [], approvals: [], pending: null, created: now().toISOString(), createdBy: userId, history: [] };
      if (name === 'documents') rec.revisions = [];
      rec.data = values;
      if (e.onCreate) e.onCreate(rec);
      appendHistory(rec, { ts: rec.created, user: userId, action: 'created', changes: Object.keys(rec.data).map(k => ({ field: k, from: null, to: rec.data[k] })), comment: '' });
      data.meta.seq[name] = seq;
      data.records[name][id] = rec;
      emit({ type: 'create', entity: name, id });
      return clone(rec);
    }

    function isLocked(name, rec) { return ent(name).lockedStates.includes(rec.status) || !!rec.pending; }

    function update(name, id, values, userId, comment) {
      const e = ent(name), rec = raw(name, id);
      if (!rec) throw new QMSError(id + ' not found');
      user(userId);
      if (rec.pending) throw new QMSError(id + ' is awaiting approval and cannot be edited. Withdraw or decide the approval first.');
      if (e.lockedStates.includes(rec.status)) throw new QMSError(id + ' is ' + rec.status + ' and locked against editing.' + (e.workflow.transitions.some(t => t.from.includes(rec.status) && t.to === 'Draft') ? ' Start a revision to change it.' : ''));
      values = normalize(name, values);
      e.fields.forEach(fd => { if (fd.readonly) delete values[fd.k]; });
      const errs = validateValues(name, values, rec);
      if (errs.length) throw new QMSError('Cannot save: ' + errs[0], errs);
      const merged = Object.assign({}, rec.data, values);
      if (canonical(merged) === canonical(rec.data)) return { record: clone(rec), changes: [] };
      const changes = mutate(name, rec, userId, 'updated', comment, r => { r.data = merged; });
      emit({ type: 'update', entity: name, id });
      return { record: clone(rec), changes };
    }

    function availableTransitions(name, id) {
      const e = ent(name), rec = raw(name, id);
      if (!rec || rec.pending) return [];
      return e.workflow.transitions.filter(t => t.from.includes(rec.status)).map(t => ({
        to: t.to, label: t.label, comment: !!t.comment,
        approval: typeof t.approval === 'function' ? !!t.approval(rec) : !!t.approval,
        blocked: checkTransition(name, rec, t)
      }));
    }
    function checkTransition(name, rec, t) {
      const e = ent(name);
      const missing = (t.requires || []).filter(k => isEmpty(rec.data[k])).map(k => e.fields.find(x => x.k === k).label);
      if (missing.length) return 'Required before this step: ' + missing.join(', ');
      const errs = validateValues(name, {}, rec);
      if (errs.length) return errs[0];
      return t.guard ? t.guard(rec, api, now()) : null;
    }
    function findTransition(name, rec, to) {
      const t = ent(name).workflow.transitions.find(x => x.from.includes(rec.status) && x.to === to);
      if (!t) throw new QMSError('Transition from "' + rec.status + '" to "' + to + '" is not allowed for ' + ent(name).label.toLowerCase() + 's.');
      return t;
    }
    function applyTransition(name, rec, t, userId, comment, approver) {
      const from = rec.status;
      mutate(name, rec, userId, approver ? 'approved-transition' : 'transition', comment, r => {
        if (t.effect) t.effect(r, ctx(userId, approver));
        r.status = t.to; r.pending = null;
      }, { transition: t.label, fromStatus: from, toStatus: t.to });
    }

    function transition(name, id, to, userId, comment) {
      const rec = raw(name, id);
      if (!rec) throw new QMSError(id + ' not found');
      user(userId);
      if (rec.pending) throw new QMSError(id + ' already has a pending approval.');
      const t = findTransition(name, rec, to);
      if (t.comment && isEmpty(comment)) throw new QMSError('A comment is required for "' + t.label + '".');
      const block = checkTransition(name, rec, t);
      if (block) throw new QMSError(block);
      const needsApproval = typeof t.approval === 'function' ? t.approval(rec) : !!t.approval;
      if (needsApproval) {
        mutate(name, rec, userId, 'approval-requested', comment, r => { r.pending = { to, transition: t.label, requestedBy: userId, requestedAt: now().toISOString(), comment: comment || '' }; }, { transition: t.label });
        emit({ type: 'approval-requested', entity: name, id });
        return { record: clone(rec), pendingApproval: true };
      }
      applyTransition(name, rec, t, userId, comment);
      emit({ type: 'transition', entity: name, id });
      return { record: clone(rec), pendingApproval: false };
    }

    function decide(name, id, userId, approve, comment) {
      const rec = raw(name, id);
      if (!rec) throw new QMSError(id + ' not found');
      const u = user(userId);
      if (!rec.pending) throw new QMSError(id + ' has no pending approval.');
      if (u.data.canApprove !== 'Yes') throw new QMSError(u.data.name + ' does not have approval authority.');
      if (rec.pending.requestedBy === userId) throw new QMSError('Segregation of duties: the requester cannot approve their own request.');
      if (!approve && isEmpty(comment)) throw new QMSError('A reason is required when rejecting.');
      const p = rec.pending;
      const t = findTransition(name, rec, p.to);
      if (approve) {
        const block = checkTransition(name, rec, t);
        if (block) throw new QMSError('Cannot approve: ' + block);
      }
      rec.approvals = rec.approvals || [];
      const signature = { decision: approve ? 'Approved' : 'Rejected', transition: p.transition, to: p.to, requestedBy: p.requestedBy, requestedAt: p.requestedAt, by: userId, byName: u.data.name, at: now().toISOString(), comment: comment || '' };
      signature.signatureHash = sha256(canonical(signature) + canonical(rec.data));
      if (approve) {
        rec.approvals.push(signature);
        applyTransition(name, rec, t, userId, comment, userId);
      } else {
        mutate(name, rec, userId, 'approval-rejected', comment, r => { r.approvals.push(signature); r.pending = null; }, { transition: p.transition });
      }
      emit({ type: approve ? 'approved' : 'rejected', entity: name, id });
      return clone(rec);
    }
    function withdraw(name, id, userId, comment) {
      const rec = raw(name, id);
      if (!rec || !rec.pending) throw new QMSError('Nothing to withdraw.');
      user(userId);
      if (rec.pending.requestedBy !== userId) throw new QMSError('Only the requester can withdraw an approval request.');
      mutate(name, rec, userId, 'approval-withdrawn', comment, r => { r.pending = null; });
      emit({ type: 'withdrawn', entity: name, id });
      return clone(rec);
    }

    function addAttachment(name, id, file, userId) {
      const rec = raw(name, id);
      if (!rec) throw new QMSError(id + ' not found');
      user(userId);
      if (!file || !file.name || typeof file.data !== 'string') throw new QMSError('Invalid attachment.');
      const size = file.size !== undefined ? file.size : Math.floor(file.data.length * 0.75);
      if (size > MAX_ATTACHMENT_BYTES) throw new QMSError('Attachment exceeds the ' + (MAX_ATTACHMENT_BYTES / 1048576) + ' MB limit.');
      const att = { id: 'ATT-' + sha256(id + '|' + file.name + '|' + now().toISOString() + '|' + rec.history.length).slice(0, 12), name: String(file.name).slice(0, 200), type: file.type || 'application/octet-stream', size, sha256: sha256(file.data), addedBy: userId, addedAt: now().toISOString(), description: file.description || '', data: file.data };
      mutate(name, rec, userId, 'attachment-added', att.name, r => { r.attachments.push(att); }, { attachment: { id: att.id, name: att.name, sha256: att.sha256 } });
      emit({ type: 'attachment', entity: name, id });
      return Object.assign({}, att, { data: undefined });
    }
    function removeAttachment(name, id, attId, userId, comment) {
      const rec = raw(name, id);
      if (!rec) throw new QMSError(id + ' not found');
      user(userId);
      if (isLocked(name, rec)) throw new QMSError('Evidence on a locked record cannot be removed.');
      if (isEmpty(comment)) throw new QMSError('A reason is required to remove evidence.');
      const att = rec.attachments.find(a => a.id === attId);
      if (!att) throw new QMSError('Attachment not found');
      mutate(name, rec, userId, 'attachment-removed', comment, r => { r.attachments = r.attachments.filter(a => a.id !== attId); }, { attachment: { id: att.id, name: att.name, sha256: att.sha256 } });
      emit({ type: 'attachment', entity: name, id });
    }
    function comment(name, id, userId, text) {
      const rec = raw(name, id);
      if (!rec) throw new QMSError(id + ' not found');
      user(userId);
      if (isEmpty(text)) throw new QMSError('Comment is empty.');
      mutate(name, rec, userId, 'comment', String(text).slice(0, 5000), () => {});
      emit({ type: 'comment', entity: name, id });
    }

    /* relationships: everything that references (entity,id), including table rows */
    function related(name, id) {
      const out = [];
      Object.keys(ENTITIES).forEach(en => {
        const e = ENTITIES[en];
        list(en).forEach(r => {
          e.fields.forEach(fd => {
            if (fd.type === 'ref' && fd.ref === name && r.data[fd.k] === id) out.push({ entity: en, record: r, via: fd.label, direction: 'in' });
            if (fd.type === 'refs' && fd.ref === name && (r.data[fd.k] || []).includes(id)) out.push({ entity: en, record: r, via: fd.label, direction: 'in' });
            if (fd.type === 'table') fd.columns.forEach(c => { if (c.type === 'ref' && c.ref === name && (r.data[fd.k] || []).some(row => row[c.k] === id)) out.push({ entity: en, record: r, via: fd.label + ' / ' + c.label, direction: 'in' }); });
          });
        });
      });
      const rec = raw(name, id);
      if (rec) ENTITIES[name].fields.forEach(fd => {
        const push = tid => { const t = raw(fd.ref, tid); if (t) out.push({ entity: fd.ref, record: t, via: fd.label, direction: 'out' }); };
        if (fd.type === 'ref' && rec.data[fd.k] && fd.ref !== 'people') push(rec.data[fd.k]);
        if (fd.type === 'refs') (rec.data[fd.k] || []).forEach(push);
        if (fd.type === 'table') fd.columns.forEach(c => { if (c.type === 'ref' && c.ref !== 'people') (rec.data[fd.k] || []).forEach(row => { if (row[c.k]) { const t = raw(c.ref, row[c.k]); if (t) out.push({ entity: c.ref, record: t, via: fd.label + ' / ' + c.label, direction: 'out' }); } }); });
      });
      const seen = new Set();
      return out.filter(x => { const k = x.entity + x.record.id + x.direction + x.via; if (seen.has(k)) return false; seen.add(k); return true; });
    }
    function traceChain(name, id, depth) {
      // Breadth-first walk of non-people relationships to show an end-to-end trace (e.g. complaint → NCR → CAPA → risk).
      const seen = new Set([name + ':' + id]), out = [];
      let frontier = [[name, id, 0]];
      while (frontier.length) {
        const next = [];
        frontier.forEach(([n, i, d]) => {
          if (d >= (depth || 3)) return;
          if (d > 0 && TRACE_HUBS.includes(n)) return; // shared hubs (e.g. a process) would link everything to everything
          related(n, i).forEach(x => {
            if (x.entity === 'people') return;
            const key = x.entity + ':' + x.record.id;
            if (seen.has(key)) return; seen.add(key);
            out.push({ entity: x.entity, id: x.record.id, depth: d + 1, from: i, via: x.via });
            next.push([x.entity, x.record.id, d + 1]);
          });
        });
        frontier = next;
      }
      return out;
    }

    function derive(name, rec) { const e = ent(name); return e.derive ? e.derive(rec, api, now()) : {}; }
    function dueOf(name, rec) { const e = ent(name); return e.due ? e.due(rec, api, now()) : null; }
    function dueItems(horizonDays) {
      const t = today(), out = [];
      Object.keys(ENTITIES).forEach(n => list(n).forEach(r => {
        const d = dueOf(n, r);
        if (!d || !d.date) return;
        const left = daysBetween(t, d.date);
        if (left <= (horizonDays === undefined ? 30 : horizonDays)) out.push({ entity: n, id: r.id, title: titleOf(n, r), label: d.label, date: d.date, daysLeft: left, overdue: left < 0, owner: r.data.owner || r.data.person || r.data.leadAuditor || r.data.chair || '' });
      }));
      return out.sort((a, b) => (a.date < b.date ? -1 : 1));
    }
    function pendingApprovals() {
      const out = [];
      Object.keys(ENTITIES).forEach(n => list(n).forEach(r => { if (r.pending) out.push({ entity: n, id: r.id, title: titleOf(n, r), pending: r.pending }); }));
      return out;
    }
    function titleOf(name, rec) {
      const e = ent(name);
      if (name === 'supplierEvals') { const s = raw('suppliers', rec.data.supplier); return (s ? s.data.name : '') + ' — ' + (rec.data.period || ''); }
      if (name === 'calibrations') { const q = raw('equipment', rec.data.equipment); return (q ? q.data.assetTag : '') + ' — ' + (rec.data.calDate || ''); }
      if (name === 'training') { const p = raw('people', rec.data.person); return (p ? p.data.name : '') + ' — ' + (rec.data.course || ''); }
      if (name === 'inspections') { const p = raw('inspPlans', rec.data.plan); return (p ? p.data.partNumber : '') + ' lot ' + (rec.data.lot || ''); }
      if (name === 'documents') return (rec.data.docNumber || '') + ' ' + (rec.data.title || '');
      return rec.data[e.titleField] || rec.id;
    }

    /* ---------------------------------------------------------------- integrity */
    function verifyRecord(name, rec, errors) {
      const e = ENTITIES[name];
      const where = name + '/' + rec.id;
      if (!new RegExp('^' + e.prefix + '-\\d{4,}$').test(rec.id)) errors.push({ where, code: 'bad-id', msg: 'ID does not match the ' + e.prefix + ' pattern' });
      if (!e.workflow.states.includes(rec.status)) errors.push({ where, code: 'bad-status', msg: 'Unknown status "' + rec.status + '"' });
      if (!Array.isArray(rec.history) || !rec.history.length) { errors.push({ where, code: 'no-history', msg: 'Revision history missing' }); return; }
      let prev = 'GENESIS';
      rec.history.forEach((h, i) => {
        const body = Object.assign({}, h); delete body.hash;
        if (h.prevHash !== prev) errors.push({ where, code: 'chain-broken', msg: 'History entry ' + (i + 1) + ' does not link to the previous entry' });
        if (sha256(prev + canonical(body)) !== h.hash) errors.push({ where, code: 'history-tampered', msg: 'History entry ' + (i + 1) + ' has been altered' });
        if (h.seq !== i + 1) errors.push({ where, code: 'seq', msg: 'History sequence gap at entry ' + (i + 1) });
        prev = h.hash;
      });
      const last = rec.history[rec.history.length - 1];
      if (last.snapshotHash !== sha256(canonical(snapshotOf(rec)))) errors.push({ where, code: 'content-tampered', msg: 'Record content differs from the last recorded change (edited outside the application)' });
      (rec.attachments || []).forEach(a => { if (typeof a.data !== 'string' || sha256(a.data) !== a.sha256) errors.push({ where, code: 'attachment-corrupt', msg: 'Attachment "' + a.name + '" fails its checksum' }); });
      const checkRef = (fd, v, label) => {
        if (isEmpty(v)) return;
        (fd.type === 'refs' ? v : [v]).forEach(x => { if (!raw(fd.ref, x)) errors.push({ where, code: 'dangling-ref', msg: label + ' points to missing ' + x }); });
      };
      e.fields.forEach(fd => {
        if (fd.type === 'ref' || fd.type === 'refs') checkRef(fd, rec.data[fd.k], fd.label);
        if (fd.type === 'table') (rec.data[fd.k] || []).forEach((row, i) => fd.columns.forEach(c => { if (c.type === 'ref') checkRef(c, row[c.k], fd.label + ' row ' + (i + 1)); }));
      });
      (rec.approvals || []).forEach(a => { if (!raw('people', a.by)) errors.push({ where, code: 'dangling-ref', msg: 'Approval signed by unknown user ' + a.by }); });
    }
    function integrityCheck() {
      const errors = [];
      let count = 0;
      if (!data || !data.meta || !data.records) return { ok: false, count: 0, errors: [{ where: 'database', code: 'structure', msg: 'Database structure invalid' }] };
      Object.keys(data.records).forEach(n => { if (!ENTITIES[n]) errors.push({ where: n, code: 'unknown-type', msg: 'Unknown record type in database' }); });
      Object.keys(ENTITIES).forEach(n => {
        const recs = data.records[n] || {};
        Object.keys(recs).forEach(id => {
          count++;
          const r = recs[id];
          if (!r || r.id !== id) { errors.push({ where: n + '/' + id, code: 'key-mismatch', msg: 'Record key does not match its ID' }); return; }
          verifyRecord(n, r, errors);
          const num = parseInt(id.split('-')[1], 10);
          if (num > (data.meta.seq[n] || 0)) errors.push({ where: n + '/' + id, code: 'seq', msg: 'ID is beyond the issued sequence' });
        });
        ENTITIES[n].fields.filter(fd => fd.unique).forEach(fd => {
          const seen = {};
          Object.values(recs).forEach(r => { const v = String(r.data[fd.k] || '').toLowerCase(); if (!v) return; if (seen[v]) errors.push({ where: n + '/' + r.id, code: 'duplicate', msg: fd.label + ' duplicates ' + seen[v] }); else seen[v] = r.id; });
        });
      });
      return { ok: errors.length === 0, count, errors, checkedAt: now().toISOString() };
    }

    /* ---------------------------------------------------------------- export */
    function csvCell(v) {
      let s = v === null || v === undefined ? '' : Array.isArray(v) ? v.join('; ') : String(v);
      if (/^[=+\-@\t\r]/.test(s)) s = "'" + s; // neutralize spreadsheet formula injection
      return /[",\r\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }
    function toCSV(name) {
      const e = ent(name);
      const derivedCols = e.derivedList || [];
      const header = ['ID', 'Status'].concat(e.fields.map(fd => fd.label), derivedCols.map(d => d[1]), ['Pending approval', 'Attachments', 'Created', 'Last changed']);
      const rows = list(name).map(r => {
        const d = derive(name, r);
        const vals = e.fields.map(fd => {
          const v = r.data[fd.k];
          if (fd.type === 'table') return (v || []).map(row => fd.columns.map(c => row[c.k] === undefined ? '' : row[c.k]).join(' | ')).join(' ;; ');
          return v;
        });
        return [r.id, r.status].concat(vals, derivedCols.map(c => d[c[0]]), [r.pending ? r.pending.transition : '', (r.attachments || []).length, r.created, r.history[r.history.length - 1].ts]);
      });
      return '﻿' + [header].concat(rows).map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
    }
    function auditTrailCSV() {
      const header = ['Timestamp', 'Record type', 'Record ID', 'Seq', 'User', 'Action', 'Transition', 'Field', 'From', 'To', 'Comment', 'Entry hash'];
      const rows = [];
      Object.keys(ENTITIES).forEach(n => list(n).forEach(r => r.history.forEach(h => {
        const base = [h.ts, ENTITIES[n].label, r.id, h.seq, h.user, h.action, h.transition || ''];
        const ch = h.changes && h.changes.length ? h.changes : [{ field: '', from: '', to: '' }];
        ch.forEach(c => rows.push(base.concat([c.field, typeof c.from === 'object' ? canonical(c.from) : c.from, typeof c.to === 'object' ? canonical(c.to) : c.to, h.comment, h.hash])));
      })));
      rows.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));
      return '﻿' + [header].concat(rows).map(row => row.map(csvCell).join(',')).join('\r\n') + '\r\n';
    }

    /* ---------------------------------------------------------------- backup / restore */
    function logEvent(evt, userId, detail) { data.meta.events.push({ ts: now().toISOString(), user: userId || '', event: evt, detail: detail || '' }); if (data.meta.events.length > 1000) data.meta.events.shift(); }
    function backup(userId) {
      logEvent('backup-exported', userId);
      const payload = clone(data);
      let n = 0; Object.values(payload.records).forEach(m => (n += Object.keys(m).length));
      return { format: BACKUP_FORMAT, formatVersion: 1, schemaVersion: SCHEMA_VERSION, exportedAt: now().toISOString(), recordCount: n, sha256: sha256(canonical(payload)), data: payload };
    }
    const MIGRATIONS = { /* schemaVersion N -> N+1 functions go here: 1: d => { ... ; d.meta.schemaVersion = 2; return d; } */ };
    function inspectBackup(obj) {
      const problems = [];
      if (typeof obj === 'string') { try { obj = JSON.parse(obj); } catch (e) { return { ok: false, problems: ['File is not valid JSON.'] }; } }
      if (!obj || obj.format !== BACKUP_FORMAT) return { ok: false, problems: ['Not a QMS backup file (format marker missing).'] };
      if (obj.formatVersion !== 1) problems.push('Unsupported backup format version ' + obj.formatVersion + '.');
      if (!obj.data || !obj.data.records || !obj.data.meta) return { ok: false, problems: problems.concat('Backup has no data section.') };
      if (sha256(canonical(obj.data)) !== obj.sha256) problems.push('Checksum mismatch: the file was modified or corrupted after export.');
      let d = clone(obj.data);
      if (obj.schemaVersion > SCHEMA_VERSION) problems.push('Backup was made by a newer schema (' + obj.schemaVersion + ') than this application (' + SCHEMA_VERSION + ').');
      for (let v = obj.schemaVersion; v < SCHEMA_VERSION; v++) { if (!MIGRATIONS[v]) { problems.push('No migration from schema ' + v); break; } d = MIGRATIONS[v](d); }
      Object.keys(ENTITIES).forEach(n => { if (!d.records[n]) d.records[n] = {}; });
      const tmp = createStore({ data: d, clock });
      const integ = tmp.integrityCheck();
      if (!integ.ok) problems.push(integ.errors.length + ' integrity error(s), first: ' + integ.errors[0].where + ' — ' + integ.errors[0].msg);
      return { ok: problems.length === 0, problems, recordCount: integ.count, exportedAt: obj.exportedAt, data: d, integrity: integ };
    }
    function restore(obj, userId) {
      const report = inspectBackup(obj);
      if (!report.ok) throw new QMSError('Restore refused: ' + report.problems[0], report.problems);
      const previous = data;
      data = report.data;
      const check = integrityCheck();
      if (!check.ok) { data = previous; throw new QMSError('Restore rolled back: integrity check failed after load.', check.errors.map(e => e.msg)); }
      logEvent('backup-restored', userId, 'Backup exported ' + report.exportedAt + ', ' + report.recordCount + ' records');
      emit({ type: 'restore' });
      return { recordCount: report.recordCount, exportedAt: report.exportedAt };
    }

    /* ---------------------------------------------------------------- KPIs */
    function monthKey(d) { return d ? d.slice(0, 7) : ''; }
    function lastMonths(n) {
      const out = [], d = new Date(today() + 'T00:00:00Z'); d.setUTCDate(1);
      for (let i = n - 1; i >= 0; i--) { const x = new Date(d); x.setUTCMonth(d.getUTCMonth() - i); out.push(isoDate(x).slice(0, 7)); }
      return out;
    }
    function closedOn(rec) { for (let i = rec.history.length - 1; i >= 0; i--) if (rec.history[i].toStatus === 'Closed') return rec.history[i].ts.slice(0, 10); return null; }
    function kpis() {
      const t = today(), months = lastMonths(12);
      const capas = list('capas'), ncrs = list('ncrs'), cmps = list('complaints');
      const openCapas = capas.filter(r => !['Closed', 'Cancelled'].includes(r.status));
      const closed = capas.filter(r => r.status === 'Closed');
      const cycle = closed.map(r => daysBetween(r.data.openedDate, closedOn(r) || t));
      const onTime = closed.filter(r => (closedOn(r) || t) <= r.data.dueDate).length;
      const eqp = list('equipment').filter(r => r.status === 'In service');
      const eqStat = eqp.map(r => derive('equipment', r).calStatus);
      const trn = list('training').filter(r => r.status !== 'Cancelled');
      const trnDone = trn.filter(r => ['Completed', 'Verified'].includes(r.status));
      const trnOver = trn.filter(r => r.status === 'Assigned' && r.data.dueDate < t);
      const ins = list('inspections').filter(r => r.status !== 'Open');
      const yieldByMonth = months.map(m => { const xs = ins.filter(r => monthKey(r.data.inspDate) === m); const q = xs.reduce((s, r) => s + Number(r.data.qtyInspected || 0), 0); const rj = xs.reduce((s, r) => s + Number(r.data.qtyRejected || 0), 0); return q ? +(100 * (1 - rj / q)).toFixed(2) : null; });
      const totalQ = ins.reduce((s, r) => s + Number(r.data.qtyInspected || 0), 0), totalR = ins.reduce((s, r) => s + Number(r.data.qtyRejected || 0), 0);
      const evals = list('supplierEvals').filter(r => r.status === 'Completed');
      const sup = list('suppliers');
      const risks = list('risks').filter(r => r.status !== 'Closed');
      const heat = {}; risks.filter(r => r.data.kind === 'Risk').forEach(r => { const k = r.data.likelihood + 'x' + r.data.severity; heat[k] = (heat[k] || 0) + 1; });
      const objs = list('objectives').filter(r => r.status === 'Active').map(r => Object.assign({ id: r.id, title: r.data.title, target: r.data.target, unit: r.data.unit, direction: r.data.direction }, derive('objectives', r)));
      const audits = list('audits'); const yr = t.slice(0, 4);
      const auditsYr = audits.filter(r => (r.data.plannedDate || '').startsWith(yr) && r.status !== 'Cancelled');
      const findings = []; audits.forEach(a => (a.data.findings || []).forEach(x => findings.push(x.type)));
      const respondedCmps = cmps.filter(r => r.data.responseDate);
      const docs = list('documents');
      const due = dueItems(0);
      const summary = {
        capaOpen: openCapas.length,
        capaOverdue: openCapas.filter(r => { const d = dueOf('capas', r); return d && d.date < t; }).length,
        capaAvgCycleDays: cycle.length ? Math.round(cycle.reduce((a, b) => a + b, 0) / cycle.length) : null,
        capaOnTimePct: closed.length ? Math.round(100 * onTime / closed.length) : null,
        ncrOpen: ncrs.filter(r => !['Closed', 'Cancelled'].includes(r.status)).length,
        ncrLast12: ncrs.filter(r => months.includes(monthKey(r.data.detectedDate))).length,
        complaintsOpen: cmps.filter(r => !['Closed', 'Cancelled'].includes(r.status)).length,
        complaintAvgResponseDays: respondedCmps.length ? +(respondedCmps.reduce((s, r) => s + daysBetween(r.data.receivedDate, r.data.responseDate), 0) / respondedCmps.length).toFixed(1) : null,
        calibrationCurrentPct: eqp.length ? Math.round(100 * eqStat.filter(s => s === 'Current' || s === 'Due soon').length / eqp.length) : null,
        calibrationOverdue: eqStat.filter(s => s === 'Overdue' || s === 'No calibration').length,
        trainingCompletionPct: trn.length ? Math.round(100 * trnDone.length / trn.length) : null,
        trainingOverdue: trnOver.length,
        firstPassYieldPct: totalQ ? +(100 * (1 - totalR / totalQ)).toFixed(2) : null,
        supplierApproved: sup.filter(r => r.status === 'Approved').length,
        supplierAvgScore: evals.length ? Math.round(evals.reduce((s, r) => s + derive('supplierEvals', r).overall, 0) / evals.length) : null,
        risksHigh: risks.filter(r => r.data.kind === 'Risk' && Number(r.data.likelihood) * Number(r.data.severity) >= 10).length,
        auditsPlannedThisYear: auditsYr.length,
        auditsCompletedThisYear: auditsYr.filter(r => ['Report issued', 'Closed'].includes(r.status)).length,
        objectivesOnTarget: objs.filter(o => o.performance === 'On target').length,
        objectivesActive: objs.length,
        documentsEffective: docs.filter(r => r.status === 'Effective').length,
        overdueItems: due.length,
        pendingApprovals: pendingApprovals().length
      };
      return {
        summary, months,
        ncrByMonth: months.map(m => ncrs.filter(r => monthKey(r.data.detectedDate) === m).length),
        complaintsByMonth: months.map(m => cmps.filter(r => monthKey(r.data.receivedDate) === m).length),
        yieldByMonth,
        capaByStage: ENTITIES.capas.workflow.states.filter(s => s !== 'Cancelled').map(s => [s, capas.filter(r => r.status === s).length]),
        ncrBySource: ENTITIES.ncrs.fields.find(x => x.k === 'detectedAt').options.map(o => [o, ncrs.filter(r => r.data.detectedAt === o).length]),
        findingsByType: ['Major NC', 'Minor NC', 'Observation', 'Opportunity'].map(k => [k, findings.filter(x => x === k).length]),
        riskHeat: heat, objectives: objs,
        supplierScores: sup.map(s => [s.data.name, derive('suppliers', s).lastScore]).filter(x => x[1] !== '')
      };
    }

    const api = {
      ENTITIES, get data() { return data; },
      now, today, list: n => list(n), get: (n, id) => clone(raw(n, id)), _raw: raw,
      create, update, transition, approve: (n, id, u, c) => decide(n, id, u, true, c), reject: (n, id, u, c) => decide(n, id, u, false, c), withdraw,
      availableTransitions, isLocked: (n, id) => { const r = raw(n, id); return !r || isLocked(n, r); },
      addAttachment, removeAttachment, comment, related, traceChain, derive, dueOf, dueItems, pendingApprovals, titleOf,
      integrityCheck, verify: (n, id) => { const errs = []; const r = raw(n, id); if (r) verifyRecord(n, r, errs); return { ok: !errs.length, errors: errs }; }, toCSV, auditTrailCSV, backup, inspectBackup, restore, kpis, logEvent,
      setClock: fn => { clock = fn; }, on: fn => listeners.push(fn),
      serialize: () => JSON.stringify(data), setCompany: (name, userId) => { data.meta.company = String(name || '').slice(0, 120); logEvent('company-renamed', userId, data.meta.company); }
    };
    return api;
  }

  return { createStore, ENTITIES, REVIEW_INPUT_TOPICS, sha256, canonical, QMSError, SCHEMA_VERSION, BACKUP_FORMAT, MAX_ATTACHMENT_BYTES, utils: { addDays, daysBetween, nextRev, validDate, isoDate, riskRating }, RESERVED };
});
