/* Core engine test suite — run: node tests/core.test.js  (no dependencies) */
const assert = require('assert');
const Core = require('../src/core.js');
const { seed } = require('../src/seed.js');
const { createStore, canonical, sha256 } = Core;

const results = [];
function test(name, fn) {
  try { fn(); results.push([true, name]); }
  catch (e) { results.push([false, name, e && e.stack ? e.stack.split('\n').slice(0, 3).join('\n') : String(e)]); }
}
const throwsQ = (fn, re) => assert.throws(fn, e => e instanceof Core.QMSError && (!re || re.test(e.message)), 'expected QMSError ' + (re || ''));
const fixedClock = iso => () => new Date(iso);
function demo() { const s = createStore(); const ids = seed(s); s.setClock(fixedClock('2026-11-27T12:00:00Z')); return { s, ids }; }
// Minimal store with two approvers and one plain user
function mini() {
  const s = createStore({ clock: fixedClock('2026-11-27T10:00:00Z') });
  const a = s.create('people', { name: 'Ann Approver', canApprove: 'Yes', isAdmin: 'Yes' }, '').id;
  const b = s.create('people', { name: 'Ben Approver', canApprove: 'Yes' }, a).id;
  const c = s.create('people', { name: 'Cal User' }, a).id;
  return { s, a, b, c };
}
function parseCSV(text) {
  text = text.replace(/^﻿/, ''); const rows = []; let row = [], f = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (q) { if (ch === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; }
    else if (ch === '"') q = true; else if (ch === ',') { row.push(f); f = ''; }
    else if (ch === '\r') { } else if (ch === '\n') { row.push(f); rows.push(row); row = []; f = ''; } else f += ch;
  }
  if (f || row.length) { row.push(f); rows.push(row); }
  return rows;
}

/* ---------------- crypto & helpers ---------------- */
test('SHA-256 matches NIST vectors', () => {
  assert.strictEqual(sha256('abc'), 'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
  assert.strictEqual(sha256(''), 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
  assert.strictEqual(sha256('abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq'), '248d6a61d20638b8e5c026930c3e6039a33ce45964ff2167f6ecedd419db06c1');
  assert.strictEqual(sha256('a'.repeat(1000000)), 'cdc76e5c9914fb9281a1c7e284d73e67f1809a48a497200e046d39ccc7112cd0');
  assert.strictEqual(sha256('héllo ✓'), require('crypto').createHash('sha256').update('héllo ✓').digest('hex'));
});
test('canonical JSON is key-order independent', () => { assert.strictEqual(canonical({ b: 1, a: [2, { d: 1, c: 2 }] }), canonical({ a: [2, { c: 2, d: 1 }], b: 1 })); });
test('revision letters increment A→B, Z→AA', () => { const n = Core.utils.nextRev; assert.strictEqual(n('A'), 'B'); assert.strictEqual(n('Z'), 'AA'); assert.strictEqual(n('AZ'), 'BA'); });

/* ---------------- demo data ---------------- */
test('demo data passes the full integrity check', () => { const { s } = demo(); const r = s.integrityCheck(); assert.ok(r.ok, JSON.stringify(r.errors.slice(0, 3))); assert.ok(r.count > 100); });
test('demo data covers every module', () => { const { s } = demo(); Object.keys(Core.ENTITIES).forEach(n => assert.ok(s.list(n).length > 0, n + ' empty')); });
test('demo seeding is deterministic', () => { const a = demo().s, b = demo().s; assert.strictEqual(sha256(canonical(a.data.records)), sha256(canonical(b.data.records))); });
test('flagship CAPA-0001 traversed the complete lifecycle in order with approvals', () => {
  const { s } = demo(); const c = s.get('capas', 'CAPA-0001');
  const path = c.history.filter(h => h.toStatus).map(h => h.toStatus);
  assert.deepStrictEqual(path, ['Containment', 'Root cause', 'Action plan', 'Implementation', 'Verification', 'Effectiveness review', 'Closed']);
  assert.strictEqual(c.status, 'Closed');
  assert.deepStrictEqual(c.approvals.map(a => a.decision), ['Rejected', 'Approved', 'Approved']);
  assert.ok(c.attachments.length >= 2);
});
test('flagship trace links complaint → NCR → CAPA → risk, document, training', () => {
  const { s } = demo();
  const t = s.traceChain('complaints', 'CMP-0001', 4).map(x => x.id);
  assert.ok(t.includes('CAPA-0001') && t.some(id => id.startsWith('NCR-')) && t.includes('RSK-0001'), t.join(','));
  const doc = s.list('documents').find(d => d.data.docNumber === 'WI-CNC-014');
  assert.strictEqual(doc.data.revision, 'B'); assert.strictEqual(doc.revisions.length, 2);
  assert.ok(/CAPA-0001/.test(doc.revisions[1].changeSummary));
});
test('trace from CAPA-0001 reaches the revised document and its training records, not unrelated process siblings', () => {
  const { s } = demo(); const t = s.traceChain('capas', 'CAPA-0001', 4);
  const doc = s.list('documents').find(d => d.data.docNumber === 'WI-CNC-014');
  assert.ok(t.some(x => x.id === doc.id), 'document'); assert.ok(t.some(x => x.entity === 'training'), 'training');
  assert.ok(!t.some(x => x.id === 'CAPA-0006'), 'should not fan out through the shared process');
});
test('demo includes a failed effectiveness check that looped back', () => {
  const { s } = demo(); const c = s.list('capas').find(x => x.history.some(h => h.transition === 'Not effective — reinvestigate'));
  assert.ok(c, 'no looped CAPA'); assert.ok(c.pending, 'looped CAPA should be awaiting action plan approval');
});
test('training currency detects retraining after a document revision', () => {
  const { s } = demo(); const cur = s.list('training').map(t => s.derive('training', t).currency);
  assert.ok(cur.some(c => /^Retraining needed/.test(c))); assert.ok(cur.includes('Superseded'));
});

/* ---------------- workflow ---------------- */
test('records start in the initial state with sequential IDs', () => {
  const { s, a } = mini();
  const r1 = s.create('risks', { title: 'R1', kind: 'Risk', description: 'd', likelihood: '2', severity: '3', reviewDate: '2027-01-01' }, a);
  const r2 = s.create('risks', { title: 'R2', kind: 'Risk', description: 'd', likelihood: '2', severity: '3', reviewDate: '2027-01-01' }, a);
  assert.strictEqual(r1.id, 'RSK-0001'); assert.strictEqual(r2.id, 'RSK-0002'); assert.strictEqual(r1.status, 'Open');
});
test('disallowed transitions are refused', () => {
  const { s, a } = mini();
  const c = s.create('capas', { title: 'T', source: 'Nonconformance', priority: 'Low', openedDate: '2026-11-01', dueDate: '2026-12-01', problem: 'p' }, a);
  throwsQ(() => s.transition('capas', c.id, 'Closed', a), /not allowed/);
});
test('required fields and guards block transitions', () => {
  const { s, a } = mini();
  const c = s.create('capas', { title: 'T', source: 'Nonconformance', priority: 'Low', openedDate: '2026-11-01', dueDate: '2026-12-01', problem: 'p' }, a);
  throwsQ(() => s.transition('capas', c.id, 'Containment', a), /Owner/);
  s.update('capas', c.id, { owner: a }, a); s.transition('capas', c.id, 'Containment', a);
  throwsQ(() => s.transition('capas', c.id, 'Root cause', a), /Containment actions/);
  s.update('capas', c.id, { containment: 'x' }, a); s.transition('capas', c.id, 'Root cause', a);
  s.update('capas', c.id, { rootCauseMethod: '5 Whys', rootCause: 'rc' }, a); s.transition('capas', c.id, 'Action plan', a);
  s.update('capas', c.id, { actions: [{ action: 'do' }] }, a);
  throwsQ(() => s.transition('capas', c.id, 'Implementation', a), /owner and due date/);
});
test('comment-required transitions need a comment', () => {
  const { s, a } = mini(); throwsQ(() => s.transition('people', 'PER-0003', 'Inactive', a), /comment is required/);
  s.transition('people', 'PER-0003', 'Inactive', a, 'left company'); assert.strictEqual(s.get('people', 'PER-0003').status, 'Inactive');
});
test('inactive users cannot act', () => {
  const { s, a, c } = mini(); s.transition('people', c, 'Inactive', a, 'left');
  throwsQ(() => s.create('processes', { name: 'X' }, c), /inactive/);
});
test('approval: pending locks record, segregation of duties, authority, rejection reason', () => {
  const { s, a, b, c } = mini();
  const d = s.create('documents', { docNumber: 'P-1', title: 'Proc', docType: 'Procedure', owner: a, content: 'text' }, a);
  const r = s.transition('documents', d.id, 'Effective', a); assert.ok(r.pendingApproval);
  assert.strictEqual(s.get('documents', d.id).status, 'Draft');
  throwsQ(() => s.update('documents', d.id, { title: 'changed' }, a), /awaiting approval/);
  throwsQ(() => s.approve('documents', d.id, a), /Segregation of duties/);
  throwsQ(() => s.approve('documents', d.id, c), /approval authority/);
  throwsQ(() => s.reject('documents', d.id, b, ''), /reason/);
  s.reject('documents', d.id, b, 'Needs scope section');
  assert.strictEqual(s.get('documents', d.id).pending, null);
  s.transition('documents', d.id, 'Effective', a); s.approve('documents', d.id, b, 'ok');
  const doc = s.get('documents', d.id);
  assert.strictEqual(doc.status, 'Effective'); assert.strictEqual(doc.data.effectiveDate, '2026-11-27'); assert.strictEqual(doc.data.nextReview, '2028-11-27');
  assert.strictEqual(doc.approvals.length, 2); assert.ok(/^[0-9a-f]{64}$/.test(doc.approvals[1].signatureHash));
});
test('only the requester can withdraw an approval request', () => {
  const { s, a, b } = mini();
  const d = s.create('documents', { docNumber: 'P-2', title: 'Proc', docType: 'Procedure', owner: a, content: 'text' }, a);
  s.transition('documents', d.id, 'Effective', a);
  throwsQ(() => s.withdraw('documents', d.id, b), /Only the requester/);
  s.withdraw('documents', d.id, a); assert.strictEqual(s.get('documents', d.id).pending, null);
});
test('conditional approval: NCR concession needs approval, rework does not', () => {
  const { s, a, b } = mini();
  const mk = disp => { const n = s.create('ncrs', { title: 'N', detectedDate: '2026-11-01', detectedAt: 'In-process', partNumber: 'P', severity: 'Minor', description: 'd', owner: a }, a); s.transition('ncrs', n.id, 'Under review', a); s.update('ncrs', n.id, { disposition: disp, dispositionNotes: 'why' }, a); return s.transition('ncrs', n.id, 'Dispositioned', a); };
  assert.strictEqual(mk('Rework').pendingApproval, false);
  assert.strictEqual(mk('Use as is (concession)').pendingApproval, true);
});
test('locked records refuse edits; revision workflow bumps revision and requires change summary', () => {
  const { s, a, b } = mini();
  const d = s.create('documents', { docNumber: 'P-3', title: 'Proc', docType: 'Procedure', owner: a, content: 'v1' }, a);
  s.transition('documents', d.id, 'Effective', a); s.approve('documents', d.id, b);
  throwsQ(() => s.update('documents', d.id, { content: 'v2' }, a), /locked/);
  s.transition('documents', d.id, 'Draft', a, 'update');
  assert.strictEqual(s.get('documents', d.id).data.revision, 'B');
  s.update('documents', d.id, { content: 'v2' }, a);
  throwsQ(() => s.transition('documents', d.id, 'Effective', a), /change summary/);
  s.update('documents', d.id, { changeSummary: 'changed text' }, a);
  s.transition('documents', d.id, 'Effective', a); s.approve('documents', d.id, b);
  const doc = s.get('documents', d.id);
  assert.deepStrictEqual(doc.revisions.map(r => r.revision), ['A', 'B']); assert.notStrictEqual(doc.revisions[0].contentHash, doc.revisions[1].contentHash);
});
test('readonly fields cannot be set through create/update', () => {
  const { s, a } = mini();
  const d = s.create('documents', { docNumber: 'P-4', title: 't', docType: 'Form', revision: 'Z', effectiveDate: '2020-01-01' }, a);
  assert.strictEqual(d.data.revision, 'A'); assert.strictEqual(d.data.effectiveDate, undefined);
});
test('equipment cannot return to service without a current passing calibration', () => {
  const { s, a, b } = mini();
  const e = s.create('equipment', { assetTag: 'T-1', name: 'Gauge', intervalDays: 30 }, a);
  s.transition('equipment', e.id, 'Out of service', a, 'check');
  throwsQ(() => s.transition('equipment', e.id, 'In service', a), /current passing calibration/);
  const c = s.create('calibrations', { equipment: e.id, calDate: '2026-11-20', certificateNo: 'C1', result: 'Pass' }, a);
  s.transition('calibrations', c.id, 'Approved', a); s.approve('calibrations', c.id, b);
  s.transition('equipment', e.id, 'In service', a);
  assert.strictEqual(s.derive('equipment', s.get('equipment', e.id)).nextDue, '2026-12-20');
});
test('supplier evaluation completion schedules the next evaluation on the supplier', () => {
  const { s, a, b } = mini();
  const sup = s.create('suppliers', { name: 'S', category: 'Packaging', criticality: 'Low', evalIntervalMonths: 6 }, a);
  throwsQ(() => s.transition('suppliers', sup.id, 'Approved', a), /completed evaluation/);
  const ev = s.create('supplierEvals', { supplier: sup.id, period: 'P', evaluator: a, evalDate: '2026-11-10', qualityScore: 90, deliveryScore: 80, responsivenessScore: 70 }, a);
  assert.deepStrictEqual(s.derive('supplierEvals', s.get('supplierEvals', ev.id)), { overall: 83, grade: 'B' });
  s.transition('supplierEvals', ev.id, 'Completed', a); s.approve('supplierEvals', ev.id, b);
  assert.strictEqual(s.get('suppliers', sup.id).data.nextEvaluation, '2027-05-10');
  s.transition('suppliers', sup.id, 'Approved', a); s.approve('suppliers', sup.id, b); assert.strictEqual(s.get('suppliers', sup.id).status, 'Approved');
});

/* ---------------- validation ---------------- */
test('field validation rejects bad input', () => {
  const { s, a } = mini();
  const base = { title: 'R', kind: 'Risk', description: 'd', likelihood: '2', severity: '3', reviewDate: '2027-01-01' };
  throwsQ(() => s.create('risks', Object.assign({}, base, { reviewDate: '2027-02-30' }), a), /invalid date/);
  throwsQ(() => s.create('risks', Object.assign({}, base, { likelihood: '9' }), a), /not an allowed value/);
  throwsQ(() => s.create('risks', Object.assign({}, base, { owner: 'PER-9999' }), a), /does not exist/);
  throwsQ(() => s.create('risks', Object.assign({}, base, { bogus: 1 }), a), /Unknown field/);
  throwsQ(() => s.create('risks', Object.assign({}, base, { title: '' }), a), /required/);
  throwsQ(() => s.create('suppliers', { name: 'X', category: 'Packaging', criticality: 'Low', evalIntervalMonths: 99 }, a), /maximum/);
  throwsQ(() => s.create('people', { name: 'X', email: 'not-an-email' }, a), /invalid email/);
  throwsQ(() => s.create('capas', { title: 'T', source: 'Nonconformance', priority: 'Low', openedDate: '2026-11-01', dueDate: '2026-12-01', problem: 'p', actions: [{ action: 'x', due: 'soon' }] }, a), /invalid date/);
  throwsQ(() => s.create('capas', { title: 'T', source: 'Nonconformance', priority: 'Low', openedDate: '2026-11-01', dueDate: '2026-12-01', problem: 'p', risks: ['RSK-0042'] }, a), /does not exist/);
});
test('unique fields are enforced case-insensitively', () => {
  const { s, a } = mini(); s.create('equipment', { assetTag: 'G-1', name: 'x', intervalDays: 10 }, a);
  throwsQ(() => s.create('equipment', { assetTag: 'g-1 ', name: 'y', intervalDays: 10 }, a), /already used/);
});
test('cross-field validation: rejected cannot exceed inspected', () => {
  const { s, a } = mini();
  const p = s.create('inspPlans', { title: 'P', partNumber: 'X', stage: 'Final', characteristics: [{ characteristic: 'c' }] }, a);
  throwsQ(() => s.create('inspections', { plan: p.id, inspDate: '2026-11-01', lot: 'L', inspector: a, qtyInspected: 5, qtyRejected: 6 }, a), /cannot exceed/);
});
test('empty table rows are dropped and text is trimmed', () => {
  const { s, a } = mini();
  const p = s.create('inspPlans', { title: '  P  ', partNumber: 'X', stage: 'Final', characteristics: [{ characteristic: ' c ' }, { characteristic: '', spec: '' }] }, a);
  assert.strictEqual(p.data.title, 'P'); assert.deepStrictEqual(p.data.characteristics, [{ characteristic: 'c' }]);
});
test('attachments: checksum stored, size limit enforced, removal needs reason and is logged', () => {
  const { s, a } = mini(); const r = s.create('processes', { name: 'X' }, a);
  const data = Buffer.from('evidence').toString('base64');
  const att = s.addAttachment('processes', r.id, { name: 'e.txt', data }, a);
  assert.strictEqual(att.sha256, sha256(data));
  throwsQ(() => s.addAttachment('processes', r.id, { name: 'big', data: 'A'.repeat(5 * 1024 * 1024) }, a), /limit/);
  throwsQ(() => s.removeAttachment('processes', r.id, att.id, a, ''), /reason/);
  s.removeAttachment('processes', r.id, att.id, a, 'wrong file');
  const h = s.get('processes', r.id).history; assert.strictEqual(h[h.length - 1].action, 'attachment-removed');
});
test('no-op updates do not create history entries', () => {
  const { s, a } = mini(); const r = s.create('processes', { name: 'X' }, a);
  const res = s.update('processes', r.id, { name: 'X ' }, a); assert.strictEqual(res.changes.length, 0); assert.strictEqual(s.get('processes', r.id).history.length, 1);
});

/* ---------------- integrity ---------------- */
function tamper(fn) { const { s } = demo(); const d = JSON.parse(s.serialize()); fn(d); return createStore({ data: d }).integrityCheck(); }
test('integrity detects direct content edits', () => { const r = tamper(d => { d.records.capas['CAPA-0001'].data.rootCause = 'edited'; }); assert.ok(r.errors.some(e => e.code === 'content-tampered' && /CAPA-0001/.test(e.where))); });
test('integrity detects status edits', () => { const r = tamper(d => { d.records.ncrs['NCR-0011'].status = 'Closed'; }); assert.ok(r.errors.some(e => e.code === 'content-tampered')); });
test('integrity detects altered history entries', () => { const r = tamper(d => { d.records.capas['CAPA-0001'].history[3].user = 'PER-0007'; }); assert.ok(r.errors.some(e => e.code === 'history-tampered')); });
test('integrity detects deleted history entries', () => { const r = tamper(d => { d.records.capas['CAPA-0001'].history.splice(4, 1); }); assert.ok(r.errors.some(e => e.code === 'chain-broken')); });
test('integrity detects dangling references', () => { const r = tamper(d => { delete d.records.capas['CAPA-0002']; }); assert.ok(r.errors.some(e => e.code === 'dangling-ref')); });
test('integrity detects corrupted evidence files', () => { const r = tamper(d => { d.records.capas['CAPA-0001'].attachments[0].data = Buffer.from('forged').toString('base64'); }); assert.ok(r.errors.some(e => e.code === 'attachment-corrupt')); });
test('integrity detects invalid status and unknown types', () => { const r = tamper(d => { d.records.risks['RSK-0001'].status = 'Whatever'; d.records.bogus = {}; }); assert.ok(r.errors.some(e => e.code === 'bad-status')); assert.ok(r.errors.some(e => e.code === 'unknown-type')); });
test('integrity detects duplicate unique values', () => { const r = tamper(d => { d.records.equipment['EQP-0002'].data.assetTag = 'CAL-0412'; }); assert.ok(r.errors.some(e => e.code === 'duplicate')); });

/* ---------------- exports ---------------- */
test('CSV export for every module: BOM, header, one row per record', () => {
  const { s } = demo();
  Object.keys(Core.ENTITIES).forEach(n => {
    const csv = s.toCSV(n); assert.ok(csv.startsWith('﻿'));
    const rows = parseCSV(csv); assert.strictEqual(rows.length, s.list(n).length + 1, n);
    assert.ok(rows.every(r => r.length === rows[0].length), n + ' ragged');
    assert.deepStrictEqual(rows[0].slice(0, 2), ['ID', 'Status']);
  });
});
test('CSV escapes quotes, commas, newlines and neutralizes formulas', () => {
  const { s, a } = mini();
  s.create('processes', { name: '=HYPERLINK("http://x")', purpose: 'line1\nline2, "quoted"' }, a);
  const rows = parseCSV(s.toCSV('processes'));
  const row = rows.find(r => r[0] === 'PRC-0001');
  assert.strictEqual(row[2], '\'=HYPERLINK("http://x")'); assert.strictEqual(row[4], 'line1\nline2, "quoted"');
});
test('audit trail CSV contains every change of every record, in time order', () => {
  const { s } = demo(); const rows = parseCSV(s.auditTrailCSV());
  let expected = 0; Object.keys(Core.ENTITIES).forEach(n => s.list(n).forEach(r => r.history.forEach(h => (expected += Math.max(1, (h.changes || []).length)))));
  assert.strictEqual(rows.length - 1, expected);
  const ts = rows.slice(1).map(r => r[0]); assert.deepStrictEqual(ts, ts.slice().sort());
});

/* ---------------- backup & restore ---------------- */
test('backup → JSON file → restore into a fresh store is lossless', () => {
  const { s } = demo(); const file = JSON.stringify(s.backup('PER-0001'));
  const fresh = createStore(); fresh.restore(file, '');
  assert.strictEqual(canonical(fresh.data.records), canonical(s.data.records));
  assert.ok(fresh.integrityCheck().ok);
  const att = fresh.get('capas', 'CAPA-0001').attachments[0]; assert.strictEqual(sha256(att.data), att.sha256);
});
test('restored database continues ID sequences without collision', () => {
  const { s } = demo(); const fresh = createStore({ clock: fixedClock('2026-11-28T09:00:00Z') }); fresh.restore(s.backup(''), '');
  const c = fresh.create('capas', { title: 'N', source: 'Risk review', priority: 'Low', openedDate: '2026-11-28', dueDate: '2026-12-28', problem: 'p' }, 'PER-0001');
  assert.strictEqual(c.id, 'CAPA-0008'); assert.ok(fresh.integrityCheck().ok);
});
test('restore refuses: invalid JSON, wrong format, checksum mismatch, newer schema', () => {
  const { s } = demo(); const b = s.backup('');
  throwsQ(() => createStore().restore('{not json', ''), /not valid JSON/);
  throwsQ(() => createStore().restore({ format: 'other' }, ''), /format/);
  const t = JSON.parse(JSON.stringify(b)); t.data.records.capas['CAPA-0001'].data.title = 'x';
  throwsQ(() => createStore().restore(t, ''), /Checksum/);
  const n = JSON.parse(JSON.stringify(b)); n.schemaVersion = 99;
  throwsQ(() => createStore().restore(n, ''), /newer schema/);
});
test('restore refuses a backup whose checksum was recomputed after tampering (integrity gate)', () => {
  const { s } = demo(); const t = JSON.parse(JSON.stringify(s.backup('')));
  t.data.records.capas['CAPA-0001'].data.title = 'forged'; t.sha256 = sha256(canonical(t.data));
  throwsQ(() => createStore().restore(t, ''), /integrity/);
});
test('failed restore leaves the current database untouched', () => {
  const { s } = demo(); const before = s.serialize();
  try { s.restore({ format: 'offline-qms-backup', formatVersion: 1, data: { meta: {}, records: {} }, sha256: 'x' }, ''); } catch (e) { /* expected */ }
  assert.strictEqual(s.serialize(), before);
});
test('backup and restore events are logged', () => {
  const { s } = demo(); const b = s.backup('PER-0001'); s.restore(b, 'PER-0001');
  const ev = s.data.meta.events.map(e => e.event); assert.ok(ev.includes('backup-restored'));
});

/* ---------------- KPIs & due items ---------------- */
test('KPIs agree with direct counts', () => {
  const { s } = demo(); const k = s.kpis().summary;
  assert.strictEqual(k.capaOpen, s.list('capas').filter(c => !['Closed', 'Cancelled'].includes(c.status)).length);
  assert.strictEqual(k.pendingApprovals, s.pendingApprovals().length);
  const ins = s.list('inspections').filter(r => r.status !== 'Open'); const q = ins.reduce((a, r) => a + r.data.qtyInspected, 0), rj = ins.reduce((a, r) => a + r.data.qtyRejected, 0);
  assert.strictEqual(k.firstPassYieldPct, +(100 * (1 - rj / q)).toFixed(2));
  assert.strictEqual(s.kpis().ncrByMonth.reduce((a, b) => a + b, 0), k.ncrLast12);
});
test('due items flag overdue work relative to the clock', () => {
  const { s } = demo(); const d = s.dueItems(0);
  assert.ok(d.length > 0 && d.every(x => x.date <= '2026-11-27'));
  s.setClock(fixedClock('2025-01-01T00:00:00Z')); assert.strictEqual(s.dueItems(0).filter(x => x.overdue).length, 0);
});
test('management review captured a KPI snapshot when held', () => {
  const { s } = demo(); const mr = s.get('reviews', 'MR-0001'); assert.strictEqual(mr.status, 'Minutes approved'); assert.ok(JSON.parse(mr.data.kpiSnapshot).capaOpen !== undefined);
});

/* ---------------- scale ---------------- */
test('performance: 2,000 extra records create and verify in reasonable time', () => {
  const { s } = demo(); const t0 = Date.now();
  for (let i = 0; i < 2000; i++) s.create('ncrs', { title: 'Bulk ' + i, detectedDate: '2026-10-01', detectedAt: 'In-process', partNumber: 'P' + i, severity: 'Minor', description: 'bulk' }, 'PER-0001');
  const t1 = Date.now(); const r = s.integrityCheck(); const t2 = Date.now();
  assert.ok(r.ok); console.log('    (create 2000: ' + (t1 - t0) + ' ms, integrity ' + r.count + ' records: ' + (t2 - t1) + ' ms)');
  assert.ok(t2 - t0 < 60000);
});

const failed = results.filter(r => !r[0]);
results.forEach(r => console.log((r[0] ? '  ok   ' : '  FAIL ') + r[1] + (r[0] ? '' : '\n' + r[2])));
console.log('\n' + (results.length - failed.length) + '/' + results.length + ' passed');
process.exit(failed.length ? 1 : 0);
