/* End-to-end UI tests in headless Chrome via Playwright.
   Run: node tests/ui.test.js   (requires the 'playwright' package and a Chrome/Chromium binary;
   set CHROME_PATH to use a specific browser executable) */
const fs = require('fs'), path = require('path'), os = require('os');
let chromium; try { ({ chromium } = require('playwright')); } catch (e) { console.error('Playwright is not installed: npm i -D playwright'); process.exit(2); }
const FILE = 'file://' + path.resolve(__dirname, '..', 'dist', 'qms.html');
const SHOTS = path.resolve(__dirname, '..', 'docs', 'screenshots'); fs.mkdirSync(SHOTS, { recursive: true });
const results = []; let page, ctx, browser, pageErrors = [], netRequests = [];
async function test(name, fn) { try { await fn(); results.push([true, name]); } catch (e) { results.push([false, name, String(e && e.stack || e).split('\n').slice(0, 4).join('\n')]); } }
const ok = (c, m) => { if (!c) throw new Error(m || 'assertion failed'); };
const go = async h => { await page.evaluate(x => { location.hash = x; }, h); await page.waitForTimeout(60); };
const store = (fn, arg) => page.evaluate(fn, arg);
const asUser = async id => { await page.selectOption('#userSel', id); await page.waitForTimeout(50); };
const dlgOK = async () => { await page.waitForSelector('#dlg[open]'); await page.click('#dlg button[type=submit]'); await page.waitForSelector('#dlg[open]', { state: 'detached' }); await page.waitForTimeout(80); };
const goBtn = async to => { await page.click('button[data-act=go][data-to="' + to + '"]'); await page.waitForTimeout(80); };
const status = id => store(i => window.QMSApp.store.get('capas', i).status.toString(), id);

(async () => {
  browser = await chromium.launch({ executablePath: process.env.CHROME_PATH || (fs.existsSync('/usr/bin/google-chrome') ? '/usr/bin/google-chrome' : undefined) });
  ctx = await browser.newContext({ viewport: { width: 1440, height: 900 }, acceptDownloads: true });
  page = await ctx.newPage();
  page.on('pageerror', e => pageErrors.push(e.message));
  page.on('console', m => { if (m.type() === 'error') pageErrors.push(m.text()); });
  page.on('request', r => { if (!r.url().startsWith('file:') && !r.url().startsWith('data:') && !r.url().startsWith('blob:')) netRequests.push(r.url()); });

  await test('first run shows setup; demo data loads', async () => {
    await page.goto(FILE); await page.waitForSelector('[data-act=setupDemo]');
    await page.click('[data-act=setupDemo]'); await page.waitForSelector('.tiles .tile');
    ok((await page.$$('.tile')).length === 8, 'expected 8 KPI tiles');
    ok(await store(() => window.QMSApp.store.integrityCheck().ok), 'integrity');
  });
  await test('data persists across reload (IndexedDB)', async () => {
    await page.reload(); await page.waitForSelector('.tiles');
    ok(await page.evaluate(() => window.QMSApp.Storage.mode) === 'indexeddb', 'storage mode');
    ok(await store(() => window.QMSApp.store.list('capas').length) === 7);
  });
  await test('every module list renders with rows and sortable headers', async () => {
    const mods = await store(() => Object.keys(window.QMSCore.ENTITIES));
    for (const n of mods) { await go('#/list/' + n); await page.waitForSelector('table.grid tbody tr'); }
    await go('#/list/capas'); await page.click('button.sort[data-k="d.score"], button.sort[data-k="dueDate"]').catch(() => {});
  });
  await test('every record renders on every tab without errors', async () => {
    const recs = await store(() => { const s = window.QMSApp.store; return Object.keys(window.QMSCore.ENTITIES).flatMap(n => s.list(n).map(r => [n, r.id])); });
    for (const [n, id] of recs) for (const tab of ['details', 'related', 'evidence', 'history', 'approvals']) {
      await page.evaluate(h => { location.hash = h; }, '#/rec/' + n + '/' + id + '/' + tab);
      await page.waitForSelector('.rec-head h1');
      if (tab === 'history') ok(await page.$('.banner.info'), 'history not verified for ' + id);
    }
    ok(pageErrors.length === 0, pageErrors.join('; '));
  });
  await test('every report and the data page render', async () => {
    for (const r of ['capa', 'due', 'trace', 'training', 'calibration', 'suppliers', 'audits', 'activity']) { await go('#/reports/' + r); await page.waitForSelector('.page-head h1'); }
    await go('#/reports/trace?id=CAPA-0001'); await page.waitForSelector('text=Lifecycle');
    await go('#/data'); await page.waitForSelector('text=Integrity check');
  });

  await test('validation: missing required fields shows errors and creates nothing', async () => {
    await asUser('PER-0003'); await go('#/new/capas'); await page.waitForSelector('#recForm');
    const before = await store(() => window.QMSApp.store.list('capas').length);
    await page.click('#recForm button[type=submit]'); await page.waitForSelector('.form-err .banner');
    ok(await store(() => window.QMSApp.store.list('capas').length) === before);
  });

  await test('full corrective-action lifecycle through the UI with approvals and segregation of duties', async () => {
    await asUser('PER-0003'); await go('#/new/capas'); await page.waitForSelector('#f_title');
    await page.fill('#f_title', 'UI test: torque values not recorded');
    await page.selectOption('#f_source', 'Internal audit');
    await page.selectOption('#f_priority', 'High');
    await page.fill('#f_dueDate', '2027-02-26');
    await page.fill('#f_problem', 'Torque values missing on 3 of 10 assembly travellers.');
    await page.click('#recForm button[type=submit]');
    await page.waitForFunction(() => /#\/rec\/capas\/CAPA-\d+/.test(location.hash));
    const id = await page.evaluate(() => location.hash.split('/')[3]);
    await goBtn('Containment'); ok(await status(id) === 'Containment');
    await page.fill('#f_containment', 'Re-torqued and recorded all open travellers.');
    await goBtn('Root cause'); ok(await status(id) === 'Root cause', 'auto-save before transition');
    await page.selectOption('#f_rootCauseMethod', '5 Whys'); await page.fill('#f_rootCause', 'Traveller has no torque value field.');
    await goBtn('Action plan');
    await page.fill('#f_actions_0_action', 'Add torque field to traveller'); await page.selectOption('#f_actions_0_owner', 'PER-0003'); await page.fill('#f_actions_0_due', '2027-01-15');
    await page.click('[data-act=addrow][data-k=actions]');
    await page.fill('#f_actions_1_action', 'Brief assembly team'); await page.selectOption('#f_actions_1_owner', 'PER-0002'); await page.fill('#f_actions_1_due', '2027-01-22');
    await goBtn('Implementation'); await dlgOK();
    ok(await store(i => !!window.QMSApp.store.get('capas', i).pending, id), 'pending');
    ok(!(await page.$('button[data-act=approve]')), 'requester must not see Approve');
    await asUser('PER-0001'); await page.click('button[data-act=approve]'); await dlgOK();
    ok(await status(id) === 'Implementation');
    await asUser('PER-0003');
    for (const i of [0, 1]) { await page.selectOption('#f_actions_' + i + '_status', 'Done'); await page.fill('#f_actions_' + i + '_completedOn', '2027-01-10'); }
    await goBtn('Verification'); ok(await status(id) === 'Verification');
    await page.fill('#f_verification', 'Checked 20 travellers, all with torque values.');
    await goBtn('Effectiveness review');
    await page.selectOption('#f_effectivenessResult', 'Effective'); await page.fill('#f_effectivenessEvidence', 'Next audit sample 30/30 complete.');
    await goBtn('Closed'); await dlgOK();
    await asUser('PER-0007'); await page.click('button[data-act=approve]'); await dlgOK();
    ok(await status(id) === 'Closed', 'closed');
    const pathTaken = await store(i => window.QMSApp.store.get('capas', i).history.filter(h => h.toStatus).map(h => h.toStatus).join('>'), id);
    ok(pathTaken === 'Containment>Root cause>Action plan>Implementation>Verification>Effectiveness review>Closed', pathTaken);
    ok(await page.$('.badge >> text=Locked'), 'closed record shows locked');
    ok(await store(() => window.QMSApp.store.integrityCheck().ok));
    await page.screenshot({ path: path.join(SHOTS, 'capa-closed.png') });
  });

  await test('reject with reason returns record to requester', async () => {
    await asUser('PER-0003'); await go('#/rec/documents/DOC-0010');
    await asUser('PER-0001'); await page.click('button[data-act=reject]');
    await page.click('#dlg button[type=submit]'); ok(await page.textContent('#dlg .dlg-err'), 'reason required');
    await page.fill('#dlg textarea', 'Add drop-test reference.'); await page.click('#dlg button[type=submit]');
    ok(await store(() => window.QMSApp.store.get('documents', 'DOC-0010').pending === null));
  });

  await test('evidence upload, checksum, download round-trip', async () => {
    await asUser('PER-0003'); await go('#/rec/capas/CAPA-0004/evidence');
    await page.setInputFiles('#attFile', { name: 'photo-evidence.txt', mimeType: 'text/plain', buffer: Buffer.from('measured 12.004 mm') });
    await page.click('#attForm button[type=submit]'); await page.waitForSelector('text=photo-evidence.txt');
    const [dl] = await Promise.all([page.waitForEvent('download'), page.click('tr:has-text("photo-evidence.txt") [data-act=dl-att]')]);
    ok(fs.readFileSync(await dl.path(), 'utf8') === 'measured 12.004 mm', 'download content');
  });

  await test('unsaved-changes guard intercepts navigation', async () => {
    await go('#/rec/capas/CAPA-0007'); await page.fill('#f_containment', 'draft text');
    await page.evaluate(() => { location.hash = '#/dashboard'; }); await page.waitForSelector('#dlg[open]');
    await page.click('#dlg [data-x=cancel]'); ok((await page.inputValue('#f_containment')) === 'draft text', 'edits kept');
    await page.click('[data-act=discard]');
  });

  await test('CSV and audit-trail exports download valid files', async () => {
    await go('#/list/ncrs');
    const [d1] = await Promise.all([page.waitForEvent('download'), page.click('[data-act=csv][data-n=ncrs]')]);
    const csv = fs.readFileSync(await d1.path(), 'utf8'); const n = await store(() => window.QMSApp.store.list('ncrs').length);
    ok(csv.trim().split(/\r\n(?=NCR-|ID,)/).length === n + 1, 'row count');
    await go('#/data');
    const [d2] = await Promise.all([page.waitForEvent('download'), page.click('[data-act=auditcsv]')]);
    ok(fs.readFileSync(await d2.path(), 'utf8').includes('approved-transition'));
    await go('#/reports/capa');
    const [d3] = await Promise.all([page.waitForEvent('download'), page.click('[data-act=rpt-csv]')]);
    ok(fs.readFileSync(await d3.path(), 'utf8').includes('CAPA-0001'));
  });

  let backupPath;
  await test('backup download, destructive change, restore, then undo restore', async () => {
    await asUser('PER-0001'); await go('#/data');
    const [d] = await Promise.all([page.waitForEvent('download'), page.click('[data-act=backup]')]);
    backupPath = path.join(os.tmpdir(), 'qms-ui-backup.json'); fs.copyFileSync(await d.path(), backupPath);
    const b = JSON.parse(fs.readFileSync(backupPath, 'utf8')); ok(b.format === 'offline-qms-backup' && b.sha256.length === 64);
    const countBefore = b.recordCount;
    await store(() => window.QMSApp.store.create('processes', { name: 'Added after backup' }, 'PER-0001'));
    await page.setInputFiles('#restoreFile', backupPath); await page.waitForSelector('#dlg[open] >> text=Restore this backup?'); await dlgOK();
    await page.waitForSelector('text=Undo last restore');
    const after = await store(() => { const s = window.QMSApp.store; return Object.keys(window.QMSCore.ENTITIES).reduce((a, n) => a + s.list(n).length, 0); });
    ok(after === countBefore, 'restored count ' + after + ' vs ' + countBefore);
    ok(!(await store(() => window.QMSApp.store.list('processes').some(p => p.data.name === 'Added after backup'))));
    await page.click('[data-act=undoRestore]'); await dlgOK();
    ok(await store(() => window.QMSApp.store.list('processes').some(p => p.data.name === 'Added after backup')), 'undo restored newer state');
    await page.reload(); await page.waitForSelector('.page-head');
    ok(await store(() => window.QMSApp.store.list('processes').some(p => p.data.name === 'Added after backup')), 'undo persisted');
  });
  await test('tampered backup is rejected and nothing changes', async () => {
    const b = JSON.parse(fs.readFileSync(backupPath, 'utf8')); b.data.records.capas['CAPA-0001'].data.title = 'forged';
    const bad = path.join(os.tmpdir(), 'qms-bad.json'); fs.writeFileSync(bad, JSON.stringify(b));
    const before = await store(() => window.QMSApp.store.serialize().length);
    await go('#/data'); await page.setInputFiles('#restoreFile', bad);
    await page.waitForSelector('#dlg[open] >> text=Backup rejected'); ok(await page.$('#dlg >> text=Checksum mismatch')); await dlgOK();
    ok(before === await store(() => window.QMSApp.store.serialize().length));
  });
  await test('integrity check button reports tampering made outside the app', async () => {
    await store(() => { window.QMSApp.store._raw('risks', 'RSK-0002').data.title = 'edited in devtools'; });
    await go('#/data'); await page.click('[data-act=integrity]'); await page.waitForSelector('.banner.crit >> text=RSK-0002');
  });
  await test('restore from setup screen after storage is cleared', async () => {
    await page.evaluate(async () => { await window.QMSApp.Storage.del('database'); });
    await page.reload(); await page.waitForSelector('#setupRestore');
    await page.setInputFiles('#setupRestore', backupPath); await dlgOK(); await page.waitForSelector('text=Integrity check');
    ok(await store(() => window.QMSApp.store.integrityCheck().ok));
  });

  await test('no network requests were made (fully offline)', async () => { ok(netRequests.length === 0, netRequests.join(', ')); });
  await test('form controls all have accessible names', async () => {
    await asUser('PER-0001');
    for (const h of ['#/new/capas', '#/rec/capas/CAPA-0007', '#/list/capas', '#/new/reviews', '#/data']) {
      await go(h); await page.waitForSelector('.page-head, .rec-head');
      const unlabeled = await page.evaluate(() => Array.from(document.querySelectorAll('main input:not([type=hidden]), main select, main textarea')).filter(el => { if (el.getAttribute('aria-label')) return false; if (el.id && document.querySelector('label[for="' + el.id + '"]')) return false; if (el.closest('label')) return false; return true; }).map(el => el.id || el.outerHTML.slice(0, 60)));
      ok(!unlabeled.length, h + ': ' + unlabeled.join(', '));
    }
  });
  await test('keyboard: "/" focuses search; tab order reaches workflow buttons', async () => {
    await go('#/list/capas'); await page.click('h1'); await page.keyboard.press('/');
    ok(await page.evaluate(() => document.activeElement.id) === 'listSearch');
    await page.keyboard.type('bore'); await page.waitForTimeout(300);
    ok((await page.$$('table.grid tbody tr')).length >= 1);
    await page.click('[data-act=clearFilters]');
  });

  await test('responsive layouts: no page-level horizontal overflow at standard breakpoints', async () => {
    const sizes = [[320, 640], [375, 812], [414, 896], [768, 1024], [1024, 768], [1280, 800], [1920, 1080], [2560, 1440]];
    const routes = ['#/dashboard', '#/list/capas', '#/rec/capas/CAPA-0001', '#/rec/audits/AUD-0001', '#/reports/training', '#/data'];
    const problems = [];
    for (const [w, h] of sizes) {
      await page.setViewportSize({ width: w, height: h });
      for (const r of routes) {
        await go(r); await page.waitForSelector('.page-head, .rec-head');
        const o = await page.evaluate(() => ({ doc: document.documentElement.scrollWidth - window.innerWidth, main: document.querySelector('main').scrollWidth - document.querySelector('main').clientWidth }));
        if (o.doc > 0 || o.main > 1) problems.push(w + 'px ' + r + ' overflow doc ' + o.doc + ' main ' + o.main);
      }
      if ([375, 768, 1440, 1920].includes(w) || w === 1280) { await go('#/dashboard'); await page.screenshot({ path: path.join(SHOTS, 'dashboard-' + w + '.png') }); }
    }
    ok(!problems.length, problems.join('\n'));
  });
  await test('mobile navigation drawer opens and closes with Escape', async () => {
    await page.setViewportSize({ width: 375, height: 812 }); await go('#/dashboard');
    await page.click('#menuBtn'); ok(await page.evaluate(() => document.body.classList.contains('nav-open')));
    await page.screenshot({ path: path.join(SHOTS, 'mobile-nav.png') });
    await page.keyboard.press('Escape'); ok(!(await page.evaluate(() => document.body.classList.contains('nav-open'))));
    await go('#/rec/capas/CAPA-0001'); await page.screenshot({ path: path.join(SHOTS, 'mobile-capa.png'), fullPage: false });
  });
  await test('dark theme and print stylesheet render', async () => {
    await page.setViewportSize({ width: 1440, height: 900 });
    await page.click('#themeBtn'); ok(await page.evaluate(() => document.documentElement.dataset.theme) === 'dark');
    await go('#/dashboard'); await page.screenshot({ path: path.join(SHOTS, 'dashboard-dark.png') });
    await go('#/rec/capas/CAPA-0001/related'); await page.screenshot({ path: path.join(SHOTS, 'capa-trace-dark.png') });
    await page.click('#themeBtn');
    await go('#/reports/trace?id=CAPA-0001'); await page.emulateMedia({ media: 'print' });
    await page.screenshot({ path: path.join(SHOTS, 'report-print.png'), fullPage: true }); await page.emulateMedia({ media: 'screen' });
    for (const [h, f] of [['#/rec/capas/CAPA-0001', 'capa-record.png'], ['#/list/capas', 'capa-list.png'], ['#/rec/capas/CAPA-0001/history', 'capa-history.png'], ['#/reports/training', 'training-matrix.png'], ['#/work', 'my-work.png'], ['#/data', 'data-page.png']]) { await go(h); await page.screenshot({ path: path.join(SHOTS, f) }); }
  });
  await test('no uncaught page errors during the whole run', async () => { ok(pageErrors.length === 0, pageErrors.join('\n')); });

  await browser.close();
  const failed = results.filter(r => !r[0]);
  results.forEach(r => console.log((r[0] ? '  ok   ' : '  FAIL ') + r[1] + (r[0] ? '' : '\n' + r[2])));
  console.log('\n' + (results.length - failed.length) + '/' + results.length + ' passed');
  process.exit(failed.length ? 1 : 0);
})();
