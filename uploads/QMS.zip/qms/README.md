# Offline QMS

An offline quality management system aligned with ISO 9001:2015 principles. The whole application is one HTML file. It runs in any modern browser with no server, no install, no network connection and no third-party code.

> **Important.** This software supports a quality management system. Using it does not by itself make an organization conform to ISO 9001:2015, and it does not guarantee certification. An accredited certification body decides certification after auditing how the organization actually works. This project does not reproduce the text of the standard. It refers to clause numbers only, so keep a licensed copy of ISO 9001:2015 for the requirements themselves.

## Quick start

1. Open `dist/qms.html` in Chrome, Edge, Firefox or Safari (double-click works).
2. Choose **Load demonstration data** to explore, or **Start empty** to set up your organization.
3. Use **Acting as** (top right) to choose the user. Approvals need a *different* user who has approval authority.
4. Go to **Data, backup & integrity → Download backup** and download a backup regularly.

## What's included

| Module | Clause | Highlights |
|---|---|---|
| Processes | 4.4 | Process owners, inputs/outputs and measures. Every other record links to a process |
| Risk register | 6.1 | Likelihood × impact scoring, residual risk, heat map, review dates |
| Quality objectives | 6.2 | Targets, direction, monthly measurements, on/off-target status, sparklines |
| Documents | 7.5 | Numbering, Draft → Effective approval, revision letters, revision history with content hashes, periodic review dates, link to the CAPA that drove a change |
| Training records | 7.2 / 7.3 | Assigned → Completed → Verified (competence approval), records which revision was trained, **flags retraining automatically when a document is revised**, training matrix report |
| Equipment and calibration records | 7.1.5 | Intervals, next-due calculation, overdue status; failed calibrations require an impact assessment; equipment cannot return to service without a current passing calibration |
| Customer complaints | 8.2.1 / 9.1.2 | Response due dates, investigation, response, customer acceptance; major complaints need a CAPA before closure |
| Nonconformances | 8.7 | Detection point, disposition, concession and critical items need approval, major NCRs need a CAPA before closure |
| Inspection plans and inspection records | 8.5.1 / 8.6 | Characteristics with gauges linked to calibrated equipment; lot acceptance requires an NCR for any rejected pieces; yield trend |
| Suppliers and supplier evaluations | 8.4 | Weighted scoring (quality 50%, delivery 30%, responsiveness 20%), grade A–D, approval requires a completed evaluation, re-evaluation scheduling |
| Internal audits | 9.2 | Audit programme, findings table, every nonconformity finding needs a CAPA before closure |
| Management reviews | 9.3 | Input checklist, decisions/actions with owners, **automatic KPI snapshot** when the meeting is recorded, minutes approval |
| Corrective actions (CAPA) | 10.2 | Open → Containment → Root cause → Action plan (approval) → Implementation → Verification → Effectiveness review → Closed (approval), plus a "not effective → reinvestigate" loop |
| Dashboard and reports | 9.1 | Live KPIs, NCR trend, yield trend, CAPA stages, risk heat map, objectives, due list; 8 printable reports with CSV export |

**Cross-cutting features:** approval workflow with segregation of duties and signature hashes; tamper-evident, hash-chained revision history on every record; evidence attachments with SHA-256 checksums; due dates and overdue tracking everywhere; relationship and traceability views; full-text search; CSV and audit-trail exports; checksummed JSON backup and verified restore with undo; light and dark themes; keyboard support; responsive layouts from 320 px to 2560 px; print stylesheet.

## Demonstration data

The demo is a fictional company, *Halvorsen Precision Machining*, with 122 linked records dated January to November 2026. Every name, customer and supplier is invented. The data is generated through the application's own API, so every history entry, approval and hash is genuine. Highlights:

- **CAPA-0001 shows the complete lifecycle.** A customer complaint (CMP-0001) leads to an NCR, then containment, a 5-Whys root cause, and an action plan that is *rejected once* by the approver and then approved. The actions are a work-instruction revision to rev B (with a wear study attached), a change to the inspection plan, retraining, and a risk-register update. The CAPA then passes implementation verification and a 60-day effectiveness check backed by data, and is closed by the General Manager.
- **CAPA-0006** failed its effectiveness check and looped back to root cause. Its revised plan is awaiting approval.
- Other CAPAs sit at containment (overdue), root cause (supplier SCAR), implementation and effectiveness review.
- A failed height-gauge calibration leads to an impact assessment, an NCR, a CAPA and a procedure revision.
- A supplier was downgraded to *Conditional* after two coating escapes.
- One employee is flagged for retraining after an inspection instruction was revised.

## Project layout

```
dist/qms.html            the application (build output, one file, ~235 KB)
src/core.js              engine: schema, validation, workflows, approvals, history, integrity, exports, backup, KPIs
src/seed.js              demonstration data script
src/app.js               browser user interface
src/index.template.html  page shell and styles
build.js                 inlines the sources into dist/qms.html
tests/core.test.js       50 engine tests (Node only, no dependencies)
tests/ui.test.js         22 end-to-end browser tests (Playwright + Chrome)
docs/                    user guide, administration and data guide, validation report, screenshots
```

## Build and test

You need Node.js 18 or later. There are no runtime dependencies.

```bash
node build.js              # writes dist/qms.html
node tests/core.test.js    # engine tests
npm i -D playwright        # only for the browser tests
node tests/ui.test.js      # set CHROME_PATH if Chrome is not at /usr/bin/google-chrome
```

## Know before you deploy

- **Single-user, per-browser storage.** Data lives in this browser profile's IndexedDB on this computer. It is not shared between computers or browsers. To move data, use backup and restore. See `docs/ADMINISTRATION.md` for deployment patterns.
- **User selection is not authentication.** Anyone who can open the browser profile can act as any user. Segregation of duties is enforced between *named users* in the system, not against impersonation. Protect access with operating-system accounts.
- **Tamper-evident, not tamper-proof.** The hash chain detects edits made outside the application. Someone with the source code and enough skill could rebuild a consistent chain. Off-site backups are the real control.
- **Clearing browser data deletes the database.** Download backups on a schedule and keep them off the machine.

## License

MIT. See `LICENSE`.
