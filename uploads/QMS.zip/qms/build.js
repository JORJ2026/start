#!/usr/bin/env node
// Builds dist/qms.html: one self-contained offline file (core + seed + app inlined).
const fs = require('fs'), path = require('path');
const src = f => fs.readFileSync(path.join(__dirname, 'src', f), 'utf8');
const parts = { CORE: src('core.js'), SEED: src('seed.js'), APP: src('app.js') };
for (const [k, v] of Object.entries(parts)) if (/<\/script/i.test(v)) throw new Error(k + ' contains a closing script tag');
let html = src('index.template.html');
for (const [k, v] of Object.entries(parts)) html = html.replace('/*@@' + k + '@@*/', () => v);
const pkg = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8'));
html = html.replace('<title>Offline QMS</title>', () => '<title>Offline QMS</title>\n<meta name="generator" content="offline-qms ' + pkg.version + '">');
fs.mkdirSync(path.join(__dirname, 'dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'dist', 'qms.html'), html);
console.log('dist/qms.html', (html.length / 1024).toFixed(1) + ' KB');
