# Forge ERP

Forge ERP is an offline ERP for a small manufacturer and distributor. It runs on one computer, and other people can use it from a browser on the local network.

It needs no internet connection and no third-party packages. The only requirement is Python 3.10 or newer, which includes SQLite. It has been tested on Python 3.11 and 3.13.

## Start

```
python3 run.py            # first run creates data/erp.db with 12 months of demo history
python3 run.py --demo     # discard the database (after backing it up) and regenerate demo data
ERP_EMPTY=1 python3 run.py   # first run with an empty database (admin / admin only)
```

On Windows you can double-click `start-windows.bat`. On macOS or Linux, run `./start-mac-linux.sh`.

The app opens at http://127.0.0.1:8765.

**Demo accounts.** All of these are flagged with a "change your password" banner until you change them.

| User | Password | Role | Can do |
|---|---|---|---|
| admin | admin | admin | everything, including users, settings, backup/restore and stock rebuild |
| pmorgan | manager | manager | approve any PO, cancel/void, override credit, adjust stock, bulk edit, import |
| sramirez, pdesai, jwhitaker, gokafor | clerk | clerk | create and process documents, record payments, POs up to the approval limit |
| auditor | viewer | viewer | read-only, with pay rates hidden |

## What's included

| Area | Capabilities |
|---|---|
| Customers / suppliers | Contacts, terms, credit limits, tax exemption, lead times, live AR/AP balances, customer statements |
| Items & inventory | Raw, component, finished and service items; multiple locations; moving-average cost; immutable ledger with running balances; adjustments, cycle counts, transfers; reorder suggestions |
| Purchasing (procure-to-pay) | PO draft → approval (with approval limit) → partial or complete receipts (with over-receipt tolerance) → supplier bill (three-way match: bills cover only received quantity) → payment. Short-close and cancel are supported. |
| Sales (order-to-cash) | SO draft → confirm (credit-limit check; a manager can override, and the override is audited) → partial shipments → one invoice per shipment → full or partial payments; void and re-invoice; backorders |
| Manufacturing | Multi-level BOMs with scrap %, labor and overhead; cycle detection; production orders: plan → release → report output (backflushes components, receives finished goods at actual cost) → close short or cancel |
| Employees & assets | Org chart (manager), departments, pay data (hidden from clerks and viewers); fixed assets with straight-line depreciation, assignment, location and service log |
| Documents | Printable purchase order, invoice, packing slip, receiving report, production traveler/pick list, and customer statement. Use the browser's print dialog to save as PDF. |
| Dashboards & reports | KPIs (revenue, margin, AR/AP, inventory, backlog, late items) plus a 12-month revenue and COGS trend. Reports: inventory valuation, stock movement, reorder (one click creates draft POs), open order backlog, sales by customer and by item with margin, AR and AP aging, purchases by supplier with on-time rate, production cost vs standard, asset register, headcount |
| Global search | Ctrl K or `/` searches across customers, suppliers, items, every document type, employees and assets |
| Bulk editing | Select rows, then set a value, add an amount, or change by a percentage. Allowed fields are whitelisted, everything runs in one transaction, and each row is audited. |
| Spreadsheets | Every list and report exports to CSV and .xlsx. Master data imports from .xlsx or .csv: you validate first, then the import commits all-or-nothing (rows are upserted by code/SKU/tag, and blank cells keep current values). A backup is taken before each import, and templates are provided. |
| Integrity | Foreign keys with RESTRICT, CHECK constraints, status-machine guards, and atomic transactions that roll everything back on error, including document numbers. A reconciliation screen runs 14 checks, and admins can rebuild stock from the ledger. |
| Audit log | Every create, update (with before/after values), status change, payment, import, bulk edit, setting change, sign-in, backup and restore |
| Backup / restore | Hot backups via SQLite's online backup API, plus an automatic backup at each startup with retention. Every backup is integrity-checked before restore, a safety backup is taken first, and you can upload or download backups. |
| Configurable rules | Settings → tax rate, credit enforcement, negative stock, over-receipt tolerance, PO approval limit, three-way match, auto-invoice on ship, backup retention, session length, company details |

## Demo data

`erp/seed.py` simulates 12 months of business, using the same service layer that the app itself uses:

- about 160 purchase orders, with receipts (some partial), bills and payments
- about 330 production orders that consume components
- about 880 sales orders, with shipments (including transfers between sites to fill orders), invoices and payments (three customers pay late)
- monthly cycle counts and transfers
- credit-limit holds left as drafts
- 34 items, 11 BOMs, 24 customers, 8 suppliers, 23 employees and 16 assets

The run ends with live open work: draft and approved POs, released production orders, the open backlog, and overdue receivables. The generated data passes every reconciliation check.

## Tests

```
python3 -m unittest discover -s tests -v
```

There are 31 tests. One of them, the openpyxl compatibility check, is skipped when openpyxl isn't installed.

- **Inventory reconciliation**
  - Moving-average cost arithmetic.
  - A full buy → make → ship → invoice → pay cycle, checked against exact quantities, COGS and tax.
  - Corruption of the stock table is detected, and Rebuild repairs it.
  - Mismatches between documents and their lines are detected.
  - Cycle counts and transfers.
  - The negative-stock setting.
  - A 120-day seeded dataset reconciles with no exceptions.
- **Transaction dependencies**
  - An order can't ship until it's confirmed, and can't ship more than ordered.
  - A shipment that fails mid-way writes nothing and doesn't consume a document number.
  - Double invoicing, overpayment, and voiding a paid invoice are blocked.
  - Three-way match, over-receipt tolerance, and no cancelling a PO that has receipts.
  - The PO approval limit applies by role.
  - Credit limits, plus manager-only override.
  - Records can't be deleted while other records reference them.
  - BOM cycles are rejected, production checks for component shortages, and orders can be closed short.
  - Only drafts can be edited.
  - The audit trail records before/after values.
- **Data recovery**
  - Back up → change data → restore → restore the safety copy.
  - Corrupt, foreign and non-SQLite files, and path traversal attempts, are rejected, and live data is left untouched.
  - A simulated crash in the middle of a transaction leaves no partial data.
- **Import/export**
  - .xlsx round trip and dry-run vs commit.
  - All-or-nothing on errors.
  - CSV formula injection is neutralised.
  - Bulk edit permissions.
- **HTTP**
  - Sign-in is required.
  - CSRF and Origin checks.
  - Role enforcement.
  - Lockout after repeated failed sign-ins.
  - Host-header (DNS-rebinding) rejection.
  - Keep-alive request framing.
  - The import endpoint.

The browser UI was also driven end to end in headless Chrome. The run went through both lifecycles entirely through the UI, in desktop, mobile (390 px) and dark-mode layouts:

- order → confirm → ship → invoice → payment
- PO → approve → partial receipt → bill → payment
- bulk edit, search, restore

## Architecture

```
run.py            launcher (startup backup, optional demo seed, opens the browser)
erp/db.py         schema, views, settings, numbering, transactions, audit helper
erp/services.py   business rules: inventory ledger, P2P, O2C, manufacturing, planning, reconciliation
erp/entities.py   metadata for every list/form; generic CRUD, bulk edit, import/export, search
erp/reports.py    dashboard and reports
erp/documents.py  composite record loading + printable documents
erp/backup.py     online backup, verification, restore
erp/auth.py       PBKDF2 passwords, sessions, CSRF, lockout
erp/server.py     stdlib HTTP server and JSON API
erp/xlsx.py       dependency-free .xlsx writer/reader, CSV
static/           single-page UI (vanilla JS, light/dark, keyboard and mobile support)
tests/            unittest suite
```

All data is in `data/erp.db`, and backups are in `data/backups/`. To move the system to another computer, copy the folder.

## Known limitations

**Concurrent users**

- This is built for a small team: roughly 1 to 15 simultaneous users on one machine or a LAN.
- SQLite in WAL mode lets many people read at once, but writes are serialized. Each write is a short transaction, so users won't notice the queue at this scale. It is not suitable for hundreds of concurrent writers or for running several server processes.
- Master records (customer, item, etc.) use last-write-wins. Two people editing the same customer at the same moment won't get a merge warning. Documents are protected by their status rules: for example, two people can't both ship the last unit, because the second shipment fails the stock check.
- By default the server listens only on this computer. For LAN use, start it with `--host 0.0.0.0 --allow-host <server-name-or-ip>`.
- The connection is plain HTTP. Passwords and data cross the network unencrypted. For LAN use, put it behind a TLS reverse proxy (Caddy, nginx) or run it over a VPN.
- Restoring a backup replaces the data for everyone, so other users should stop working during a restore.

**Accounting compliance**

- This is an operational ERP with AR and AP subledgers. It is **not** a general ledger.
  - There's no chart of accounts, double-entry journal, trial balance, period close or lock, or financial statements.
  - It supports one currency and one flat sales-tax rate per order. There's no tax engine and no jurisdiction rules.
  - There are no credit memos or returns (RMA). The correction path is void and re-invoice before payment.
  - There's no revenue recognition, 1099 reporting, bank reconciliation or payroll. Employee pay data is stored for reference only.
- Inventory is valued at moving-average cost. Standard cost is used only for variance reporting. FIFO/LIFO, landed cost, and lot or serial traceability aren't implemented.
- Depreciation is straight-line and for management purposes only. It does not produce tax books.
- Amounts are rounded half-up to the cent at each posting and stored as SQLite REAL.
- The audit log is append-only in the application, but anyone with access to the database file could alter it. It isn't tamper-evident.
- For statutory reporting, export invoices, bills, payments and inventory valuation to your accounting system.
- None of this has been reviewed against GAAP, IFRS or SOX.

**Authentication and security**

- Only local accounts are supported:
  - Passwords are hashed with PBKDF2-SHA256 (240k iterations).
  - Sessions are stored on the server, and the session cookie is HttpOnly and SameSite=Strict.
  - Changes require a CSRF token and pass an Origin check.
  - There are 4 roles. Pay rates are restricted by field.
- There's no MFA, SSO/LDAP, or self-service password reset. An admin resets passwords in Users.
- Lockout after failed sign-ins is held in memory, so it resets when the server restarts.
- **The demo passwords are public and must be changed.** The database and its backups (which include password hashes) are not encrypted at rest. Use disk encryption and restrict access to the folder at the operating-system level.

**Other scope limits**

- Planning is reorder-point replenishment that accounts for open production demand. It is not full time-phased MRP or capacity scheduling.
- There's no email sending, EDI, barcode scanning, or quoting module (draft SOs serve as quotes).
- Units of measure are not converted.
- Dates use the server's local time.
