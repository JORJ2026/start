"""Forge ERP test suite (stdlib unittest).  Run:  python3 -m unittest discover -s tests -v"""
import base64
import json
import os
import shutil
import sqlite3
import sys
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
from http.cookiejar import CookieJar

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from erp import backup, db, entities, seed, services as S, xlsx  # noqa: E402
from erp.auth import ensure_admin, hash_password  # noqa: E402
from erp.db import BizError, Forbidden  # noqa: E402

ADMIN = S.Ctx("admin", "admin")
MGR = S.Ctx("mgr", "manager")
CLERK = S.Ctx("clerk", "clerk")
VIEWER = S.Ctx("viewer", "viewer")


class Base(unittest.TestCase):
    """Fresh, small, hand-built dataset per test for exact arithmetic."""

    def setUp(self):
        self.dir = tempfile.mkdtemp()
        self.path = os.path.join(self.dir, "erp.db")
        self.c = db.open_db(self.path)
        c = self.c
        self.main = db.scalar(c, "SELECT id FROM locations WHERE code='MAIN'")
        self.dc = c.execute("INSERT INTO locations(code,name) VALUES('DC','DC')").lastrowid
        self.sup = c.execute("INSERT INTO suppliers(code,name,terms_days) VALUES('S1','Steel Co',30)").lastrowid
        self.cus = c.execute("INSERT INTO customers(code,name,credit_limit,terms_days) VALUES('C1','Cust One',0,30)").lastrowid
        self.raw = c.execute("INSERT INTO items(sku,name,type,uom,std_cost,preferred_supplier_id,reorder_point,reorder_qty)"
                             " VALUES('RAW','Raw bar','raw','ea',10,?,50,100)", (self.sup,)).lastrowid
        self.fg = c.execute("INSERT INTO items(sku,name,type,uom,price) VALUES('FG','Widget','finished','ea',100)").lastrowid
        self.svc = c.execute("INSERT INTO items(sku,name,type,uom,price) VALUES('SVC','Install','service','hr',80)").lastrowid
        self.bom = S.save_bom(c, MGR, {"item_id": self.fg, "labor_cost": 5, "overhead_cost": 1,
                                       "lines": [{"component_id": self.raw, "qty_per": 2, "scrap_pct": 0}]})["id"]

    def tearDown(self):
        self.c.close()
        shutil.rmtree(self.dir, ignore_errors=True)

    # helpers
    def buy(self, qty, cost, receive=True):
        po = S.save_po(self.c, CLERK, {"supplier_id": self.sup, "location_id": self.main,
                                       "lines": [{"item_id": self.raw, "qty": qty, "unit_cost": cost}]})["id"]
        S.approve_po(self.c, CLERK, po)
        if receive:
            line = db.scalar(self.c, "SELECT id FROM po_lines WHERE po_id=?", po)
            S.receive_po(self.c, CLERK, po, [{"po_line_id": line, "qty": qty}])
        return po

    def make(self, qty):
        mo = S.save_mo(self.c, CLERK, {"item_id": self.fg, "qty": qty, "location_id": self.main})["id"]
        S.release_mo(self.c, CLERK, mo)
        S.complete_mo(self.c, CLERK, mo)
        return mo

    def order(self, qty, confirm=True, price=100):
        so = S.save_so(self.c, CLERK, {"customer_id": self.cus, "location_id": self.main, "tax_rate": 0.1,
                                       "lines": [{"item_id": self.fg, "qty": qty, "unit_price": price}]})["id"]
        if confirm:
            S.confirm_so(self.c, CLERK, so)
        return so

    def ship_all(self, so, qty=None):
        line = db.one(self.c, "SELECT * FROM so_lines WHERE so_id=?", so)
        return S.ship_so(self.c, CLERK, so, [{"so_line_id": line["id"], "qty": qty or line["qty"] - line["qty_shipped"]}])

    def onhand(self, item, loc=None):
        return db.scalar(self.c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", item, loc or self.main) or 0

    def assertReconciles(self):
        r = S.reconcile(self.c)
        self.assertTrue(r["ok"], [(x["name"], x["rows"][:3]) for x in r["checks"] if not x["ok"]])


class TestInventoryReconciliation(Base):
    def test_moving_average_cost(self):
        self.buy(100, 10)
        self.buy(100, 14)
        self.assertAlmostEqual(db.scalar(self.c, "SELECT avg_cost FROM items WHERE id=?", self.raw), 12.0)
        self.assertEqual(self.onhand(self.raw), 200)
        self.assertReconciles()

    def test_full_cycle_quantities_and_cost(self):
        self.buy(100, 10)
        self.make(10)                     # consumes 20 RAW at 10, adds labor 5 + overhead 1 per unit
        self.assertEqual(self.onhand(self.raw), 80)
        self.assertEqual(self.onhand(self.fg), 10)
        self.assertAlmostEqual(db.scalar(self.c, "SELECT avg_cost FROM items WHERE id=?", self.fg), 26.0)
        so = self.order(4)
        sh = self.ship_all(so)
        self.assertEqual(self.onhand(self.fg), 6)
        cogs = db.scalar(self.c, "SELECT SUM(qty*unit_cost) FROM shipment_lines WHERE shipment_id=?", sh["id"])
        self.assertAlmostEqual(cogs, 104.0)
        inv = S.invoice_shipment(self.c, CLERK, sh["id"])
        v = db.one(self.c, "SELECT * FROM invoices WHERE id=?", inv["id"])
        self.assertEqual((v["subtotal"], v["tax"], v["total"]), (400.0, 40.0, 440.0))
        S.record_payment(self.c, CLERK, inv["id"], 440)
        self.assertEqual(db.scalar(self.c, "SELECT status FROM sales_orders WHERE id=?", so), "closed")
        self.assertReconciles()

    def test_reconcile_detects_and_rebuild_repairs_tampering(self):
        self.buy(100, 10)
        self.c.execute("UPDATE stock SET qty=qty+7 WHERE item_id=?", (self.raw,))   # simulate corruption
        r = S.reconcile(self.c)
        failing = {x["name"] for x in r["checks"] if not x["ok"]}
        self.assertIn("Stock balance vs ledger", failing)
        with self.assertRaises(Forbidden):
            S.rebuild_stock(self.c, MGR)
        S.rebuild_stock(self.c, ADMIN)
        self.assertEqual(self.onhand(self.raw), 100)
        self.assertReconciles()

    def test_reconcile_detects_document_mismatch(self):
        po = self.buy(100, 10)
        self.c.execute("UPDATE po_lines SET qty_received=90 WHERE po_id=?", (po,))
        failing = {x["name"] for x in S.reconcile(self.c)["checks"] if not x["ok"]}
        self.assertIn("PO received qty vs receipts", failing)

    def test_cycle_count_and_transfer(self):
        self.buy(100, 10)
        r = S.adjust_stock(self.c, MGR, self.raw, self.main, counted=97, reason="count")
        self.assertEqual(r["delta"], -3)
        S.transfer_stock(self.c, CLERK, self.raw, self.main, self.dc, 40)
        self.assertEqual((self.onhand(self.raw), self.onhand(self.raw, self.dc)), (57, 40))
        self.assertAlmostEqual(db.scalar(self.c, "SELECT avg_cost FROM items WHERE id=?", self.raw), 10.0)
        with self.assertRaises(BizError):
            S.adjust_stock(self.c, MGR, self.raw, self.main, qty=-1, reason="")   # reason required
        with self.assertRaises(Forbidden):
            S.adjust_stock(self.c, CLERK, self.raw, self.main, qty=-1, reason="x")
        self.assertReconciles()

    def test_negative_stock_rule(self):
        self.buy(10, 10)
        with self.assertRaises(BizError):
            S.transfer_stock(self.c, CLERK, self.raw, self.main, self.dc, 11)
        self.c.execute("UPDATE settings SET value='1' WHERE key='allow_negative_stock'")
        S.transfer_stock(self.c, CLERK, self.raw, self.main, self.dc, 11)
        self.assertEqual(self.onhand(self.raw), -1)
        self.assertReconciles()

    def test_full_seed_reconciles(self):
        c = db.open_db(os.path.join(self.dir, "seed.db"))
        seed.seed(c, days=120)
        r = S.reconcile(c)
        self.assertTrue(r["ok"], [(x["name"], x["rows"][:3]) for x in r["checks"] if not x["ok"]])
        for t in ("receipts", "bills", "supplier_payments", "shipments", "invoices", "payments", "production_orders"):
            self.assertGreater(db.scalar(c, f"SELECT COUNT(*) FROM {t}"), 0, t)
        c.close()


class TestTransactionDependencies(Base):
    def test_cannot_ship_unconfirmed_or_over_ship(self):
        self.buy(100, 10)
        self.make(5)
        so = self.order(3, confirm=False)
        with self.assertRaisesRegex(BizError, "only confirmed"):
            self.ship_all(so)
        S.confirm_so(self.c, CLERK, so)
        with self.assertRaisesRegex(BizError, "exceeds the remaining"):
            self.ship_all(so, 4)
        self.ship_all(so, 2)
        self.assertEqual(db.scalar(self.c, "SELECT status FROM sales_orders WHERE id=?", so), "partial")

    def test_shipment_blocked_by_stock_is_atomic(self):
        self.buy(100, 10)
        self.make(2)
        so = S.save_so(self.c, CLERK, {"customer_id": self.cus, "location_id": self.main, "lines": [
            {"item_id": self.fg, "qty": 2, "unit_price": 100}, {"item_id": self.raw, "qty": 500, "unit_price": 1}]})["id"]
        S.confirm_so(self.c, CLERK, so)
        lines = db.all_(self.c, "SELECT id, qty FROM so_lines WHERE so_id=? ORDER BY id", so)
        before = (db.scalar(self.c, "SELECT COUNT(*) FROM inventory_txns"), db.scalar(self.c, "SELECT COUNT(*) FROM shipments"),
                  db.scalar(self.c, "SELECT next_val FROM sequences WHERE name='shipments'"))
        with self.assertRaisesRegex(BizError, "Insufficient stock"):
            S.ship_so(self.c, CLERK, so, [{"so_line_id": l["id"], "qty": l["qty"]} for l in lines])
        after = (db.scalar(self.c, "SELECT COUNT(*) FROM inventory_txns"), db.scalar(self.c, "SELECT COUNT(*) FROM shipments"),
                 db.scalar(self.c, "SELECT next_val FROM sequences WHERE name='shipments'"))
        self.assertEqual(before, after)                 # nothing partially written, number not consumed
        self.assertEqual(self.onhand(self.fg), 2)
        self.assertReconciles()

    def test_invoice_payment_and_void_rules(self):
        self.buy(100, 10)
        self.make(5)
        sh = self.ship_all(self.order(2))
        inv = S.invoice_shipment(self.c, CLERK, sh["id"])
        with self.assertRaisesRegex(BizError, "already invoiced"):
            S.invoice_shipment(self.c, CLERK, sh["id"])
        with self.assertRaisesRegex(BizError, "exceeds the open balance"):
            S.record_payment(self.c, CLERK, inv["id"], 10000)
        S.record_payment(self.c, CLERK, inv["id"], 50)
        self.assertEqual(db.scalar(self.c, "SELECT status FROM invoices WHERE id=?", inv["id"]), "partial")
        with self.assertRaisesRegex(BizError, "has payments"):
            S.void_invoice(self.c, MGR, inv["id"])
        # void + re-invoice path on a fresh shipment
        sh2 = self.ship_all(self.order(1))
        inv2 = S.invoice_shipment(self.c, CLERK, sh2["id"])
        with self.assertRaises(Forbidden):
            S.void_invoice(self.c, CLERK, inv2["id"])
        S.void_invoice(self.c, MGR, inv2["id"])
        S.invoice_shipment(self.c, CLERK, sh2["id"])
        self.assertReconciles()

    def test_purchase_rules_three_way_match(self):
        po = self.buy(100, 10, receive=False)
        with self.assertRaisesRegex(BizError, "Nothing to bill"):
            S.create_bill(self.c, CLERK, po)
        line = db.scalar(self.c, "SELECT id FROM po_lines WHERE po_id=?", po)
        with self.assertRaisesRegex(BizError, "exceed ordered"):
            S.receive_po(self.c, CLERK, po, [{"po_line_id": line, "qty": 106}])    # tolerance 5%
        S.receive_po(self.c, CLERK, po, [{"po_line_id": line, "qty": 60}])
        b = S.create_bill(self.c, CLERK, po, "X1")
        self.assertEqual(db.scalar(self.c, "SELECT total FROM bills WHERE id=?", b["id"]), 600.0)
        with self.assertRaisesRegex(BizError, "has receipts"):
            S.cancel_po(self.c, MGR, po)
        S.pay_bill(self.c, CLERK, b["id"], 600)
        S.close_po(self.c, MGR, po)
        self.assertEqual(db.scalar(self.c, "SELECT status FROM purchase_orders WHERE id=?", po), "closed")
        self.assertReconciles()

    def test_po_approval_limit(self):
        po = S.save_po(self.c, CLERK, {"supplier_id": self.sup, "lines": [{"item_id": self.raw, "qty": 1000, "unit_cost": 10}]})["id"]
        with self.assertRaisesRegex(Forbidden, "approval limit"):
            S.approve_po(self.c, CLERK, po)
        S.approve_po(self.c, MGR, po)

    def test_credit_limit_and_override(self):
        self.c.execute("UPDATE customers SET credit_limit=500 WHERE id=?", (self.cus,))
        so = self.order(10, confirm=False)                    # 1,100 incl tax
        with self.assertRaisesRegex(BizError, "Credit limit exceeded"):
            S.confirm_so(self.c, CLERK, so)
        with self.assertRaisesRegex(BizError, "Credit limit exceeded"):
            S.confirm_so(self.c, CLERK, so, override_credit=True)  # clerks cannot override
        S.confirm_so(self.c, MGR, so, override_credit=True)
        self.assertTrue(db.scalar(self.c, "SELECT COUNT(*) FROM audit_log WHERE action='credit_override'"))

    def test_referential_integrity(self):
        self.order(1, confirm=False)
        with self.assertRaisesRegex(BizError, "referenced by other records"):
            entities.delete_record(self.c, MGR, "customers", self.cus)
        self.buy(5, 1)
        with self.assertRaisesRegex(BizError, "inventory history"):
            entities.delete_record(self.c, MGR, "items", self.raw)
        with self.assertRaises(sqlite3.IntegrityError):
            self.c.execute("INSERT INTO so_lines(so_id,item_id,qty,unit_price) VALUES(99999,1,1,1)")
        with self.assertRaises(sqlite3.IntegrityError):
            self.c.execute("INSERT INTO po_lines(po_id,item_id,qty,unit_cost) VALUES(1,?,-5,1)", (self.raw,))

    def test_bom_cycle_and_production_shortage(self):
        sub = self.c.execute("INSERT INTO items(sku,name,type) VALUES('SUB','Sub','component')").lastrowid
        S.save_bom(self.c, MGR, {"item_id": sub, "lines": [{"component_id": self.fg, "qty_per": 1}]})
        with self.assertRaisesRegex(BizError, "circular"):
            S.save_bom(self.c, MGR, {"id": self.bom, "item_id": self.fg, "lines": [{"component_id": sub, "qty_per": 1}]})
        mo = S.save_mo(self.c, CLERK, {"item_id": self.fg, "qty": 5})["id"]
        with self.assertRaisesRegex(BizError, "release it"):
            S.complete_mo(self.c, CLERK, mo)
        S.release_mo(self.c, CLERK, mo)
        with self.assertRaisesRegex(BizError, "Insufficient components"):
            S.complete_mo(self.c, CLERK, mo)
        self.buy(4, 10)
        S.complete_mo(self.c, CLERK, mo, 2)
        self.assertEqual(db.scalar(self.c, "SELECT status FROM production_orders WHERE id=?", mo), "released")
        S.cancel_mo(self.c, MGR, mo)        # partial output -> closed short
        self.assertEqual(db.scalar(self.c, "SELECT status FROM production_orders WHERE id=?", mo), "completed")
        self.assertReconciles()

    def test_draft_only_edits_and_viewer_blocked(self):
        so = self.order(1)
        with self.assertRaisesRegex(BizError, "only draft"):
            S.save_so(self.c, CLERK, {"id": so, "customer_id": self.cus, "lines": [{"item_id": self.fg, "qty": 2}]})
        with self.assertRaises(Forbidden):
            S.save_so(self.c, VIEWER, {"customer_id": self.cus, "lines": [{"item_id": self.fg, "qty": 1}]})

    def test_audit_trail(self):
        entities.save_record(self.c, CLERK, "customers", {"id": self.cus, "name": "Renamed", "code": "C1"})
        a = db.one(self.c, "SELECT * FROM audit_log WHERE entity='customers' AND entity_id=? ORDER BY id DESC", self.cus)
        self.assertEqual(json.loads(a["before_json"])["name"], "Cust One")
        self.assertEqual(json.loads(a["after_json"])["name"], "Renamed")


class TestImportExport(Base):
    def test_xlsx_roundtrip_and_import(self):
        hdr, rows = entities.export_for_import(self.c, ADMIN, "items")
        data = xlsx.write_xlsx(hdr, rows)
        h2, r2 = xlsx.read_xlsx(data)
        self.assertEqual(h2, hdr)
        self.assertEqual(len(r2), 3)
        r2 = [list(r) for r in r2]
        r2[0][h2.index("price")] = 12.5
        r2.append(["NEW1", "New item", None, "Hardware", "raw", "ea", 3, 1, 5, 10, "S1", 1])
        res = entities.import_rows(self.c, MGR, "items", h2, r2, dry_run=True)
        self.assertEqual((res["created"], res["updated"], res["committed"]), (1, 1, False))
        self.assertIsNone(db.scalar(self.c, "SELECT id FROM items WHERE sku='NEW1'"))
        res = entities.import_rows(self.c, MGR, "items", h2, r2, dry_run=False)
        self.assertTrue(res["committed"])
        self.assertEqual(db.scalar(self.c, "SELECT preferred_supplier_id FROM items WHERE sku='NEW1'"), self.sup)

    def test_import_is_all_or_nothing(self):
        hdr = ["code", "name", "credit_limit", "email"]
        rows = [["C9", "Good", "100", "a@b.co"], ["C10", "Bad", "-5", "x"], ["", "No key", "", ""]]
        res = entities.import_rows(self.c, MGR, "customers", hdr, rows, dry_run=False)
        self.assertFalse(res["committed"])
        self.assertEqual(len(res["errors"]), 2)
        self.assertIsNone(db.scalar(self.c, "SELECT id FROM customers WHERE code='C9'"))

    def test_csv_import_and_formula_neutralised(self):
        h, rows = xlsx.read_csv(b"code,name\nC20,=HYPERLINK(\"x\")\n")
        entities.import_rows(self.c, MGR, "customers", h, rows, dry_run=False)
        out = xlsx.write_csv(["name"], [[db.scalar(self.c, "SELECT name FROM customers WHERE code='C20'")]]).decode("utf-8-sig")
        self.assertIn("'=HYPERLINK", out)

    def test_xlsx_opens_in_openpyxl(self):
        try:
            import openpyxl
        except ImportError:
            self.skipTest("openpyxl not installed")
        import io
        wb = openpyxl.load_workbook(io.BytesIO(xlsx.write_xlsx(["a", "b"], [[1, "x & <y>"], [2.5, None]])))
        ws = wb.active
        self.assertEqual([c.value for c in ws[2]], [1, "x & <y>"])

    def test_bulk_update(self):
        r = entities.bulk_update(self.c, MGR, "items", [self.fg, self.svc], "price", "pct", 10)
        self.assertEqual(r["updated"], 2)
        self.assertAlmostEqual(db.scalar(self.c, "SELECT price FROM items WHERE id=?", self.fg), 110.0)
        with self.assertRaises(BizError):
            entities.bulk_update(self.c, MGR, "items", [self.fg], "sku", "set", "X")    # not bulk-editable
        with self.assertRaises(Forbidden):
            entities.bulk_update(self.c, CLERK, "items", [self.fg], "price", "set", 1)


class TestRecovery(Base):
    def test_backup_restore_roundtrip(self):
        self.buy(100, 10)
        b = backup.create_backup(self.c, self.path, "t")
        self.make(10)
        self.c.execute("DELETE FROM audit_log")
        self.assertEqual(self.onhand(self.raw), 80)
        r = backup.restore_from_file(self.c, self.path, backup.backup_path(self.path, b["name"]))
        self.assertEqual(self.onhand(self.raw), 100)
        self.assertEqual(self.onhand(self.fg), 0)
        self.assertTrue(os.path.exists(backup.backup_path(self.path, r["safety_backup"])))
        self.assertReconciles()
        # the safety copy holds the pre-restore state and can itself be restored
        backup.restore_from_file(self.c, self.path, backup.backup_path(self.path, r["safety_backup"]))
        self.assertEqual(self.onhand(self.fg), 10)

    def test_rejects_corrupt_and_foreign_files(self):
        bad = os.path.join(backup.backup_dir(self.path), "erp-bad.db")
        with open(bad, "wb") as f:
            f.write(b"SQLite format 3\x00" + os.urandom(4096))
        with self.assertRaises(BizError):
            backup.verify_backup(bad)
        other = os.path.join(self.dir, "other.db")
        o = sqlite3.connect(other)
        o.execute("CREATE TABLE x(a)")
        o.commit()
        o.close()
        with self.assertRaisesRegex(BizError, "not a Forge ERP"):
            backup.verify_backup(other)
        with self.assertRaises(BizError):
            backup.save_upload(self.path, b"not a database")
        with self.assertRaises(BizError):
            backup.backup_path(self.path, "../erp.db")
        before = self.onhand(self.raw)
        with self.assertRaises(BizError):
            backup.restore_from_file(self.c, self.path, bad)
        self.assertEqual(self.onhand(self.raw), before)       # live data untouched

    def test_crash_mid_transaction_rolls_back(self):
        """A failure inside a write transaction leaves no partial data (simulated crash)."""
        self.buy(100, 10)
        n = db.scalar(self.c, "SELECT COUNT(*) FROM inventory_txns")
        try:
            with db.tx(self.c):
                S.post_inventory(self.c, ADMIN, self.raw, self.main, -10, "adjustment")
                raise RuntimeError("power loss")
        except RuntimeError:
            pass
        self.assertEqual(db.scalar(self.c, "SELECT COUNT(*) FROM inventory_txns"), n)
        self.assertEqual(self.onhand(self.raw), 100)
        # a second connection (new process after crash) sees committed state only
        c2 = db.connect(self.path)
        self.assertEqual(db.scalar(c2, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", self.raw, self.main), 100)
        c2.close()


class TestHTTP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        from erp.server import serve
        cls.dir = tempfile.mkdtemp()
        cls.path = os.path.join(cls.dir, "erp.db")
        c = db.open_db(cls.path)
        ensure_admin(c)
        h, s = hash_password("viewerpass")
        c.execute("INSERT INTO users(username,full_name,role,pw_hash,salt) VALUES('v','Viewer','viewer',?,?)", (h, s))
        c.close()
        cls.httpd = serve(cls.path, "127.0.0.1", 0)
        cls.base = f"http://127.0.0.1:{cls.httpd.server_address[1]}"
        threading.Thread(target=cls.httpd.serve_forever, daemon=True).start()

    @classmethod
    def tearDownClass(cls):
        cls.httpd.shutdown()
        cls.httpd.server_close()
        shutil.rmtree(cls.dir, ignore_errors=True)

    def client(self):
        op = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(CookieJar()))

        def call(path, body=None, csrf=None, headers=None):
            hd = {"Content-Type": "application/json", **(headers or {})}
            if csrf:
                hd["X-CSRF"] = csrf
            req = urllib.request.Request(self.base + path, data=None if body is None else json.dumps(body).encode(), headers=hd)
            try:
                r = op.open(req)
                return r.status, json.loads(r.read() or b"{}")
            except urllib.error.HTTPError as e:
                return e.code, json.loads(e.read() or b"{}")
        return call

    def login(self, u, p):
        call = self.client()
        self.assertEqual(call("/api/login", {"username": u, "password": p})[0], 200)
        return call, call("/api/me")[1]["csrf"]

    def test_requires_auth(self):
        call = self.client()
        self.assertEqual(call("/api/dashboard")[0], 401)
        self.assertEqual(call("/api/login", {"username": "admin", "password": "nope"})[0], 400)

    def test_csrf_and_roles(self):
        call, csrf = self.login("admin", "admin")
        self.assertEqual(call("/api/save/locations", {"code": "X1", "name": "X"})[0], 403)                 # no CSRF
        self.assertEqual(call("/api/save/locations", {"code": "X1", "name": "X"}, csrf)[0], 200)
        self.assertEqual(call("/api/save/locations", {"code": "X2", "name": "X"}, csrf,
                              {"Origin": "http://evil.example"})[0], 403)
        vcall, vcsrf = self.login("v", "viewerpass")
        self.assertEqual(vcall("/api/save/customers", {"code": "Q", "name": "Q"}, vcsrf)[0], 403)
        self.assertEqual(vcall("/api/backups")[0], 403)
        self.assertEqual(vcall("/api/list/customers")[0], 200)

    def test_lockout(self):
        call = self.client()
        for _ in range(5):
            call("/api/login", {"username": "lockme", "password": "x"})
        s, d = call("/api/login", {"username": "lockme", "password": "x"})
        self.assertIn("Too many", d["error"])

    def test_host_header_rejected(self):
        call = self.client()
        self.assertEqual(call("/api/me", headers={"Host": "attacker.example"})[0], 421)

    def test_keepalive_after_post_without_body_use(self):
        """Regression: unread POST bodies must not corrupt the next request on a keep-alive socket."""
        import http.client
        port = self.httpd.server_address[1]
        hc = http.client.HTTPConnection("127.0.0.1", port)
        hc.request("POST", "/api/login", body=json.dumps({"username": "admin", "password": "admin"}),
                   headers={"Content-Type": "application/json"})
        r = hc.getresponse()
        cookie = r.getheader("Set-Cookie").split(";")[0]
        r.read()
        hc.request("GET", "/api/me", headers={"Cookie": cookie})
        r = hc.getresponse()
        csrf = json.loads(r.read())["csrf"]
        hc.request("POST", "/api/logout", body="{}", headers={"Cookie": cookie, "X-CSRF": csrf,
                                                              "Content-Type": "application/json"})
        r = hc.getresponse()
        r.read()
        hc.request("GET", "/api/me", headers={"Cookie": cookie})
        self.assertEqual(hc.getresponse().status, 401)   # signed out, and the request parsed cleanly
        hc.close()

    def test_import_endpoint(self):
        call, csrf = self.login("admin", "admin")
        data = base64.b64encode(xlsx.write_csv(["code", "name"], [["S77", "Sup 77"]])).decode()
        s, r = call("/api/import/suppliers", {"filename": "s.csv", "data": data, "dry_run": False}, csrf)
        self.assertEqual((s, r["created"], r["committed"]), (200, 1, True))


if __name__ == "__main__":
    unittest.main(verbosity=2)
