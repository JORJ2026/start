"""Dashboard metrics and operational reports."""
from datetime import date, timedelta

from .db import BizError, all_, money, scalar, today
from .services import reorder_suggestions, require


def _month_starts(n=12):
    d = date.today().replace(day=1)
    out = []
    for _ in range(n):
        out.append(d)
        d = (d - timedelta(days=1)).replace(day=1)
    return list(reversed(out))


def dashboard(c, ctx):
    t = today()
    m0 = date.today().replace(day=1).isoformat()
    lm = (date.today().replace(day=1) - timedelta(days=1)).replace(day=1).isoformat()
    y0 = date.today().replace(month=1, day=1).isoformat()
    rev = lambda a, b: money(scalar(c, "SELECT COALESCE(SUM(subtotal),0) FROM invoices WHERE status<>'void' "
                                       "AND date>=? AND date<?", a, b))
    tomorrow = (date.today() + timedelta(days=1)).isoformat()
    k = {
        "revenue_mtd": rev(m0, tomorrow),
        "revenue_last_month": rev(lm, m0),
        "revenue_ytd": rev(y0, tomorrow),
        "cogs_mtd": money(scalar(c, "SELECT COALESCE(SUM(sl.qty*sl.unit_cost),0) FROM shipment_lines sl "
                                    "JOIN shipments s ON s.id=sl.shipment_id WHERE s.date>=?", m0)),
        "ar_open": money(scalar(c, "SELECT COALESCE(SUM(total-amount_paid),0) FROM invoices WHERE status IN ('open','partial')")),
        "ar_overdue": money(scalar(c, "SELECT COALESCE(SUM(total-amount_paid),0) FROM invoices "
                                      "WHERE status IN ('open','partial') AND due_date<?", t)),
        "ap_open": money(scalar(c, "SELECT COALESCE(SUM(total-amount_paid),0) FROM bills WHERE status IN ('open','partial')")),
        "ap_due_7": money(scalar(c, "SELECT COALESCE(SUM(total-amount_paid),0) FROM bills WHERE status IN ('open','partial') "
                                    "AND due_date<=?", (date.today() + timedelta(days=7)).isoformat())),
        "inventory_value": money(scalar(c, "SELECT COALESCE(SUM(s.qty*i.avg_cost),0) FROM stock s JOIN items i ON i.id=s.item_id")),
        "so_backlog": money(scalar(c, "SELECT COALESCE(SUM((l.qty-l.qty_shipped)*l.unit_price*(1-l.discount_pct/100.0)),0) "
                                      "FROM so_lines l JOIN sales_orders o ON o.id=l.so_id WHERE o.status IN ('confirmed','partial')")),
        "so_late": scalar(c, "SELECT COUNT(*) FROM sales_orders WHERE status IN ('confirmed','partial') AND ship_by<?", t),
        "so_open": scalar(c, "SELECT COUNT(*) FROM sales_orders WHERE status IN ('draft','confirmed','partial')"),
        "po_open_value": money(scalar(c, "SELECT COALESCE(SUM((l.qty-l.qty_received)*l.unit_cost),0) FROM po_lines l "
                                         "JOIN purchase_orders p ON p.id=l.po_id WHERE p.status IN ('approved','partial') "
                                         "AND l.qty>l.qty_received")),
        "po_late": scalar(c, "SELECT COUNT(*) FROM purchase_orders WHERE status IN ('approved','partial') AND expected_date<?", t),
        "po_draft": scalar(c, "SELECT COUNT(*) FROM purchase_orders WHERE status='draft'"),
        "mo_active": scalar(c, "SELECT COUNT(*) FROM production_orders WHERE status IN ('planned','released')"),
        "mo_late": scalar(c, "SELECT COUNT(*) FROM production_orders WHERE status IN ('planned','released') AND due_date<?", t),
        "low_stock": len(reorder_suggestions(c)),
        "assets_service_due": scalar(c, "SELECT COUNT(*) FROM assets WHERE status IN ('in_service','maintenance') "
                                        "AND next_service_date IS NOT NULL AND next_service_date<=?",
                                     (date.today() + timedelta(days=14)).isoformat()),
        "headcount": scalar(c, "SELECT COUNT(*) FROM employees WHERE status<>'terminated'"),
    }
    months = _month_starts(12)
    series = []
    for i, m in enumerate(months):
        nxt = months[i + 1].isoformat() if i + 1 < len(months) else tomorrow
        series.append({
            "month": m.strftime("%b %y"),
            "revenue": rev(m.isoformat(), nxt),
            "cogs": money(scalar(c, "SELECT COALESCE(SUM(sl.qty*sl.unit_cost),0) FROM shipment_lines sl JOIN shipments s "
                                    "ON s.id=sl.shipment_id WHERE s.date>=? AND s.date<?", m.isoformat(), nxt)),
            "purchases": money(scalar(c, "SELECT COALESCE(SUM(rl.qty*rl.unit_cost),0) FROM receipt_lines rl JOIN receipts r "
                                         "ON r.id=rl.receipt_id WHERE r.date>=? AND r.date<?", m.isoformat(), nxt)),
        })
    yr = (date.today() - timedelta(days=365)).isoformat()
    return {
        "kpi": k, "monthly": series,
        "ar_aging": _aging(c, "invoices")["buckets"],
        "top_customers": all_(c, "SELECT c.id, c.name, ROUND(SUM(v.subtotal),2) AS revenue FROM invoices v JOIN customers c "
                                 "ON c.id=v.customer_id WHERE v.status<>'void' AND v.date>=? GROUP BY c.id "
                                 "ORDER BY revenue DESC LIMIT 6", yr),
        "top_items": all_(c, "SELECT i.id, i.sku, i.name, ROUND(SUM(l.amount),2) AS revenue, ROUND(SUM(l.qty),2) AS qty "
                             "FROM invoice_lines l JOIN invoices v ON v.id=l.invoice_id JOIN items i ON i.id=l.item_id "
                             "WHERE v.status<>'void' AND v.date>=? GROUP BY i.id ORDER BY revenue DESC LIMIT 6", yr),
        "inventory_by_type": all_(c, "SELECT i.type, ROUND(SUM(s.qty*i.avg_cost),2) AS value FROM stock s JOIN items i "
                                     "ON i.id=s.item_id GROUP BY i.type ORDER BY value DESC"),
        "late_orders": all_(c, "SELECT id, number, customer_name, ship_by, subtotal-shipped_value AS open_value "
                               "FROM v_sales_orders WHERE status IN ('confirmed','partial') AND ship_by<? "
                               "ORDER BY ship_by LIMIT 8", t),
        "recent": all_(c, "SELECT ts, username, action, entity, entity_id, summary FROM audit_log "
                          "WHERE action NOT IN ('login','login_failed') ORDER BY id DESC LIMIT 10"),
    }


def _aging(c, table):
    t = date.today()
    view = "v_invoices" if table == "invoices" else "v_bills"
    party = "customer" if table == "invoices" else "supplier"
    rows = all_(c, f"SELECT {party}_id AS pid, {party}_name AS name, due_date, balance FROM {view} "
                   "WHERE status IN ('open','partial') AND balance > 0.004")
    keys = ["current", "d1_30", "d31_60", "d61_90", "d90p"]
    agg, buckets = {}, dict.fromkeys(keys, 0.0)
    for r in rows:
        days = (t - date.fromisoformat(r["due_date"])).days
        k = keys[0] if days <= 0 else keys[1] if days <= 30 else keys[2] if days <= 60 else keys[3] if days <= 90 else keys[4]
        a = agg.setdefault(r["pid"], {"id": r["pid"], "name": r["name"], **dict.fromkeys(keys, 0.0), "total": 0.0})
        a[k] += r["balance"]
        a["total"] += r["balance"]
        buckets[k] += r["balance"]
    out = sorted(agg.values(), key=lambda x: -x["total"])
    for a in out:
        for k in keys + ["total"]:
            a[k] = money(a[k])
    labels = {"current": "Current", "d1_30": "1-30", "d31_60": "31-60", "d61_90": "61-90", "d90p": "90+"}
    return {"rows": out, "buckets": [{"bucket": labels[k], "amount": money(buckets[k])} for k in keys]}


M, Q, I, T, D, P = "money", "qty", "int", "text", "date", "pct"


def _cols(*spec):
    return [{"key": k, "label": l, "type": t} for k, l, t in spec]


def _range(p, default_days=90):
    to = p.get("to") or today()
    fr = p.get("from") or (date.fromisoformat(to) - timedelta(days=default_days)).isoformat()
    return fr, to


def r_inventory_valuation(c, p):
    rows = all_(c, "SELECT sku, name, type, category, uom, on_hand, avg_cost, stock_value, reorder_point, on_order, committed "
                   "FROM v_items WHERE type<>'service' AND (on_hand<>0 OR active=1) ORDER BY type, sku")
    return dict(title="Inventory valuation (moving average cost)", rows=rows,
                columns=_cols(("sku", "SKU", T), ("name", "Item", T), ("type", "Type", T), ("category", "Category", T),
                              ("uom", "UoM", T), ("on_hand", "On hand", Q), ("avg_cost", "Avg cost", "cost"),
                              ("stock_value", "Value", M), ("committed", "Committed", Q), ("on_order", "On order", Q)),
                totals={"stock_value": money(sum(r["stock_value"] for r in rows))})


def r_ar_aging(c, p):
    a = _aging(c, "invoices")
    return dict(title="Accounts receivable aging (by due date)", rows=a["rows"], link="customers",
                columns=_cols(("name", "Customer", T), ("current", "Current", M), ("d1_30", "1-30", M),
                              ("d31_60", "31-60", M), ("d61_90", "61-90", M), ("d90p", "90+", M), ("total", "Total", M)),
                totals={k: money(sum(r[k] for r in a["rows"])) for k in ("current", "d1_30", "d31_60", "d61_90", "d90p", "total")})


def r_ap_aging(c, p):
    a = _aging(c, "bills")
    return dict(title="Accounts payable aging (by due date)", rows=a["rows"], link="suppliers",
                columns=_cols(("name", "Supplier", T), ("current", "Current", M), ("d1_30", "1-30", M),
                              ("d31_60", "31-60", M), ("d61_90", "61-90", M), ("d90p", "90+", M), ("total", "Total", M)),
                totals={k: money(sum(r[k] for r in a["rows"])) for k in ("current", "d1_30", "d31_60", "d61_90", "d90p", "total")})


def r_sales_by_customer(c, p):
    fr, to = _range(p)
    rows = all_(c, """
      SELECT cu.id, cu.code, cu.name, COUNT(DISTINCT v.id) AS invoices, ROUND(SUM(il.amount),2) AS revenue,
        ROUND(SUM(il.qty*COALESCE(sl.unit_cost,0)),2) AS cogs
      FROM invoices v JOIN customers cu ON cu.id=v.customer_id JOIN invoice_lines il ON il.invoice_id=v.id
      LEFT JOIN shipment_lines sl ON sl.shipment_id=v.shipment_id AND sl.so_line_id=il.so_line_id
      WHERE v.status<>'void' AND v.date BETWEEN ? AND ? GROUP BY cu.id ORDER BY revenue DESC""", fr, to)
    for r in rows:
        r["margin"] = money(r["revenue"] - r["cogs"])
        r["margin_pct"] = round(100 * r["margin"] / r["revenue"], 1) if r["revenue"] else 0
    return dict(title=f"Sales by customer, {fr} to {to}", rows=rows, link="customers", params=["from", "to"],
                columns=_cols(("code", "Code", T), ("name", "Customer", T), ("invoices", "Invoices", I),
                              ("revenue", "Revenue", M), ("cogs", "COGS", M), ("margin", "Gross margin", M),
                              ("margin_pct", "Margin %", P)),
                totals={k: money(sum(r[k] for r in rows)) for k in ("revenue", "cogs", "margin")})


def r_sales_by_item(c, p):
    fr, to = _range(p)
    rows = all_(c, """
      SELECT i.id, i.sku, i.name, ROUND(SUM(il.qty),2) AS qty, ROUND(SUM(il.amount),2) AS revenue,
        ROUND(SUM(il.qty*COALESCE(sl.unit_cost,0)),2) AS cogs
      FROM invoice_lines il JOIN invoices v ON v.id=il.invoice_id JOIN items i ON i.id=il.item_id
      LEFT JOIN shipment_lines sl ON sl.shipment_id=v.shipment_id AND sl.so_line_id=il.so_line_id
      WHERE v.status<>'void' AND v.date BETWEEN ? AND ? GROUP BY i.id ORDER BY revenue DESC""", fr, to)
    for r in rows:
        r["margin"] = money(r["revenue"] - r["cogs"])
        r["margin_pct"] = round(100 * r["margin"] / r["revenue"], 1) if r["revenue"] else 0
    return dict(title=f"Sales by item, {fr} to {to}", rows=rows, link="items", params=["from", "to"],
                columns=_cols(("sku", "SKU", T), ("name", "Item", T), ("qty", "Qty", Q), ("revenue", "Revenue", M),
                              ("cogs", "COGS", M), ("margin", "Gross margin", M), ("margin_pct", "Margin %", P)),
                totals={k: money(sum(r[k] for r in rows)) for k in ("revenue", "cogs", "margin")})


def r_purchases_by_supplier(c, p):
    fr, to = _range(p)
    rows = all_(c, """
      SELECT s.id, s.code, s.name, COUNT(DISTINCT r.id) AS receipts, ROUND(SUM(rl.qty*rl.unit_cost),2) AS received,
        ROUND(COALESCE((SELECT SUM(total) FROM bills b WHERE b.supplier_id=s.id AND b.status<>'void'
                        AND b.date BETWEEN ? AND ?),0),2) AS billed,
        ROUND(AVG(julianday(r.date)-julianday(po.order_date)),1) AS avg_lead_days,
        ROUND(100.0*SUM(CASE WHEN r.date<=po.expected_date THEN 1 ELSE 0 END)/COUNT(*),1) AS on_time_pct
      FROM receipts r JOIN receipt_lines rl ON rl.receipt_id=r.id JOIN purchase_orders po ON po.id=r.po_id
      JOIN suppliers s ON s.id=po.supplier_id WHERE r.date BETWEEN ? AND ? GROUP BY s.id ORDER BY received DESC""",
                fr, to, fr, to)
    return dict(title=f"Purchases by supplier, {fr} to {to}", rows=rows, link="suppliers", params=["from", "to"],
                columns=_cols(("code", "Code", T), ("name", "Supplier", T), ("receipts", "Receipts", I),
                              ("received", "Received value", M), ("billed", "Billed", M),
                              ("avg_lead_days", "Avg lead (days)", Q), ("on_time_pct", "On-time lines %", P)),
                totals={k: money(sum(r[k] or 0 for r in rows)) for k in ("received", "billed")})


def r_reorder(c, p):
    rows = reorder_suggestions(c)
    for r in rows:
        r["id"] = r["item_id"]
        r["est_cost"] = money(r["suggested_qty"] * (r["unit_cost"] or 0))
    return dict(title="Reorder and replenishment suggestions", rows=rows, link="items",
                columns=_cols(("sku", "SKU", T), ("name", "Item", T), ("action", "Action", T), ("on_hand", "On hand", Q),
                              ("on_order", "On order", Q), ("committed", "Committed", Q), ("mfg_demand", "Mfg demand", Q),
                              ("available", "Projected", Q), ("reorder_point", "Reorder pt", Q),
                              ("suggested_qty", "Suggested", Q), ("supplier_code", "Supplier", T), ("est_cost", "Est. cost", M)),
                totals={"est_cost": money(sum(r["est_cost"] for r in rows))})


def r_stock_movement(c, p):
    fr, to = _range(p, 30)
    rows = all_(c, """
      SELECT i.id, i.sku, i.name,
        ROUND(COALESCE((SELECT SUM(qty) FROM inventory_txns WHERE item_id=i.id AND substr(ts,1,10)<?),0),4) AS opening,
        ROUND(SUM(CASE WHEN t.type='receipt' THEN t.qty ELSE 0 END),4) AS received,
        ROUND(SUM(CASE WHEN t.type='output' THEN t.qty ELSE 0 END),4) AS produced,
        ROUND(-SUM(CASE WHEN t.type='issue' THEN t.qty ELSE 0 END),4) AS consumed,
        ROUND(-SUM(CASE WHEN t.type='shipment' THEN t.qty ELSE 0 END),4) AS shipped,
        ROUND(SUM(CASE WHEN t.type IN ('adjustment','opening') THEN t.qty ELSE 0 END),4) AS adjusted
      FROM items i LEFT JOIN inventory_txns t ON t.item_id=i.id AND substr(t.ts,1,10) BETWEEN ? AND ?
      WHERE i.type<>'service' GROUP BY i.id ORDER BY i.sku""", fr, fr, to)
    for r in rows:
        r["closing"] = round(r["opening"] + r["received"] + r["produced"] - r["consumed"] - r["shipped"] + r["adjusted"], 4)
    return dict(title=f"Stock movement, {fr} to {to}", rows=rows, link="items", params=["from", "to"],
                columns=_cols(("sku", "SKU", T), ("name", "Item", T), ("opening", "Opening", Q), ("received", "Received", Q),
                              ("produced", "Produced", Q), ("consumed", "Consumed", Q), ("shipped", "Shipped", Q),
                              ("adjusted", "Adjusted", Q), ("closing", "Closing", Q)))


def r_production(c, p):
    fr, to = _range(p, 180)
    rows = all_(c, """
      SELECT m.id, m.number, i.sku, i.name, m.qty, m.qty_completed, m.status, m.completed_date, m.actual_cost,
        ROUND(m.qty_completed*(b.labor_cost+b.overhead_cost+COALESCE((SELECT SUM(l.qty_per*(1+l.scrap_pct/100.0)*c.std_cost)
          FROM bom_lines l JOIN items c ON c.id=l.component_id WHERE l.bom_id=b.id),0)),2) AS standard_cost
      FROM production_orders m JOIN items i ON i.id=m.item_id JOIN boms b ON b.id=m.bom_id
      WHERE m.qty_completed>0 AND COALESCE(m.completed_date, m.start_date) BETWEEN ? AND ? ORDER BY m.id DESC""", fr, to)
    for r in rows:
        r["variance"] = money(r["actual_cost"] - r["standard_cost"])
        r["unit_cost"] = round(r["actual_cost"] / r["qty_completed"], 4) if r["qty_completed"] else 0
    return dict(title=f"Production cost vs standard, {fr} to {to}", rows=rows, link="production_orders",
                params=["from", "to"],
                columns=_cols(("number", "MO #", T), ("sku", "SKU", T), ("name", "Item", T), ("qty_completed", "Produced", Q),
                              ("status", "Status", T), ("actual_cost", "Actual", M), ("standard_cost", "Standard", M),
                              ("variance", "Variance", M), ("unit_cost", "Unit cost", "cost")),
                totals={k: money(sum(r[k] for r in rows)) for k in ("actual_cost", "standard_cost", "variance")})


def r_asset_register(c, p):
    rows = all_(c, "SELECT id, tag, name, category, location_code, assigned_to, purchase_date, cost, salvage_value, "
                   "useful_life_months, book_value, status FROM v_assets WHERE status<>'disposed' ORDER BY tag")
    for r in rows:
        r["accum_dep"] = money(r["cost"] - r["book_value"])
        r["monthly_dep"] = money((r["cost"] - r["salvage_value"]) / r["useful_life_months"]) \
            if r["book_value"] > r["salvage_value"] + 0.004 else 0.0
    return dict(title="Fixed asset register (straight-line depreciation)", rows=rows, link="assets",
                columns=_cols(("tag", "Tag", T), ("name", "Asset", T), ("category", "Category", T),
                              ("location_code", "Location", T), ("assigned_to", "Assigned", T),
                              ("purchase_date", "Purchased", D), ("cost", "Cost", M), ("accum_dep", "Accum. dep.", M),
                              ("book_value", "Book value", M), ("monthly_dep", "Monthly dep.", M), ("status", "Status", T)),
                totals={k: money(sum(r[k] for r in rows)) for k in ("cost", "accum_dep", "book_value", "monthly_dep")})


def r_open_orders(c, p):
    rows = all_(c, """
      SELECT o.id, o.number, cu.name AS customer, o.ship_by, i.sku, i.name AS item, l.qty, l.qty_shipped,
        ROUND(l.qty-l.qty_shipped,4) AS open_qty, ROUND((l.qty-l.qty_shipped)*l.unit_price*(1-l.discount_pct/100.0),2) AS open_value,
        COALESCE((SELECT qty FROM stock WHERE item_id=l.item_id AND location_id=o.location_id),0) AS available,
        i.type
      FROM so_lines l JOIN sales_orders o ON o.id=l.so_id JOIN customers cu ON cu.id=o.customer_id JOIN items i ON i.id=l.item_id
      WHERE o.status IN ('confirmed','partial') AND l.qty>l.qty_shipped ORDER BY o.ship_by, o.number""")
    for r in rows:
        r["can_ship"] = "service" if r["type"] == "service" else ("yes" if r["available"] >= r["open_qty"] else
                                                                  "partial" if r["available"] > 0 else "no")
    return dict(title="Open sales order backlog", rows=rows, link="sales_orders",
                columns=_cols(("number", "SO #", T), ("customer", "Customer", T), ("ship_by", "Ship by", D),
                              ("sku", "SKU", T), ("item", "Item", T), ("open_qty", "Open qty", Q),
                              ("available", "Available", Q), ("can_ship", "Can ship", T), ("open_value", "Open value", M)),
                totals={"open_value": money(sum(r["open_value"] for r in rows))})


def r_headcount(c, p):
    rows = all_(c, "SELECT COALESCE(department,'(none)') AS department, COUNT(*) AS headcount, "
                   "SUM(CASE WHEN pay_type='hourly' THEN 1 ELSE 0 END) AS hourly, "
                   "SUM(CASE WHEN pay_type='salary' THEN 1 ELSE 0 END) AS salaried, "
                   "SUM(CASE WHEN status='leave' THEN 1 ELSE 0 END) AS on_leave, "
                   "ROUND(AVG((julianday('now')-julianday(hire_date))/365.25),1) AS avg_tenure_years "
                   "FROM employees WHERE status<>'terminated' GROUP BY department ORDER BY headcount DESC")
    return dict(title="Headcount by department", rows=rows,
                columns=_cols(("department", "Department", T), ("headcount", "Headcount", I), ("hourly", "Hourly", I),
                              ("salaried", "Salaried", I), ("on_leave", "On leave", I),
                              ("avg_tenure_years", "Avg tenure (yrs)", Q)),
                totals={"headcount": sum(r["headcount"] for r in rows)})


REPORTS = {
    "inventory_valuation": ("Inventory valuation", "Inventory", r_inventory_valuation, "viewer"),
    "stock_movement": ("Stock movement", "Inventory", r_stock_movement, "viewer"),
    "reorder": ("Reorder suggestions", "Inventory", r_reorder, "viewer"),
    "open_orders": ("Open order backlog", "Sales", r_open_orders, "viewer"),
    "sales_by_customer": ("Sales by customer", "Sales", r_sales_by_customer, "viewer"),
    "sales_by_item": ("Sales by item", "Sales", r_sales_by_item, "viewer"),
    "ar_aging": ("AR aging", "Finance", r_ar_aging, "viewer"),
    "ap_aging": ("AP aging", "Finance", r_ap_aging, "viewer"),
    "purchases_by_supplier": ("Purchases by supplier", "Purchasing", r_purchases_by_supplier, "viewer"),
    "production": ("Production cost variance", "Manufacturing", r_production, "viewer"),
    "asset_register": ("Asset register", "Assets", r_asset_register, "viewer"),
    "headcount": ("Headcount", "People", r_headcount, "manager"),
}


def run_report(c, ctx, name, params):
    if name not in REPORTS:
        raise BizError(f"Unknown report '{name}'.")
    label, grp, fn, role = REPORTS[name]
    require(ctx, role)
    out = fn(c, params)
    out.setdefault("params", [])
    out.setdefault("totals", {})
    out["name"] = name
    return out


def report_index():
    return [{"name": k, "label": v[0], "group": v[1], "role": v[3]} for k, v in REPORTS.items()]
