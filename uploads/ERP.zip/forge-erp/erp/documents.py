"""Composite record loading and printable business documents (HTML -> browser print / PDF)."""
from html import escape

from .db import NotFound, all_, get_settings, one
from .services import customer_exposure, requirements


def load(c, kind, id_):
    """Header + lines + related documents for a transactional or master record."""
    if kind == "purchase_orders":
        h = one(c, "SELECT * FROM v_purchase_orders WHERE id=?", id_)
        if not h:
            raise NotFound("Purchase order not found.")
        h["supplier"] = one(c, "SELECT * FROM suppliers WHERE id=?", h["supplier_id"])
        h["lines"] = all_(c, "SELECT l.*, i.sku, i.name, i.uom, ROUND(l.qty*l.unit_cost,2) AS amount FROM po_lines l "
                             "JOIN items i ON i.id=l.item_id WHERE l.po_id=? ORDER BY l.id", id_)
        h["receipts"] = all_(c, "SELECT * FROM v_receipts WHERE po_id=? ORDER BY id", id_)
        h["bills"] = all_(c, "SELECT * FROM v_bills WHERE po_id=? ORDER BY id", id_)
    elif kind == "sales_orders":
        h = one(c, "SELECT * FROM v_sales_orders WHERE id=?", id_)
        if not h:
            raise NotFound("Sales order not found.")
        h["customer"] = one(c, "SELECT * FROM v_customers WHERE id=?", h["customer_id"])
        h["lines"] = all_(c, "SELECT l.*, i.sku, i.name, i.uom, i.type AS item_type, "
                             "ROUND(l.qty*l.unit_price*(1-l.discount_pct/100.0),2) AS amount, "
                             "COALESCE((SELECT qty FROM stock WHERE item_id=l.item_id AND location_id=?),0) AS available "
                             "FROM so_lines l JOIN items i ON i.id=l.item_id WHERE l.so_id=? ORDER BY l.id",
                          h["location_id"], id_)
        h["tax"] = round(h["subtotal"] * h["tax_rate"], 2)
        h["total"] = round(h["subtotal"] + h["tax"], 2)
        h["shipments"] = all_(c, "SELECT * FROM v_shipments WHERE so_id=? ORDER BY id", id_)
        h["invoices"] = all_(c, "SELECT * FROM v_invoices WHERE so_id=? ORDER BY id", id_)
        ar, oo = customer_exposure(c, h["customer_id"], id_)
        h["credit"] = {"limit": h["customer"]["credit_limit"], "open_ar": ar, "open_orders": oo}
    elif kind == "production_orders":
        h = one(c, "SELECT * FROM v_production_orders WHERE id=?", id_)
        if not h:
            raise NotFound("Production order not found.")
        reqs = requirements(c, h["bom_id"], h["qty"])
        rem = requirements(c, h["bom_id"], max(0, h["qty"] - h["qty_completed"]))
        for r, rr in zip(reqs, rem):
            r["remaining"] = rr["required"]
            r["available"] = (one(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?",
                                  r["component_id"], h["location_id"]) or {}).get("qty", 0)
            r["short"] = max(0, round(r["remaining"] - r["available"], 4))
        h["components"] = reqs
        h["bom"] = one(c, "SELECT * FROM v_boms WHERE id=?", h["bom_id"])
        h["txns"] = all_(c, "SELECT * FROM v_inventory_txns WHERE ref_type='production' AND ref_id=? ORDER BY id", id_)
    elif kind == "boms":
        h = one(c, "SELECT * FROM v_boms WHERE id=?", id_)
        if not h:
            raise NotFound("BOM not found.")
        h["lines"] = all_(c, "SELECT l.*, i.sku, i.name, i.uom, i.avg_cost, i.std_cost, "
                             "ROUND(l.qty_per*(1+l.scrap_pct/100.0)*i.avg_cost,4) AS ext_cost "
                             "FROM bom_lines l JOIN items i ON i.id=l.component_id WHERE l.bom_id=? ORDER BY i.sku", id_)
        h["where_used"] = all_(c, "SELECT number, id, status, qty FROM production_orders WHERE bom_id=? ORDER BY id DESC "
                                  "LIMIT 20", id_)
    elif kind == "invoices":
        h = one(c, "SELECT * FROM v_invoices WHERE id=?", id_)
        if not h:
            raise NotFound("Invoice not found.")
        h["customer"] = one(c, "SELECT * FROM customers WHERE id=?", h["customer_id"])
        h["lines"] = all_(c, "SELECT l.*, i.sku, i.uom FROM invoice_lines l JOIN items i ON i.id=l.item_id "
                             "WHERE invoice_id=? ORDER BY l.id", id_)
        h["payments"] = all_(c, "SELECT * FROM payments WHERE invoice_id=? ORDER BY id", id_)
        h["so"] = one(c, "SELECT customer_po FROM sales_orders WHERE id=?", h["so_id"])
    elif kind == "bills":
        h = one(c, "SELECT * FROM v_bills WHERE id=?", id_)
        if not h:
            raise NotFound("Bill not found.")
        h["lines"] = all_(c, "SELECT l.*, i.sku, i.name, i.uom FROM bill_lines l JOIN items i ON i.id=l.item_id "
                             "WHERE bill_id=? ORDER BY l.id", id_)
        h["payments"] = all_(c, "SELECT * FROM supplier_payments WHERE bill_id=? ORDER BY id", id_)
    elif kind == "shipments":
        h = one(c, "SELECT * FROM v_shipments WHERE id=?", id_)
        if not h:
            raise NotFound("Shipment not found.")
        so = one(c, "SELECT * FROM sales_orders WHERE id=?", h["so_id"])
        h["customer"] = one(c, "SELECT * FROM customers WHERE id=?", so["customer_id"])
        h["customer_po"] = so["customer_po"]
        h["lines"] = all_(c, "SELECT sl.*, i.sku, i.name, i.uom, l.qty AS ordered, l.qty_shipped AS total_shipped "
                             "FROM shipment_lines sl JOIN items i ON i.id=sl.item_id JOIN so_lines l ON l.id=sl.so_line_id "
                             "WHERE sl.shipment_id=? ORDER BY sl.id", id_)
        h["invoice"] = one(c, "SELECT id, number, status FROM invoices WHERE shipment_id=? AND status<>'void'", id_)
    elif kind == "receipts":
        h = one(c, "SELECT * FROM v_receipts WHERE id=?", id_)
        if not h:
            raise NotFound("Receipt not found.")
        h["lines"] = all_(c, "SELECT rl.*, i.sku, i.name, i.uom, l.qty AS ordered, l.qty_received AS total_received "
                             "FROM receipt_lines rl JOIN items i ON i.id=rl.item_id JOIN po_lines l ON l.id=rl.po_line_id "
                             "WHERE rl.receipt_id=? ORDER BY rl.id", id_)
    elif kind == "items":
        h = one(c, "SELECT * FROM v_items WHERE id=?", id_)
        if not h:
            raise NotFound("Item not found.")
        h["stock"] = all_(c, "SELECT * FROM v_stock WHERE item_id=? ORDER BY location_code", id_)
        h["txns"] = all_(c, "SELECT * FROM v_inventory_txns WHERE item_id=? ORDER BY id DESC LIMIT 100", id_)
        h["boms"] = all_(c, "SELECT * FROM v_boms WHERE item_id=? ORDER BY active DESC, version", id_)
        h["used_in"] = all_(c, "SELECT b.id, i.sku, i.name, b.version, l.qty_per FROM bom_lines l JOIN boms b ON b.id=l.bom_id "
                               "JOIN items i ON i.id=b.item_id WHERE l.component_id=? AND b.active=1", id_)
    elif kind == "customers":
        h = one(c, "SELECT * FROM v_customers WHERE id=?", id_)
        if not h:
            raise NotFound("Customer not found.")
        h["orders"] = all_(c, "SELECT * FROM v_sales_orders WHERE customer_id=? ORDER BY id DESC LIMIT 25", id_)
        h["invoices"] = all_(c, "SELECT * FROM v_invoices WHERE customer_id=? ORDER BY id DESC LIMIT 25", id_)
        ar, oo = customer_exposure(c, id_)
        h["credit"] = {"limit": h["credit_limit"], "open_ar": ar, "open_orders": oo}
    elif kind == "suppliers":
        h = one(c, "SELECT * FROM v_suppliers WHERE id=?", id_)
        if not h:
            raise NotFound("Supplier not found.")
        h["orders"] = all_(c, "SELECT * FROM v_purchase_orders WHERE supplier_id=? ORDER BY id DESC LIMIT 25", id_)
        h["bills"] = all_(c, "SELECT * FROM v_bills WHERE supplier_id=? ORDER BY id DESC LIMIT 25", id_)
        h["items"] = all_(c, "SELECT id, sku, name, avg_cost FROM items WHERE preferred_supplier_id=? ORDER BY sku", id_)
    elif kind == "assets":
        h = one(c, "SELECT * FROM v_assets WHERE id=?", id_)
        if not h:
            raise NotFound("Asset not found.")
        h["events"] = all_(c, "SELECT * FROM asset_events WHERE asset_id=? ORDER BY date DESC, id DESC", id_)
    elif kind == "employees":
        h = one(c, "SELECT * FROM v_employees WHERE id=?", id_)
        if not h:
            raise NotFound("Employee not found.")
        h["reports"] = all_(c, "SELECT id, code, full_name, title FROM v_employees WHERE manager_id=? ORDER BY last_name", id_)
        h["assets"] = all_(c, "SELECT id, tag, name, status FROM assets WHERE employee_id=? ORDER BY tag", id_)
    else:
        raise NotFound(f"Unknown record type '{kind}'.")
    h["history"] = all_(c, "SELECT ts, username, action, summary FROM audit_log WHERE entity=? AND entity_id=? "
                           "ORDER BY id DESC LIMIT 50", kind, id_)
    return h


# ------------------------------------------------------------------- printable documents
CSS = """
*{box-sizing:border-box}body{font:13px/1.45 -apple-system,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;color:#111;
margin:0;background:#eee}.page{background:#fff;max-width:820px;margin:20px auto;padding:44px 48px;box-shadow:0 1px 4px #0002}
h1{font-size:22px;margin:0;letter-spacing:.04em;text-transform:uppercase}.top{display:flex;justify-content:space-between;
border-bottom:2px solid #111;padding-bottom:14px;margin-bottom:20px}.co b{font-size:16px}.muted{color:#555}
.meta td{padding:1px 0 1px 14px;text-align:right}.meta td:first-child{color:#555}.cols{display:flex;gap:40px;margin-bottom:22px}
.cols>div{flex:1}.lbl{font-size:10px;text-transform:uppercase;letter-spacing:.08em;color:#666;margin-bottom:3px}
table.lines{width:100%;border-collapse:collapse;margin-top:6px}table.lines th{text-align:left;font-size:10px;
text-transform:uppercase;letter-spacing:.06em;border-bottom:1px solid #111;padding:6px 6px}table.lines td{padding:6px;
border-bottom:1px solid #ddd;vertical-align:top}.r{text-align:right}.tot{margin-left:auto;margin-top:12px;min-width:260px}
.tot td{padding:3px 6px}.tot tr.g td{border-top:2px solid #111;font-weight:700;font-size:15px}.note{margin-top:26px;
font-size:12px;color:#444;border-top:1px solid #ddd;padding-top:10px}.sig{display:flex;gap:40px;margin-top:50px}
.sig div{flex:1;border-top:1px solid #111;padding-top:4px;font-size:11px;color:#555}.bar{max-width:820px;margin:16px auto 0;
text-align:right}.bar button{font:inherit;padding:7px 16px;border:1px solid #111;background:#111;color:#fff;cursor:pointer}
.stamp{display:inline-block;border:2px solid #b00;color:#b00;padding:2px 10px;font-weight:700;transform:rotate(-4deg);
text-transform:uppercase;margin-left:10px}
@media print{body{background:#fff}.page{box-shadow:none;margin:0;max-width:none;padding:0}.bar{display:none}
@page{margin:16mm}}
"""


def _e(v):
    return escape("" if v is None else str(v))


def _m(v, cur):
    return f"{cur}{(v or 0):,.2f}"


def _q(v):
    return f"{(v or 0):,.4f}".rstrip("0").rstrip(".")


def _addr(p):
    if not p:
        return ""
    bits = [p.get("name"), p.get("address"), " ".join(x for x in [p.get("city") and p["city"] + ",", p.get("state"),
                                                                    p.get("postal")] if x), p.get("email"), p.get("phone")]
    return "<br>".join(_e(b) for b in bits if b)


def _shell(s, title, number, meta, body, stamp=None):
    rows = "".join(f"<tr><td>{_e(k)}</td><td><b>{_e(v)}</b></td></tr>" for k, v in meta if v not in (None, ""))
    st = f'<span class="stamp">{_e(stamp)}</span>' if stamp else ""
    return (f"<!DOCTYPE html><html><head><meta charset='utf-8'><title>{_e(title)} {_e(number)}</title>"
            f"<style>{CSS}</style></head><body><div class='bar'><button onclick='print()'>Print / Save PDF</button></div>"
            f"<div class='page'><div class='top'><div class='co'><b>{_e(s['company_name'])}</b><br>"
            f"<span class='muted'>{_e(s['company_address'])}<br>{_e(s['company_phone'])} · {_e(s['company_email'])}</span>"
            f"</div><div><h1>{_e(title)}{st}</h1><table class='meta'>{rows}</table></div></div>{body}</div></body></html>")


def _table(headers, rows):
    th = "".join(f"<th class='{'r' if r else ''}'>{_e(h)}</th>" for h, r in headers)
    tb = "".join("<tr>" + "".join(f"<td class='{'r' if headers[i][1] else ''}'>{v}</td>" for i, v in enumerate(row))
                 + "</tr>" for row in rows)
    return f"<table class='lines'><thead><tr>{th}</tr></thead><tbody>{tb}</tbody></table>"


def _totals(pairs):
    return "<table class='tot'>" + "".join(
        f"<tr class='{'g' if g else ''}'><td>{_e(k)}</td><td class='r'>{_e(v)}</td></tr>" for k, v, g in pairs) + "</table>"


def render(c, doc, id_):
    s = get_settings(c)
    cur = s["currency_symbol"]
    if doc == "purchase_order":
        h = load(c, "purchase_orders", id_)
        body = (f"<div class='cols'><div><div class='lbl'>Supplier</div>{_addr(h['supplier'])}</div>"
                f"<div><div class='lbl'>Ship to</div>{_e(s['company_name'])}<br>{_e(h['location_code'])}<br>"
                f"{_e(s['company_address'])}</div></div>"
                + _table([("SKU", 0), ("Description", 0), ("Qty", 1), ("UoM", 0), ("Unit cost", 1), ("Amount", 1)],
                         [[_e(l["sku"]), _e(l["name"]), _q(l["qty"]), _e(l["uom"]), _m(l["unit_cost"], cur),
                           _m(l["amount"], cur)] for l in h["lines"]])
                + _totals([("Total", _m(h["total"], cur), 1)])
                + (f"<div class='note'>{_e(h['notes'])}</div>" if h.get("notes") else "")
                + f"<div class='note'>Payment terms: net {h['supplier']['terms_days']} days. Please reference "
                  f"{_e(h['number'])} on all shipments and invoices.</div>"
                + "<div class='sig'><div>Authorized by</div><div>Date</div></div>")
        return _shell(s, "Purchase Order", h["number"], [("PO #", h["number"]), ("Date", h["order_date"]),
                                                         ("Expected", h["expected_date"]), ("Approved by", h["approved_by"])],
                      body, "Draft" if h["status"] == "draft" else "Cancelled" if h["status"] == "cancelled" else None)
    if doc == "invoice":
        h = load(c, "invoices", id_)
        pays = sum(p["amount"] for p in h["payments"])
        body = (f"<div class='cols'><div><div class='lbl'>Bill to</div>{_addr(h['customer'])}</div>"
                f"<div><div class='lbl'>Reference</div>Sales order {_e(h['so_number'])}<br>"
                f"Customer PO {_e((h['so'] or {}).get('customer_po') or '—')}<br>Shipment {_e(h['shipment_number'] or '—')}"
                f"</div></div>"
                + _table([("SKU", 0), ("Description", 0), ("Qty", 1), ("Unit price", 1), ("Amount", 1)],
                         [[_e(l["sku"]), _e(l["description"]), _q(l["qty"]), _m(l["unit_price"], cur),
                           _m(l["amount"], cur)] for l in h["lines"]])
                + _totals([("Subtotal", _m(h["subtotal"], cur), 0), ("Tax", _m(h["tax"], cur), 0),
                           ("Total", _m(h["total"], cur), 1), ("Payments", "-" + _m(pays, cur), 0),
                           ("Balance due", _m(h["balance"], cur), 1)])
                + f"<div class='note'>Terms: net {h['customer']['terms_days']} days, due {_e(h['due_date'])}. "
                  f"Please remit to {_e(s['company_name'])}, {_e(s['company_address'])}.</div>")
        return _shell(s, "Invoice", h["number"], [("Invoice #", h["number"]), ("Date", h["date"]), ("Due", h["due_date"])],
                      body, "Void" if h["status"] == "void" else "Paid" if h["status"] == "paid" else None)
    if doc == "packing_slip":
        h = load(c, "shipments", id_)
        body = (f"<div class='cols'><div><div class='lbl'>Ship to</div>{_addr(h['customer'])}</div>"
                f"<div><div class='lbl'>Shipping</div>Carrier: {_e(h['carrier'] or '—')}<br>Tracking: "
                f"{_e(h['tracking'] or '—')}<br>Order: {_e(h['so_number'])}<br>Customer PO: {_e(h['customer_po'] or '—')}"
                f"</div></div>"
                + _table([("SKU", 0), ("Description", 0), ("UoM", 0), ("Ordered", 1), ("This shipment", 1),
                          ("Backordered", 1)],
                         [[_e(l["sku"]), _e(l["name"]), _e(l["uom"]), _q(l["ordered"]), f"<b>{_q(l['qty'])}</b>",
                           _q(max(0, l["ordered"] - l["total_shipped"]))] for l in h["lines"]])
                + "<div class='sig'><div>Packed by</div><div>Received by (signature)</div><div>Date</div></div>")
        return _shell(s, "Packing Slip", h["number"], [("Shipment #", h["number"]), ("Date", h["date"]),
                                                       ("From", h["location_code"])], body)
    if doc == "receiving_report":
        h = load(c, "receipts", id_)
        body = (_table([("SKU", 0), ("Description", 0), ("UoM", 0), ("Ordered", 1), ("Received now", 1),
                        ("Total received", 1), ("Unit cost", 1)],
                       [[_e(l["sku"]), _e(l["name"]), _e(l["uom"]), _q(l["ordered"]), f"<b>{_q(l['qty'])}</b>",
                         _q(l["total_received"]), _m(l["unit_cost"], cur)] for l in h["lines"]])
                + _totals([("Received value", _m(h["value"], cur), 1)])
                + "<div class='sig'><div>Received by</div><div>Inspected by</div></div>")
        return _shell(s, "Receiving Report", h["number"], [("Receipt #", h["number"]), ("PO #", h["po_number"]),
                                                           ("Supplier", h["supplier_name"]), ("Date", h["date"]),
                                                           ("Location", h["location_code"])], body)
    if doc == "traveler":
        h = load(c, "production_orders", id_)
        body = (f"<div class='cols'><div><div class='lbl'>Build</div><b>{_e(h['sku'])}</b> {_e(h['item_name'])}<br>"
                f"Quantity {_q(h['qty'])} · BOM rev {_e(h['bom_version'])}</div><div><div class='lbl'>Schedule</div>"
                f"Start {_e(h['start_date'])}<br>Due {_e(h['due_date'])}</div></div>"
                "<div class='lbl'>Material pick list</div>"
                + _table([("Component", 0), ("Description", 0), ("UoM", 0), ("Per unit", 1), ("Scrap %", 1),
                          ("Pick qty", 1), ("Picked", 0)],
                         [[_e(r["sku"]), _e(r["name"]), _e(r["uom"]), _q(r["qty_per"]), _q(r["scrap_pct"]),
                           f"<b>{_q(r['remaining'])}</b>", "______"] for r in h["components"]])
                + (f"<div class='note'>{_e(h['notes'])}</div>" if h.get("notes") else "")
                + "<div class='sig'><div>Picked by</div><div>Built by</div><div>QC</div></div>")
        return _shell(s, "Production Traveler", h["number"], [("MO #", h["number"]), ("Status", h["status"])], body)
    if doc == "statement":
        cu = one(c, "SELECT * FROM customers WHERE id=?", id_)
        if not cu:
            raise NotFound("Customer not found.")
        inv = all_(c, "SELECT * FROM v_invoices WHERE customer_id=? AND status IN ('open','partial') ORDER BY date", id_)
        body = (f"<div class='cols'><div><div class='lbl'>Customer</div>{_addr(cu)}</div><div></div></div>"
                + _table([("Invoice", 0), ("Date", 0), ("Due", 0), ("Days late", 1), ("Total", 1), ("Paid", 1),
                          ("Balance", 1)],
                         [[_e(v["number"]), _e(v["date"]), _e(v["due_date"]), str(v["days_overdue"] or ""),
                           _m(v["total"], cur), _m(v["amount_paid"], cur), _m(v["balance"], cur)] for v in inv])
                + _totals([("Balance due", _m(sum(v["balance"] for v in inv), cur), 1)]))
        from .db import today
        return _shell(s, "Statement", cu["code"], [("Customer", cu["code"]), ("Statement date", today())], body)
    raise NotFound(f"Unknown document '{doc}'.")
