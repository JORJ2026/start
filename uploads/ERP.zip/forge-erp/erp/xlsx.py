"""Dependency-free XLSX writer/reader and CSV helpers (Office Open XML, first sheet)."""
import csv
import io
import re
import zipfile
from datetime import date, datetime, timedelta
from xml.etree import ElementTree as ET
from xml.sax.saxutils import escape

NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
      "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
      "pr": "http://schemas.openxmlformats.org/package/2006/relationships"}
_ILLEGAL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


def _col(n):
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def write_xlsx(headers, rows, sheet="Sheet1"):
    out = []
    for ri, row in enumerate([headers] + list(rows), 1):
        cells = []
        for ci, v in enumerate(row):
            ref = f"{_col(ci)}{ri}"
            style = ' s="1"' if ri == 1 else ""
            if v is None or v == "":
                continue
            if isinstance(v, bool):
                cells.append(f'<c r="{ref}" t="b"{style}><v>{int(v)}</v></c>')
            elif isinstance(v, (int, float)) and ri > 1:
                cells.append(f'<c r="{ref}"{style}><v>{v!r}</v></c>')
            else:
                t = escape(_ILLEGAL.sub("", str(v)))
                cells.append(f'<c r="{ref}" t="inlineStr"{style}><is><t xml:space="preserve">{t}</t></is></c>')
        out.append(f'<row r="{ri}">{"".join(cells)}</row>')
    widths = "".join(f'<col min="{i+1}" max="{i+1}" width="{min(48, max(10, len(str(h)) + 4))}" customWidth="1"/>'
                     for i, h in enumerate(headers))
    sheet_xml = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 f'<worksheet xmlns="{NS["m"]}"><sheetViews><sheetView workbookViewId="0">'
                 '<pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                 f'<cols>{widths}</cols><sheetData>{"".join(out)}</sheetData></worksheet>')
    name = escape(re.sub(r"[\[\]\*\?/\\:]", "", sheet)[:31] or "Sheet1")
    files = {
        "[Content_Types].xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
        '<Default Extension="xml" ContentType="application/xml"/>'
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
        '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
        '</Types>',
        "_rels/.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<Relationships xmlns="{NS["pr"]}"><Relationship Id="rId1" '
        'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
        '</Relationships>',
        "xl/workbook.xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<workbook xmlns="{NS["m"]}" xmlns:r="{NS["r"]}"><sheets>'
        f'<sheet name="{name}" sheetId="1" r:id="rId1"/></sheets></workbook>',
        "xl/_rels/workbook.xml.rels": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<Relationships xmlns="{NS["pr"]}">'
        '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
        '<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>'
        '</Relationships>',
        "xl/styles.xml": '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
        f'<styleSheet xmlns="{NS["m"]}"><fonts count="2"><font><sz val="11"/><name val="Calibri"/></font>'
        '<font><b/><sz val="11"/><name val="Calibri"/></font></fonts>'
        '<fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills>'
        '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
        '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
        '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>'
        '<xf numFmtId="0" fontId="1" fillId="0" borderId="0" xfId="0" applyFont="1"/></cellXfs></styleSheet>',
        "xl/worksheets/sheet1.xml": sheet_xml,
    }
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for k, v in files.items():
            z.writestr(k, v)
    return buf.getvalue()


_DATE_FMT_IDS = set(range(14, 23)) | {45, 46, 47}


def read_xlsx(data, max_rows=50000):
    """Return (headers, rows) from the first worksheet. Values are str/float/bool/ISO date."""
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ValueError("File is not a valid .xlsx workbook.")
    names = set(z.namelist())
    shared = []
    if "xl/sharedStrings.xml" in names:
        for si in ET.fromstring(z.read("xl/sharedStrings.xml")).findall("m:si", NS):
            shared.append("".join(t.text or "" for t in si.iter(f"{{{NS['m']}}}t")))
    date_styles = set()
    if "xl/styles.xml" in names:
        st = ET.fromstring(z.read("xl/styles.xml"))
        custom = {}
        nf = st.find("m:numFmts", NS)
        if nf is not None:
            for f in nf.findall("m:numFmt", NS):
                code = re.sub(r'"[^"]*"|\[[^\]]*\]', "", f.get("formatCode", "").lower())
                custom[int(f.get("numFmtId"))] = bool(re.search(r"[dy]", code)) or ("m" in code and "h" not in code and "s" not in code)
        xfs = st.find("m:cellXfs", NS)
        if xfs is not None:
            for i, xf in enumerate(xfs.findall("m:xf", NS)):
                fid = int(xf.get("numFmtId", 0))
                if fid in _DATE_FMT_IDS or custom.get(fid):
                    date_styles.add(i)
    wb = ET.fromstring(z.read("xl/workbook.xml"))
    first = wb.find("m:sheets/m:sheet", NS)
    rid = first.get(f"{{{NS['r']}}}id")
    rels = ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    target = next(r.get("Target") for r in rels.findall("pr:Relationship", NS) if r.get("Id") == rid)
    path = target.lstrip("/") if target.startswith("/") else "xl/" + target
    ws = ET.fromstring(z.read(path))
    grid = []
    for row in ws.iter(f"{{{NS['m']}}}row"):
        vals = {}
        for cell in row.findall("m:c", NS):
            ref = cell.get("r", "")
            letters = re.match(r"[A-Z]+", ref)
            ci = 0
            if letters:
                for ch in letters.group(0):
                    ci = ci * 26 + (ord(ch) - 64)
                ci -= 1
            else:
                ci = len(vals)
            t = cell.get("t")
            v = cell.find("m:v", NS)
            if t == "inlineStr":
                val = "".join(x.text or "" for x in cell.iter(f"{{{NS['m']}}}t"))
            elif v is None:
                val = None
            elif t == "s":
                val = shared[int(v.text)]
            elif t == "b":
                val = v.text == "1"
            elif t in ("str", "e"):
                val = v.text
            else:
                num = float(v.text)
                if int(cell.get("s", 0)) in date_styles:
                    val = (datetime(1899, 12, 30) + timedelta(days=num)).date().isoformat()
                else:
                    val = int(num) if num.is_integer() else num
            vals[ci] = val
        if vals:
            grid.append([vals.get(i) for i in range(max(vals) + 1)])
        if len(grid) > max_rows:
            raise ValueError(f"Workbook exceeds {max_rows} rows.")
    if not grid:
        return [], []
    headers = [str(h).strip() if h is not None else "" for h in grid[0]]
    rows = [r + [None] * (len(headers) - len(r)) for r in grid[1:]]
    return headers, [r[:len(headers)] for r in rows if any(x not in (None, "") for x in r)]


def write_csv(headers, rows):
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(headers)
    for r in rows:
        w.writerow(["" if v is None else _csv_safe(v) for v in r])
    return ("﻿" + buf.getvalue()).encode("utf-8")


def _csv_safe(v):
    # neutralise spreadsheet formula injection in exported text
    if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") and not re.fullmatch(r"-?\d+(\.\d+)?", v):
        return "'" + v
    return v


def read_csv(data):
    text = data.decode("utf-8-sig", errors="replace")
    try:
        dialect = csv.Sniffer().sniff(text[:4096], delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    rows = list(csv.reader(io.StringIO(text), dialect))
    if not rows:
        return [], []
    headers = [h.strip() for h in rows[0]]
    return headers, [r for r in rows[1:] if any(x.strip() for x in r)]


def read_table(filename, data):
    name = (filename or "").lower()
    if name.endswith(".xlsx") or data[:2] == b"PK":
        return read_xlsx(data)
    return read_csv(data)
