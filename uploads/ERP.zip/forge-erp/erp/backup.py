"""Online backup, verified restore, retention."""
import os
import re
import shutil
import sqlite3
from datetime import datetime

from .db import BizError, SCHEMA_VERSION, WRITE_LOCK

NAME_RE = re.compile(r"^[A-Za-z0-9_.-]+\.db$")


def backup_dir(db_path):
    d = os.path.join(os.path.dirname(os.path.abspath(db_path)), "backups")
    os.makedirs(d, exist_ok=True)
    return d


def create_backup(conn, db_path, label="manual"):
    """Consistent hot copy using SQLite's online backup API."""
    label = re.sub(r"[^a-z0-9_-]", "", label.lower())[:20] or "manual"
    name = f"erp-{datetime.now().strftime('%Y%m%d-%H%M%S-%f')[:-3]}-{label}.db"
    path = os.path.join(backup_dir(db_path), name)
    dest = sqlite3.connect(path)
    try:
        with WRITE_LOCK:
            conn.backup(dest)
    finally:
        dest.close()
    verify_backup(path)
    return {"name": name, "size": os.path.getsize(path)}


def verify_backup(path):
    """Raise BizError unless the file is an intact Forge ERP database of a compatible version."""
    try:
        c = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
        try:
            if c.execute("PRAGMA integrity_check").fetchone()[0] != "ok":
                raise BizError("Backup failed the integrity check.")
            if not c.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='meta'").fetchone():
                raise BizError("File is not a Forge ERP database.")
            app = c.execute("SELECT value FROM meta WHERE key='app'").fetchone()
            ver = c.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
            if not app or app[0] != "forge-erp":
                raise BizError("File is not a Forge ERP database.")
            if not ver or int(ver[0]) > SCHEMA_VERSION:
                raise BizError("Backup was made by a newer version of the application.")
            if c.execute("PRAGMA foreign_key_check").fetchone():
                raise BizError("Backup contains broken references.")
            return {"ok": True, "schema_version": int(ver[0]),
                    "counts": {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0]
                               for t in ("customers", "items", "sales_orders", "purchase_orders", "invoices")}}
        finally:
            c.close()
    except sqlite3.DatabaseError as e:
        raise BizError(f"File is not a readable database: {e}")


def list_backups(db_path):
    d = backup_dir(db_path)
    out = []
    for n in sorted(os.listdir(d), reverse=True):
        if NAME_RE.match(n):
            p = os.path.join(d, n)
            out.append({"name": n, "size": os.path.getsize(p),
                        "modified": datetime.fromtimestamp(os.path.getmtime(p)).strftime("%Y-%m-%d %H:%M:%S")})
    return out


def backup_path(db_path, name):
    if not NAME_RE.match(name or "") or "/" in name or "\\" in name:
        raise BizError("Invalid backup name.")
    p = os.path.join(backup_dir(db_path), name)
    if not os.path.isfile(p):
        raise BizError("Backup not found.")
    return p


def restore_from_file(conn, db_path, src_path):
    """Verify src, take a safety backup of the live DB, then copy src into the live DB in place."""
    info = verify_backup(src_path)
    safety = create_backup(conn, db_path, "pre-restore")
    src = sqlite3.connect(f"file:{src_path}?mode=ro", uri=True)
    try:
        with WRITE_LOCK:
            src.backup(conn)
    finally:
        src.close()
    conn.execute("PRAGMA foreign_keys=ON")
    return {"restored": os.path.basename(src_path), "safety_backup": safety["name"], **info}


def save_upload(db_path, data):
    if not data.startswith(b"SQLite format 3\x00"):
        raise BizError("Uploaded file is not an SQLite database.")
    name = f"erp-{datetime.now().strftime('%Y%m%d-%H%M%S')}-upload.db"
    p = os.path.join(backup_dir(db_path), name)
    with open(p, "wb") as f:
        f.write(data)
    try:
        verify_backup(p)
    except BizError:
        os.remove(p)
        raise
    return p


def prune(db_path, keep):
    files = [b for b in list_backups(db_path) if b["name"].endswith(("-auto.db", "-startup.db"))]
    for b in files[keep:]:
        os.remove(os.path.join(backup_dir(db_path), b["name"]))


def copy_db_file(db_path, dest):
    shutil.copy2(db_path, dest)
