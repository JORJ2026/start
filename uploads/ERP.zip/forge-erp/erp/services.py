"""Business logic: inventory ledger, procure-to-pay, order-to-cash, manufacturing.

Every public function takes a connection and a Ctx and runs inside one atomic
transaction. Any BizError rolls the whole operation back.
"""
from dataclasses import dataclass
from datetime import date, timedelta

from .db import (EPS, BizError, Forbidden, NotFound, all_, audit, money, next_number, now, one,
                 qty4, scalar, setting, today, tx)

ROLE_RANK = {"viewer": 0, "clerk": 1, "manager": 2, "admin": 3}


@dataclass
class Ctx:
    username: str = "system"
    role: str = "admin"


SYSTEM = Ctx()


def require(ctx, role):
    if ROLE_RANK.get(ctx.role, -1) < ROLE_RANK[role]:
        raise Forbidden(f"This action requires the '{role}' role or higher.")


def _num(v, name, positive=False, allow_zero=True):
    try:
        f = float(v)
    except (TypeError, ValueError):
        raise BizError(f"{name} must be a number.")
    if f != f or f in (float("inf"), float("-inf")):
        raise BizError(f"{name} must be a finite number.")
    if positive and (f < 0 or (not allow_zero and f <= EPS)):
        raise BizError(f"{name} must be greater than zero." if not allow_zero else f"{name} cannot be negative.")
    return f


def _date(v, name="Date", default=None):
    if v in (None, ""):
        if default is not None:
            return default
        raise BizError(f"{name} is required.")
    try:
        return date.fromisoformat(str(v)[:10]).isoformat()
    except ValueError:
        raise BizError(f"{name} must be a date in YYYY-MM-DD format.")


def _add_days(d, n):
    return (date.fromisoformat(d) + timedelta(days=int(n))).isoformat()


def _get(c, table, id_, label=None):
    r = one(c, f"SELECT * FROM {table} WHERE id=?", id_)
    if not r:
        raise NotFound(f"{label or table} {id_} not found.")
    return r


def _ts(d):
    """Use the document date with the current wall time so ledger order is stable."""
    if d and d != today():
        return f"{d}T12:00:00"
    return now()


# ---------------------------------------------------------------- inventory
def post_inventory(c, ctx, item_id, location_id, qty, type_, unit_cost=None, ref_type=None, ref_id=None,
                   note=None, ts=None):
    qty = qty4(qty)
    if abs(qty) < EPS:
        return None
    item = _get(c, "items", item_id, "Item")
    loc = _get(c, "locations", location_id, "Location")
    if item["type"] == "service":
        raise BizError(f"{item['sku']} is a service item and is not stocked.")
    cur = scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", item_id, location_id) or 0.0
    new = qty4(cur + qty)
    if new < -EPS and not setting(c, "allow_negative_stock"):
        raise BizError(f"Insufficient stock for {item['sku']} at {loc['code']}: "
                       f"on hand {cur:g}, required {-qty:g}.")
    total = scalar(c, "SELECT COALESCE(SUM(qty),0) FROM stock WHERE item_id=?", item_id) or 0.0
    avg = item["avg_cost"] or 0.0
    if qty > 0 and type_ != "transfer_in":
        uc = avg if unit_cost is None else float(unit_cost)
        new_avg = uc if total <= EPS else (total * avg + qty * uc) / (total + qty)
        c.execute("UPDATE items SET avg_cost=? WHERE id=?", (round(new_avg, 6), item_id))
    else:
        uc = avg if unit_cost is None or qty < 0 else float(unit_cost)
    c.execute("INSERT INTO stock(item_id,location_id,qty) VALUES(?,?,?) "
              "ON CONFLICT(item_id,location_id) DO UPDATE SET qty=excluded.qty", (item_id, location_id, new))
    cur_ = c.execute("INSERT INTO inventory_txns(ts,item_id,location_id,qty,unit_cost,type,ref_type,ref_id,"
                     "balance_after,username,note) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                     (ts or now(), item_id, location_id, qty, round(uc, 6), type_, ref_type, ref_id, new,
                      ctx.username, note))
    return {"txn_id": cur_.lastrowid, "unit_cost": uc, "balance": new}


def adjust_stock(c, ctx, item_id, location_id, qty=None, counted=None, reason="", unit_cost=None, date_=None):
    """Adjust by a delta (qty) or set to a physical count (counted)."""
    require(ctx, "manager")
    if not (reason or "").strip():
        raise BizError("A reason is required for inventory adjustments.")
    with tx(c):
        cur = scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", item_id, location_id) or 0.0
        if counted not in (None, ""):
            counted = _num(counted, "Counted quantity", positive=True)
            delta = qty4(counted - cur)
            note = f"Cycle count: {cur:g} -> {counted:g}. {reason}"
        else:
            delta = _num(qty, "Adjustment quantity")
            note = reason
        if abs(delta) < EPS:
            return {"delta": 0}
        r = post_inventory(c, ctx, item_id, location_id, delta, "adjustment",
                           None if unit_cost in (None, "") else _num(unit_cost, "Unit cost", True),
                           "adjustment", None, note, _ts(_date(date_, default=today())))
        audit(c, ctx.username, "adjust", "items", item_id, f"Stock adjusted by {delta:g} ({reason})")
        return {"delta": delta, **r}


def transfer_stock(c, ctx, item_id, from_loc, to_loc, qty, note="", date_=None):
    require(ctx, "clerk")
    qty = _num(qty, "Quantity", positive=True, allow_zero=False)
    if int(from_loc) == int(to_loc):
        raise BizError("Source and destination locations must differ.")
    with tx(c):
        ts = _ts(_date(date_, default=today()))
        out = post_inventory(c, ctx, item_id, from_loc, -qty, "transfer_out", None, "transfer", None, note, ts)
        post_inventory(c, ctx, item_id, to_loc, qty, "transfer_in", out["unit_cost"], "transfer",
                       out["txn_id"], note, ts)
        audit(c, ctx.username, "transfer", "items", item_id, f"Transferred {qty:g} from loc {from_loc} to {to_loc}")
        return {"ok": True}


# ---------------------------------------------------------------- purchasing
def _clean_lines(c, lines, price_key, price_label):
    if not lines:
        raise BizError("At least one line is required.")
    out = []
    for i, ln in enumerate(lines, 1):
        if not ln.get("item_id"):
            raise BizError(f"Line {i}: item is required.")
        item = _get(c, "items", int(ln["item_id"]), "Item")
        if not item["active"]:
            raise BizError(f"Line {i}: item {item['sku']} is inactive.")
        q = _num(ln.get("qty"), f"Line {i} quantity", positive=True, allow_zero=False)
        p = ln.get(price_key)
        p = _num(p if p not in (None, "") else (item["price"] if price_key == "unit_price" else
                                                 (item["avg_cost"] or item["std_cost"])),
                 f"Line {i} {price_label}", positive=True)
        d = _num(ln.get("discount_pct") or 0, f"Line {i} discount", positive=True)
        if d > 100:
            raise BizError(f"Line {i}: discount cannot exceed 100%.")
        out.append({"item_id": item["id"], "qty": qty4(q), price_key: round(p, 4), "discount_pct": d, "_item": item})
    return out


def po_total(c, po_id):
    return money(scalar(c, "SELECT COALESCE(SUM(qty*unit_cost),0) FROM po_lines WHERE po_id=?", po_id))


def save_po(c, ctx, data):
    require(ctx, "clerk")
    with tx(c):
        sup = _get(c, "suppliers", int(data.get("supplier_id") or 0), "Supplier")
        if not sup["active"]:
            raise BizError(f"Supplier {sup['code']} is inactive.")
        loc_id = int(data.get("location_id") or scalar(c, "SELECT id FROM locations ORDER BY id LIMIT 1"))
        _get(c, "locations", loc_id, "Location")
        od = _date(data.get("order_date"), "Order date", today())
        ed = _date(data.get("expected_date"), "Expected date", _add_days(od, sup["lead_time_days"]))
        lines = _clean_lines(c, data.get("lines"), "unit_cost", "unit cost")
        if data.get("id"):
            po = _get(c, "purchase_orders", int(data["id"]), "Purchase order")
            if po["status"] != "draft":
                raise BizError(f"{po['number']} is {po['status']}; only draft orders can be edited.")
            c.execute("UPDATE purchase_orders SET supplier_id=?,order_date=?,expected_date=?,location_id=?,notes=? "
                      "WHERE id=?", (sup["id"], od, ed, loc_id, data.get("notes"), po["id"]))
            c.execute("DELETE FROM po_lines WHERE po_id=?", (po["id"],))
            pid, num, act = po["id"], po["number"], "update"
        else:
            num = next_number(c, "purchase_orders")
            pid = c.execute("INSERT INTO purchase_orders(number,supplier_id,status,order_date,expected_date,"
                            "location_id,notes,created_by) VALUES(?,?,?,?,?,?,?,?)",
                            (num, sup["id"], "draft", od, ed, loc_id, data.get("notes"), ctx.username)).lastrowid
            act = "create"
        for ln in lines:
            c.execute("INSERT INTO po_lines(po_id,item_id,qty,unit_cost) VALUES(?,?,?,?)",
                      (pid, ln["item_id"], ln["qty"], ln["unit_cost"]))
        audit(c, ctx.username, act, "purchase_orders", pid, f"{num} saved, total {po_total(c, pid):.2f}")
        return {"id": pid, "number": num}


def approve_po(c, ctx, po_id):
    require(ctx, "clerk")
    with tx(c):
        po = _get(c, "purchase_orders", po_id, "Purchase order")
        if po["status"] != "draft":
            raise BizError(f"{po['number']} is {po['status']}; only drafts can be approved.")
        total = po_total(c, po_id)
        limit = setting(c, "po_approval_limit")
        if total > limit and ROLE_RANK[ctx.role] < ROLE_RANK["manager"]:
            raise Forbidden(f"{po['number']} total {total:,.2f} exceeds the clerk approval limit of {limit:,.2f}. "
                            "A manager must approve it.")
        c.execute("UPDATE purchase_orders SET status='approved', approved_by=? WHERE id=?", (ctx.username, po_id))
        audit(c, ctx.username, "approve", "purchase_orders", po_id, f"{po['number']} approved ({total:.2f})")
        return {"ok": True}


def cancel_po(c, ctx, po_id):
    require(ctx, "manager")
    with tx(c):
        po = _get(c, "purchase_orders", po_id, "Purchase order")
        if po["status"] in ("cancelled", "closed", "received"):
            raise BizError(f"{po['number']} is already {po['status']}.")
        if scalar(c, "SELECT COUNT(*) FROM receipts WHERE po_id=?", po_id):
            raise BizError(f"{po['number']} has receipts and cannot be cancelled. Short-close it instead.")
        c.execute("UPDATE purchase_orders SET status='cancelled' WHERE id=?", (po_id,))
        audit(c, ctx.username, "cancel", "purchase_orders", po_id, f"{po['number']} cancelled")
        return {"ok": True}


def close_po(c, ctx, po_id):
    """Short-close a partially received PO: remaining quantity is no longer expected."""
    require(ctx, "manager")
    with tx(c):
        po = _get(c, "purchase_orders", po_id, "Purchase order")
        if po["status"] not in ("partial", "received", "approved"):
            raise BizError(f"{po['number']} is {po['status']} and cannot be closed.")
        c.execute("UPDATE purchase_orders SET status='closed' WHERE id=?", (po_id,))
        audit(c, ctx.username, "close", "purchase_orders", po_id, f"{po['number']} short-closed")
        return {"ok": True}


def receive_po(c, ctx, po_id, lines, date_=None, location_id=None, notes=None):
    require(ctx, "clerk")
    with tx(c):
        po = _get(c, "purchase_orders", po_id, "Purchase order")
        if po["status"] not in ("approved", "partial"):
            raise BizError(f"{po['number']} is {po['status']}; only approved orders can be received.")
        d = _date(date_, "Receipt date", today())
        if d < po["order_date"]:
            raise BizError("Receipt date cannot be before the order date.")
        loc = int(location_id or po["location_id"])
        _get(c, "locations", loc, "Location")
        tol = setting(c, "over_receipt_tolerance_pct") / 100.0
        todo = [(ln, _num(ln.get("qty") or 0, "Receive quantity", positive=True)) for ln in (lines or [])]
        todo = [(ln, q) for ln, q in todo if q > EPS]
        if not todo:
            raise BizError("Enter a quantity to receive on at least one line.")
        num = next_number(c, "receipts")
        rid = c.execute("INSERT INTO receipts(number,po_id,date,location_id,notes,created_by) VALUES(?,?,?,?,?,?)",
                        (num, po_id, d, loc, notes, ctx.username)).lastrowid
        for ln, q in todo:
            pl = one(c, "SELECT * FROM po_lines WHERE id=? AND po_id=?", int(ln["po_line_id"]), po_id)
            if not pl:
                raise BizError("Receipt line does not belong to this purchase order.")
            if pl["qty_received"] + q > pl["qty"] * (1 + tol) + EPS:
                sku = scalar(c, "SELECT sku FROM items WHERE id=?", pl["item_id"])
                raise BizError(f"{sku}: receiving {q:g} would exceed ordered {pl['qty']:g} "
                               f"(already received {pl['qty_received']:g}, tolerance {tol*100:g}%).")
            c.execute("INSERT INTO receipt_lines(receipt_id,po_line_id,item_id,qty,unit_cost) VALUES(?,?,?,?,?)",
                      (rid, pl["id"], pl["item_id"], q, pl["unit_cost"]))
            c.execute("UPDATE po_lines SET qty_received=ROUND(qty_received+?,4) WHERE id=?", (q, pl["id"]))
            itype = scalar(c, "SELECT type FROM items WHERE id=?", pl["item_id"])
            if itype != "service":
                post_inventory(c, ctx, pl["item_id"], loc, q, "receipt", pl["unit_cost"], "receipt", rid,
                               f"{po['number']} / {num}", _ts(d))
        _refresh_po_status(c, po_id)
        audit(c, ctx.username, "receive", "purchase_orders", po_id, f"{num} received against {po['number']}")
        return {"id": rid, "number": num}


def _refresh_po_status(c, po_id):
    open_ = scalar(c, "SELECT COUNT(*) FROM po_lines WHERE po_id=? AND qty_received < qty - 1e-9", po_id)
    any_ = scalar(c, "SELECT COUNT(*) FROM po_lines WHERE po_id=? AND qty_received > 0", po_id)
    st = "received" if not open_ else ("partial" if any_ else "approved")
    c.execute("UPDATE purchase_orders SET status=? WHERE id=? AND status IN ('approved','partial')", (st, po_id))


def create_bill(c, ctx, po_id, supplier_ref="", date_=None, tax=0, notes=None):
    """Bill the received-but-unbilled quantity of a PO (three-way match)."""
    require(ctx, "clerk")
    with tx(c):
        po = _get(c, "purchase_orders", po_id, "Purchase order")
        if po["status"] in ("draft", "cancelled"):
            raise BizError(f"{po['number']} is {po['status']} and cannot be billed.")
        three_way = setting(c, "require_receipt_before_bill")
        basis = "qty_received" if three_way else "qty"
        lines = all_(c, f"SELECT *, ROUND({basis}-qty_billed,4) AS billable FROM po_lines "
                        f"WHERE po_id=? AND {basis}-qty_billed > 1e-9", po_id)
        if not lines:
            raise BizError(f"Nothing to bill on {po['number']}: all received quantity is already billed.")
        sup = _get(c, "suppliers", po["supplier_id"])
        d = _date(date_, "Bill date", today())
        subtotal = money(sum(l["billable"] * l["unit_cost"] for l in lines))
        tax = money(_num(tax or 0, "Tax", positive=True))
        num = next_number(c, "bills")
        bid = c.execute("INSERT INTO bills(number,supplier_ref,supplier_id,po_id,date,due_date,subtotal,tax,total,notes)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (num, supplier_ref, sup["id"], po_id, d, _add_days(d, sup["terms_days"]), subtotal, tax,
                         money(subtotal + tax), notes)).lastrowid
        for l in lines:
            c.execute("INSERT INTO bill_lines(bill_id,po_line_id,item_id,qty,unit_cost,amount) VALUES(?,?,?,?,?,?)",
                      (bid, l["id"], l["item_id"], l["billable"], l["unit_cost"], money(l["billable"] * l["unit_cost"])))
            c.execute("UPDATE po_lines SET qty_billed=ROUND(qty_billed+?,4) WHERE id=?", (l["billable"], l["id"]))
        audit(c, ctx.username, "create", "bills", bid, f"{num} for {po['number']} total {subtotal + tax:.2f}")
        return {"id": bid, "number": num}


def pay_bill(c, ctx, bill_id, amount, date_=None, method="ACH", reference=""):
    require(ctx, "clerk")
    with tx(c):
        b = _get(c, "bills", bill_id, "Bill")
        if b["status"] in ("paid", "void"):
            raise BizError(f"{b['number']} is {b['status']}.")
        amt = money(_num(amount, "Amount", positive=True, allow_zero=False))
        bal = money(b["total"] - b["amount_paid"])
        if amt > bal + 0.001:
            raise BizError(f"Payment {amt:,.2f} exceeds the open balance of {bal:,.2f}.")
        d = _date(date_, "Payment date", today())
        if d < b["date"]:
            raise BizError("Payment date cannot be before the bill date.")
        num = next_number(c, "supplier_payments")
        pid = c.execute("INSERT INTO supplier_payments(number,bill_id,date,amount,method,reference) VALUES(?,?,?,?,?,?)",
                        (num, bill_id, d, amt, method, reference)).lastrowid
        paid = money(b["amount_paid"] + amt)
        c.execute("UPDATE bills SET amount_paid=?, status=? WHERE id=?",
                  (paid, "paid" if paid >= b["total"] - 0.001 else "partial", bill_id))
        audit(c, ctx.username, "pay", "bills", bill_id, f"{num} paid {amt:.2f} on {b['number']}")
        return {"id": pid, "number": num}


def void_bill(c, ctx, bill_id):
    require(ctx, "manager")
    with tx(c):
        b = _get(c, "bills", bill_id, "Bill")
        if b["status"] == "void":
            raise BizError(f"{b['number']} is already void.")
        if scalar(c, "SELECT COUNT(*) FROM supplier_payments WHERE bill_id=?", bill_id):
            raise BizError(f"{b['number']} has payments recorded and cannot be voided.")
        for l in all_(c, "SELECT * FROM bill_lines WHERE bill_id=?", bill_id):
            if l["po_line_id"]:
                c.execute("UPDATE po_lines SET qty_billed=MAX(0,ROUND(qty_billed-?,4)) WHERE id=?",
                          (l["qty"], l["po_line_id"]))
        c.execute("UPDATE bills SET status='void' WHERE id=?", (bill_id,))
        audit(c, ctx.username, "void", "bills", bill_id, f"{b['number']} voided")
        return {"ok": True}


# ---------------------------------------------------------------- sales
def customer_exposure(c, customer_id, exclude_so=None):
    ar = scalar(c, "SELECT COALESCE(SUM(total-amount_paid),0) FROM invoices WHERE customer_id=? "
                   "AND status IN ('open','partial')", customer_id)
    oo = scalar(c, "SELECT COALESCE(SUM((l.qty-l.qty_invoiced)*l.unit_price*(1-l.discount_pct/100.0)*(1+o.tax_rate)),0) "
                   "FROM so_lines l JOIN sales_orders o ON o.id=l.so_id WHERE o.customer_id=? "
                   "AND o.status IN ('confirmed','partial','shipped') AND o.id<>?", customer_id, exclude_so or 0)
    return money(ar), money(oo)


def so_total(c, so_id):
    sub = scalar(c, "SELECT COALESCE(SUM(qty*unit_price*(1-discount_pct/100.0)),0) FROM so_lines WHERE so_id=?", so_id)
    rate = scalar(c, "SELECT tax_rate FROM sales_orders WHERE id=?", so_id) or 0
    return money(sub), money(sub * rate), money(money(sub) + money(sub * rate))


def save_so(c, ctx, data):
    require(ctx, "clerk")
    with tx(c):
        cus = _get(c, "customers", int(data.get("customer_id") or 0), "Customer")
        if not cus["active"]:
            raise BizError(f"Customer {cus['code']} is inactive.")
        loc_id = int(data.get("location_id") or scalar(c, "SELECT id FROM locations ORDER BY id LIMIT 1"))
        _get(c, "locations", loc_id, "Location")
        od = _date(data.get("order_date"), "Order date", today())
        sb = _date(data.get("ship_by"), "Ship-by date", _add_days(od, 7))
        if sb < od:
            raise BizError("Ship-by date cannot be before the order date.")
        lines = _clean_lines(c, data.get("lines"), "unit_price", "unit price")
        rate = 0.0 if cus["tax_exempt"] else (
            _num(data["tax_rate"], "Tax rate", True) if data.get("tax_rate") not in (None, "")
            else setting(c, "default_tax_rate"))
        if rate >= 1:
            raise BizError("Tax rate must be a fraction below 1 (e.g. 0.07).")
        if data.get("id"):
            so = _get(c, "sales_orders", int(data["id"]), "Sales order")
            if so["status"] != "draft":
                raise BizError(f"{so['number']} is {so['status']}; only draft orders can be edited.")
            c.execute("UPDATE sales_orders SET customer_id=?,order_date=?,ship_by=?,customer_po=?,location_id=?,"
                      "tax_rate=?,notes=? WHERE id=?",
                      (cus["id"], od, sb, data.get("customer_po"), loc_id, rate, data.get("notes"), so["id"]))
            c.execute("DELETE FROM so_lines WHERE so_id=?", (so["id"],))
            sid, num, act = so["id"], so["number"], "update"
        else:
            num = next_number(c, "sales_orders")
            sid = c.execute("INSERT INTO sales_orders(number,customer_id,status,order_date,ship_by,customer_po,"
                            "location_id,tax_rate,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (num, cus["id"], "draft", od, sb, data.get("customer_po"), loc_id, rate,
                             data.get("notes"), ctx.username)).lastrowid
            act = "create"
        for ln in lines:
            c.execute("INSERT INTO so_lines(so_id,item_id,qty,unit_price,discount_pct) VALUES(?,?,?,?,?)",
                      (sid, ln["item_id"], ln["qty"], ln["unit_price"], ln["discount_pct"]))
        audit(c, ctx.username, act, "sales_orders", sid, f"{num} saved, total {so_total(c, sid)[2]:.2f}")
        return {"id": sid, "number": num}


def confirm_so(c, ctx, so_id, override_credit=False):
    require(ctx, "clerk")
    with tx(c):
        so = _get(c, "sales_orders", so_id, "Sales order")
        if so["status"] != "draft":
            raise BizError(f"{so['number']} is {so['status']}; only drafts can be confirmed.")
        cus = _get(c, "customers", so["customer_id"])
        if not cus["active"]:
            raise BizError(f"Customer {cus['code']} is inactive.")
        total = so_total(c, so_id)[2]
        if setting(c, "enforce_credit_limit") and cus["credit_limit"] > 0:
            ar, oo = customer_exposure(c, cus["id"], so_id)
            if ar + oo + total > cus["credit_limit"] + 0.001:
                if override_credit and ROLE_RANK[ctx.role] >= ROLE_RANK["manager"]:
                    audit(c, ctx.username, "credit_override", "sales_orders", so_id,
                          f"Credit limit {cus['credit_limit']:.2f} overridden (exposure {ar + oo + total:.2f})")
                else:
                    raise BizError(f"Credit limit exceeded for {cus['name']}: open AR {ar:,.2f} + open orders "
                                   f"{oo:,.2f} + this order {total:,.2f} > limit {cus['credit_limit']:,.2f}. "
                                   "A manager can override.")
        c.execute("UPDATE sales_orders SET status='confirmed' WHERE id=?", (so_id,))
        audit(c, ctx.username, "confirm", "sales_orders", so_id, f"{so['number']} confirmed ({total:.2f})")
        return {"ok": True}


def cancel_so(c, ctx, so_id):
    require(ctx, "manager")
    with tx(c):
        so = _get(c, "sales_orders", so_id, "Sales order")
        if so["status"] in ("cancelled", "closed", "shipped"):
            raise BizError(f"{so['number']} is already {so['status']}.")
        if scalar(c, "SELECT COUNT(*) FROM shipments WHERE so_id=?", so_id):
            raise BizError(f"{so['number']} has shipments and cannot be cancelled. Close it instead.")
        c.execute("UPDATE sales_orders SET status='cancelled' WHERE id=?", (so_id,))
        audit(c, ctx.username, "cancel", "sales_orders", so_id, f"{so['number']} cancelled")
        return {"ok": True}


def close_so(c, ctx, so_id):
    require(ctx, "manager")
    with tx(c):
        so = _get(c, "sales_orders", so_id, "Sales order")
        if so["status"] not in ("partial", "shipped", "confirmed"):
            raise BizError(f"{so['number']} is {so['status']} and cannot be closed.")
        if scalar(c, "SELECT COUNT(*) FROM so_lines WHERE so_id=? AND qty_invoiced < qty_shipped - 1e-9", so_id):
            raise BizError(f"{so['number']} has shipped quantity that is not yet invoiced.")
        c.execute("UPDATE sales_orders SET status='closed' WHERE id=?", (so_id,))
        audit(c, ctx.username, "close", "sales_orders", so_id, f"{so['number']} closed")
        return {"ok": True}


def ship_so(c, ctx, so_id, lines, date_=None, location_id=None, carrier="", tracking="", notes=None):
    require(ctx, "clerk")
    with tx(c):
        so = _get(c, "sales_orders", so_id, "Sales order")
        if so["status"] not in ("confirmed", "partial"):
            raise BizError(f"{so['number']} is {so['status']}; only confirmed orders can ship.")
        d = _date(date_, "Ship date", today())
        if d < so["order_date"]:
            raise BizError("Ship date cannot be before the order date.")
        loc = int(location_id or so["location_id"])
        _get(c, "locations", loc, "Location")
        todo = [(ln, _num(ln.get("qty") or 0, "Ship quantity", positive=True)) for ln in (lines or [])]
        todo = [(ln, q) for ln, q in todo if q > EPS]
        if not todo:
            raise BizError("Enter a quantity to ship on at least one line.")
        num = next_number(c, "shipments")
        sid = c.execute("INSERT INTO shipments(number,so_id,date,location_id,carrier,tracking,notes,created_by)"
                        " VALUES(?,?,?,?,?,?,?,?)", (num, so_id, d, loc, carrier, tracking, notes, ctx.username)).lastrowid
        for ln, q in todo:
            sl = one(c, "SELECT * FROM so_lines WHERE id=? AND so_id=?", int(ln["so_line_id"]), so_id)
            if not sl:
                raise BizError("Shipment line does not belong to this sales order.")
            if sl["qty_shipped"] + q > sl["qty"] + EPS:
                sku = scalar(c, "SELECT sku FROM items WHERE id=?", sl["item_id"])
                raise BizError(f"{sku}: shipping {q:g} exceeds the remaining {sl['qty'] - sl['qty_shipped']:g}.")
            itype = scalar(c, "SELECT type FROM items WHERE id=?", sl["item_id"])
            uc = 0.0
            if itype != "service":
                r = post_inventory(c, ctx, sl["item_id"], loc, -q, "shipment", None, "shipment", sid,
                                   f"{so['number']} / {num}", _ts(d))
                uc = r["unit_cost"]
            c.execute("INSERT INTO shipment_lines(shipment_id,so_line_id,item_id,qty,unit_cost) VALUES(?,?,?,?,?)",
                      (sid, sl["id"], sl["item_id"], q, round(uc, 6)))
            c.execute("UPDATE so_lines SET qty_shipped=ROUND(qty_shipped+?,4) WHERE id=?", (q, sl["id"]))
        _refresh_so_status(c, so_id)
        audit(c, ctx.username, "ship", "sales_orders", so_id, f"{num} shipped against {so['number']}")
        result = {"id": sid, "number": num}
        if setting(c, "auto_invoice_on_ship"):
            result["invoice"] = invoice_shipment(c, ctx, sid, d)
        return result


def _refresh_so_status(c, so_id):
    so = one(c, "SELECT status FROM sales_orders WHERE id=?", so_id)
    if so["status"] not in ("confirmed", "partial", "shipped"):
        return
    unshipped = scalar(c, "SELECT COUNT(*) FROM so_lines WHERE so_id=? AND qty_shipped < qty - 1e-9", so_id)
    shipped_any = scalar(c, "SELECT COUNT(*) FROM so_lines WHERE so_id=? AND qty_shipped > 0", so_id)
    uninvoiced = scalar(c, "SELECT COUNT(*) FROM so_lines WHERE so_id=? AND qty_invoiced < qty - 1e-9", so_id)
    if not unshipped and not uninvoiced:
        st = "closed"
    elif not unshipped:
        st = "shipped"
    else:
        st = "partial" if shipped_any else "confirmed"
    c.execute("UPDATE sales_orders SET status=? WHERE id=?", (st, so_id))


def invoice_shipment(c, ctx, shipment_id, date_=None, notes=None):
    require(ctx, "clerk")
    with tx(c):
        sh = _get(c, "shipments", shipment_id, "Shipment")
        if scalar(c, "SELECT COUNT(*) FROM invoices WHERE shipment_id=? AND status<>'void'", shipment_id):
            raise BizError(f"{sh['number']} is already invoiced.")
        so = _get(c, "sales_orders", sh["so_id"])
        cus = _get(c, "customers", so["customer_id"])
        d = _date(date_, "Invoice date", today())
        if d < sh["date"]:
            raise BizError("Invoice date cannot be before the ship date.")
        lines = all_(c, "SELECT sl.*, l.unit_price, l.discount_pct, i.sku, i.name FROM shipment_lines sl "
                        "JOIN so_lines l ON l.id=sl.so_line_id JOIN items i ON i.id=sl.item_id WHERE sl.shipment_id=?",
                     shipment_id)
        subtotal = 0.0
        prepared = []
        for l in lines:
            price = round(l["unit_price"] * (1 - l["discount_pct"] / 100.0), 4)
            amt = money(l["qty"] * price)
            subtotal += amt
            prepared.append((l, price, amt))
        subtotal = money(subtotal)
        tax = money(subtotal * so["tax_rate"])
        num = next_number(c, "invoices")
        iid = c.execute("INSERT INTO invoices(number,customer_id,so_id,shipment_id,date,due_date,subtotal,tax,total,notes)"
                        " VALUES(?,?,?,?,?,?,?,?,?,?)",
                        (num, cus["id"], so["id"], shipment_id, d, _add_days(d, cus["terms_days"]), subtotal, tax,
                         money(subtotal + tax), notes)).lastrowid
        for l, price, amt in prepared:
            c.execute("INSERT INTO invoice_lines(invoice_id,so_line_id,item_id,description,qty,unit_price,amount)"
                      " VALUES(?,?,?,?,?,?,?)", (iid, l["so_line_id"], l["item_id"], l["name"],
                                                 l["qty"], price, amt))
            c.execute("UPDATE so_lines SET qty_invoiced=ROUND(qty_invoiced+?,4) WHERE id=?", (l["qty"], l["so_line_id"]))
        _refresh_so_status(c, so["id"])
        audit(c, ctx.username, "create", "invoices", iid, f"{num} for {sh['number']} total {subtotal + tax:.2f}")
        return {"id": iid, "number": num}


def record_payment(c, ctx, invoice_id, amount, date_=None, method="Check", reference=""):
    require(ctx, "clerk")
    with tx(c):
        v = _get(c, "invoices", invoice_id, "Invoice")
        if v["status"] in ("paid", "void"):
            raise BizError(f"{v['number']} is {v['status']}.")
        amt = money(_num(amount, "Amount", positive=True, allow_zero=False))
        bal = money(v["total"] - v["amount_paid"])
        if amt > bal + 0.001:
            raise BizError(f"Payment {amt:,.2f} exceeds the open balance of {bal:,.2f}.")
        d = _date(date_, "Payment date", today())
        if d < v["date"]:
            raise BizError("Payment date cannot be before the invoice date.")
        num = next_number(c, "payments")
        pid = c.execute("INSERT INTO payments(number,invoice_id,date,amount,method,reference) VALUES(?,?,?,?,?,?)",
                        (num, invoice_id, d, amt, method, reference)).lastrowid
        paid = money(v["amount_paid"] + amt)
        c.execute("UPDATE invoices SET amount_paid=?, status=? WHERE id=?",
                  (paid, "paid" if paid >= v["total"] - 0.001 else "partial", invoice_id))
        audit(c, ctx.username, "pay", "invoices", invoice_id, f"{num} received {amt:.2f} on {v['number']}")
        return {"id": pid, "number": num}


def void_invoice(c, ctx, invoice_id):
    require(ctx, "manager")
    with tx(c):
        v = _get(c, "invoices", invoice_id, "Invoice")
        if v["status"] == "void":
            raise BizError(f"{v['number']} is already void.")
        if scalar(c, "SELECT COUNT(*) FROM payments WHERE invoice_id=?", invoice_id):
            raise BizError(f"{v['number']} has payments recorded and cannot be voided.")
        for l in all_(c, "SELECT * FROM invoice_lines WHERE invoice_id=?", invoice_id):
            if l["so_line_id"]:
                c.execute("UPDATE so_lines SET qty_invoiced=MAX(0,ROUND(qty_invoiced-?,4)) WHERE id=?",
                          (l["qty"], l["so_line_id"]))
        c.execute("UPDATE invoices SET status='void' WHERE id=?", (invoice_id,))
        so = one(c, "SELECT status FROM sales_orders WHERE id=?", v["so_id"])
        if so["status"] == "closed":
            c.execute("UPDATE sales_orders SET status='shipped' WHERE id=?", (v["so_id"],))
        _refresh_so_status(c, v["so_id"])
        audit(c, ctx.username, "void", "invoices", invoice_id, f"{v['number']} voided")
        return {"ok": True}


# ---------------------------------------------------------------- manufacturing
def save_bom(c, ctx, data):
    require(ctx, "manager")
    with tx(c):
        item = _get(c, "items", int(data.get("item_id") or 0), "Item")
        if item["type"] not in ("finished", "component"):
            raise BizError("Bills of materials can only be defined for finished goods or components.")
        version = (data.get("version") or "A").strip()
        labor = _num(data.get("labor_cost") or 0, "Labor cost", True)
        ovh = _num(data.get("overhead_cost") or 0, "Overhead cost", True)
        lines = data.get("lines") or []
        if not lines:
            raise BizError("A BOM needs at least one component.")
        seen = set()
        clean = []
        for i, ln in enumerate(lines, 1):
            comp = _get(c, "items", int(ln.get("component_id") or 0), f"Line {i} component")
            if comp["id"] == item["id"]:
                raise BizError("An item cannot be a component of itself.")
            if comp["type"] == "service":
                raise BizError(f"Line {i}: service items cannot be BOM components.")
            if comp["id"] in seen:
                raise BizError(f"Line {i}: {comp['sku']} is listed twice.")
            seen.add(comp["id"])
            sp = _num(ln.get("scrap_pct") or 0, f"Line {i} scrap %", True)
            if sp >= 100:
                raise BizError(f"Line {i}: scrap % must be below 100.")
            clean.append((comp["id"], _num(ln.get("qty_per"), f"Line {i} qty per", True, False), sp))
        _check_bom_cycle(c, item["id"], [x[0] for x in clean])
        if data.get("id"):
            b = _get(c, "boms", int(data["id"]), "BOM")
            if scalar(c, "SELECT COUNT(*) FROM production_orders WHERE bom_id=? AND status='released'", b["id"]):
                raise BizError("This BOM is used by a released production order; create a new version instead.")
            c.execute("UPDATE boms SET item_id=?,version=?,labor_cost=?,overhead_cost=?,notes=?,active=? WHERE id=?",
                      (item["id"], version, labor, ovh, data.get("notes"), 1 if data.get("active", 1) else 0, b["id"]))
            c.execute("DELETE FROM bom_lines WHERE bom_id=?", (b["id"],))
            bid, act = b["id"], "update"
        else:
            if scalar(c, "SELECT COUNT(*) FROM boms WHERE item_id=? AND version=?", item["id"], version):
                raise BizError(f"{item['sku']} already has BOM version {version}.")
            bid = c.execute("INSERT INTO boms(item_id,version,labor_cost,overhead_cost,notes,active) VALUES(?,?,?,?,?,?)",
                            (item["id"], version, labor, ovh, data.get("notes"),
                             1 if data.get("active", 1) else 0)).lastrowid
            act = "create"
        for comp_id, q, sp in clean:
            c.execute("INSERT INTO bom_lines(bom_id,component_id,qty_per,scrap_pct) VALUES(?,?,?,?)", (bid, comp_id, q, sp))
        if data.get("active", 1):
            c.execute("UPDATE boms SET active=0 WHERE item_id=? AND id<>?", (item["id"], bid))
        audit(c, ctx.username, act, "boms", bid, f"BOM {item['sku']} rev {version}")
        return {"id": bid}


def _check_bom_cycle(c, parent_id, comp_ids):
    """Reject a BOM if any component (transitively) contains the parent."""
    stack, seen = list(comp_ids), set()
    while stack:
        cid = stack.pop()
        if cid == parent_id:
            raise BizError("This BOM would create a circular reference (a component contains the parent item).")
        if cid in seen:
            continue
        seen.add(cid)
        stack += [r["component_id"] for r in all_(c, "SELECT l.component_id FROM bom_lines l JOIN boms b ON b.id=l.bom_id"
                                                      " WHERE b.item_id=? AND b.active=1", cid)]


def requirements(c, bom_id, qty):
    out = []
    for l in all_(c, "SELECT l.*, i.sku, i.name, i.uom, i.avg_cost FROM bom_lines l JOIN items i ON i.id=l.component_id "
                     "WHERE l.bom_id=? ORDER BY i.sku", bom_id):
        need = qty4(l["qty_per"] * qty * (1 + l["scrap_pct"] / 100.0))
        out.append({**l, "required": need})
    return out


def save_mo(c, ctx, data):
    require(ctx, "clerk")
    with tx(c):
        item = _get(c, "items", int(data.get("item_id") or 0), "Item")
        bom_id = data.get("bom_id") or scalar(c, "SELECT id FROM boms WHERE item_id=? AND active=1", item["id"])
        if not bom_id:
            raise BizError(f"{item['sku']} has no active bill of materials.")
        bom = _get(c, "boms", int(bom_id), "BOM")
        if bom["item_id"] != item["id"]:
            raise BizError("Selected BOM does not belong to this item.")
        q = _num(data.get("qty"), "Quantity", True, False)
        loc_id = int(data.get("location_id") or scalar(c, "SELECT id FROM locations ORDER BY id LIMIT 1"))
        _get(c, "locations", loc_id, "Location")
        sd = _date(data.get("start_date"), "Start date", today())
        dd = _date(data.get("due_date"), "Due date", _add_days(sd, 5))
        if dd < sd:
            raise BizError("Due date cannot be before the start date.")
        if data.get("id"):
            mo = _get(c, "production_orders", int(data["id"]), "Production order")
            if mo["status"] != "planned":
                raise BizError(f"{mo['number']} is {mo['status']}; only planned orders can be edited.")
            c.execute("UPDATE production_orders SET item_id=?,bom_id=?,qty=?,location_id=?,start_date=?,due_date=?,notes=?"
                      " WHERE id=?", (item["id"], bom["id"], q, loc_id, sd, dd, data.get("notes"), mo["id"]))
            mid, num, act = mo["id"], mo["number"], "update"
        else:
            num = next_number(c, "production_orders")
            mid = c.execute("INSERT INTO production_orders(number,item_id,bom_id,qty,status,location_id,start_date,"
                            "due_date,notes,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
                            (num, item["id"], bom["id"], q, "planned", loc_id, sd, dd, data.get("notes"),
                             ctx.username)).lastrowid
            act = "create"
        audit(c, ctx.username, act, "production_orders", mid, f"{num}: {q:g} x {item['sku']}")
        return {"id": mid, "number": num}


def release_mo(c, ctx, mo_id):
    require(ctx, "clerk")
    with tx(c):
        mo = _get(c, "production_orders", mo_id, "Production order")
        if mo["status"] != "planned":
            raise BizError(f"{mo['number']} is {mo['status']}; only planned orders can be released.")
        c.execute("UPDATE production_orders SET status='released' WHERE id=?", (mo_id,))
        audit(c, ctx.username, "release", "production_orders", mo_id, f"{mo['number']} released")
        return {"ok": True}


def complete_mo(c, ctx, mo_id, qty=None, date_=None):
    """Backflush components and receive finished output at actual cost."""
    require(ctx, "clerk")
    with tx(c):
        mo = _get(c, "production_orders", mo_id, "Production order")
        if mo["status"] != "released":
            raise BizError(f"{mo['number']} is {mo['status']}; release it before reporting output.")
        remaining = qty4(mo["qty"] - mo["qty_completed"])
        q = remaining if qty in (None, "") else _num(qty, "Completed quantity", True, False)
        if q > remaining + EPS:
            raise BizError(f"Completing {q:g} exceeds the remaining {remaining:g}.")
        d = _date(date_, "Completion date", today())
        ts = _ts(d)
        bom = _get(c, "boms", mo["bom_id"])
        cost = 0.0
        short = []
        reqs = requirements(c, bom["id"], q)
        if not setting(c, "allow_negative_stock"):
            for r in reqs:
                have = scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", r["component_id"],
                              mo["location_id"]) or 0
                if have + EPS < r["required"]:
                    short.append(f"{r['sku']} (need {r['required']:g}, have {have:g})")
            if short:
                raise BizError("Insufficient components: " + "; ".join(short))
        for r in reqs:
            res = post_inventory(c, ctx, r["component_id"], mo["location_id"], -r["required"], "issue", None,
                                 "production", mo_id, mo["number"], ts)
            cost += r["required"] * res["unit_cost"]
        cost += q * (bom["labor_cost"] + bom["overhead_cost"])
        post_inventory(c, ctx, mo["item_id"], mo["location_id"], q, "output", cost / q, "production", mo_id,
                       mo["number"], ts)
        done = qty4(mo["qty_completed"] + q)
        status = "completed" if done >= mo["qty"] - EPS else "released"
        c.execute("UPDATE production_orders SET qty_completed=?, status=?, actual_cost=ROUND(actual_cost+?,2), "
                  "completed_date=CASE WHEN ?='completed' THEN ? ELSE completed_date END WHERE id=?",
                  (done, status, cost, status, d, mo_id))
        audit(c, ctx.username, "complete", "production_orders", mo_id,
              f"{mo['number']}: {q:g} completed, cost {cost:.2f}")
        return {"completed": q, "cost": money(cost), "status": status}


def cancel_mo(c, ctx, mo_id):
    require(ctx, "manager")
    with tx(c):
        mo = _get(c, "production_orders", mo_id, "Production order")
        if mo["status"] in ("completed", "cancelled"):
            raise BizError(f"{mo['number']} is already {mo['status']}.")
        if mo["qty_completed"] > 0:
            # partial output stays in stock; the order is closed short
            c.execute("UPDATE production_orders SET status='completed', completed_date=? WHERE id=?", (today(), mo_id))
            audit(c, ctx.username, "close", "production_orders", mo_id, f"{mo['number']} closed short")
        else:
            c.execute("UPDATE production_orders SET status='cancelled' WHERE id=?", (mo_id,))
            audit(c, ctx.username, "cancel", "production_orders", mo_id, f"{mo['number']} cancelled")
        return {"ok": True}


# ---------------------------------------------------------------- assets
def add_asset_event(c, ctx, asset_id, type_, description="", cost=0, date_=None, status=None):
    require(ctx, "clerk")
    with tx(c):
        a = _get(c, "assets", asset_id, "Asset")
        d = _date(date_, "Date", today())
        c.execute("INSERT INTO asset_events(asset_id,date,type,description,cost,username) VALUES(?,?,?,?,?,?)",
                  (asset_id, d, type_, description, money(_num(cost or 0, "Cost", True)), ctx.username))
        if status:
            c.execute("UPDATE assets SET status=? WHERE id=?", (status, asset_id))
        audit(c, ctx.username, "event", "assets", asset_id, f"{a['tag']}: {type_} {description}")
        return {"ok": True}


# ---------------------------------------------------------------- planning
def reorder_suggestions(c):
    rows = all_(c, "SELECT * FROM v_items WHERE active=1 AND type<>'service' AND reorder_point>0")
    reqs = {}
    for r in all_(c, "SELECT m.bom_id, m.qty-m.qty_completed AS rem FROM production_orders m "
                     "WHERE m.status IN ('planned','released')"):
        for q in requirements(c, r["bom_id"], r["rem"]):
            reqs[q["component_id"]] = reqs.get(q["component_id"], 0) + q["required"]
    out = []
    for r in rows:
        mfg = reqs.get(r["id"], 0)
        available = r["on_hand"] + r["on_order"] - r["committed"] - mfg
        if available < r["reorder_point"] - EPS:
            shortfall = r["reorder_point"] - available
            qty = max(r["reorder_qty"], shortfall)
            out.append({"item_id": r["id"], "sku": r["sku"], "name": r["name"], "type": r["type"],
                        "on_hand": r["on_hand"], "on_order": r["on_order"], "committed": r["committed"],
                        "mfg_demand": qty4(mfg), "available": qty4(available), "reorder_point": r["reorder_point"],
                        "suggested_qty": qty4(qty), "supplier_id": r["preferred_supplier_id"],
                        "supplier_code": r["supplier_code"], "unit_cost": r["avg_cost"] or r["std_cost"],
                        "action": "make" if r["type"] == "finished" and
                        scalar(c, "SELECT id FROM boms WHERE item_id=? AND active=1", r["id"]) else "buy"})
    return out


def create_pos_from_suggestions(c, ctx, item_ids=None):
    require(ctx, "clerk")
    with tx(c):
        sugg = [s for s in reorder_suggestions(c) if s["action"] == "buy" and s["supplier_id"]
                and (not item_ids or s["item_id"] in set(map(int, item_ids)))]
        by_sup = {}
        for s in sugg:
            by_sup.setdefault(s["supplier_id"], []).append(s)
        created = []
        for sup_id, lines in by_sup.items():
            created.append(save_po(c, ctx, {"supplier_id": sup_id, "notes": "Generated from reorder suggestions",
                                            "lines": [{"item_id": s["item_id"], "qty": s["suggested_qty"],
                                                       "unit_cost": s["unit_cost"]} for s in lines]}))
        if not created:
            raise BizError("No purchasable suggestions with a preferred supplier.")
        return {"created": created}


# ---------------------------------------------------------------- reconciliation
def reconcile(c):
    checks = []

    def add(name, rows, desc):
        checks.append({"name": name, "description": desc, "ok": not rows, "count": len(rows), "rows": rows[:200]})

    add("Stock balance vs ledger", all_(c, """
        SELECT x.item_id, i.sku, l.code AS location, ROUND(x.cached,4) AS cached, ROUND(x.ledger,4) AS ledger FROM (
          SELECT item_id, location_id, SUM(cq) AS cached, SUM(lq) AS ledger FROM (
            SELECT item_id, location_id, qty AS cq, 0 AS lq FROM stock
            UNION ALL SELECT item_id, location_id, 0, qty FROM inventory_txns)
          GROUP BY item_id, location_id) x
        JOIN items i ON i.id=x.item_id JOIN locations l ON l.id=x.location_id
        WHERE ABS(x.cached-x.ledger) > 1e-6"""),
        "Cached on-hand per item/location equals the sum of ledger transactions")
    add("Ledger running balance", all_(c, """
        SELECT t.id, i.sku, t.balance_after, ROUND((SELECT SUM(qty) FROM inventory_txns t2
            WHERE t2.item_id=t.item_id AND t2.location_id=t.location_id AND t2.id<=t.id),4) AS computed
        FROM inventory_txns t JOIN items i ON i.id=t.item_id
        WHERE ABS(t.balance_after - (SELECT SUM(qty) FROM inventory_txns t2
            WHERE t2.item_id=t.item_id AND t2.location_id=t.location_id AND t2.id<=t.id)) > 1e-6"""),
        "Each ledger entry's balance-after matches the cumulative sum")
    add("PO received qty vs receipts", all_(c, """
        SELECT l.id AS po_line_id, p.number, l.qty_received, COALESCE(SUM(r.qty),0) AS receipts
        FROM po_lines l JOIN purchase_orders p ON p.id=l.po_id LEFT JOIN receipt_lines r ON r.po_line_id=l.id
        GROUP BY l.id HAVING ABS(l.qty_received - COALESCE(SUM(r.qty),0)) > 1e-6"""),
        "PO line received quantity equals the sum of receipt lines")
    add("Receipts posted to ledger", all_(c, """
        SELECT r.id, r.number, COALESCE(SUM(rl.qty),0) AS received,
          COALESCE((SELECT SUM(qty) FROM inventory_txns WHERE ref_type='receipt' AND ref_id=r.id),0) AS ledger
        FROM receipts r JOIN receipt_lines rl ON rl.receipt_id=r.id JOIN items i ON i.id=rl.item_id
        WHERE i.type<>'service' GROUP BY r.id
        HAVING ABS(received - ledger) > 1e-6"""),
        "Every stocked receipt line has a matching inventory transaction")
    add("SO shipped qty vs shipments", all_(c, """
        SELECT l.id AS so_line_id, o.number, l.qty_shipped, COALESCE(SUM(s.qty),0) AS shipments
        FROM so_lines l JOIN sales_orders o ON o.id=l.so_id LEFT JOIN shipment_lines s ON s.so_line_id=l.id
        GROUP BY l.id HAVING ABS(l.qty_shipped - COALESCE(SUM(s.qty),0)) > 1e-6"""),
        "SO line shipped quantity equals the sum of shipment lines")
    add("Shipments posted to ledger", all_(c, """
        SELECT s.id, s.number, COALESCE(SUM(sl.qty),0) AS shipped,
          -COALESCE((SELECT SUM(qty) FROM inventory_txns WHERE ref_type='shipment' AND ref_id=s.id),0) AS ledger
        FROM shipments s JOIN shipment_lines sl ON sl.shipment_id=s.id JOIN items i ON i.id=sl.item_id
        WHERE i.type<>'service' GROUP BY s.id HAVING ABS(shipped - ledger) > 1e-6"""),
        "Every stocked shipment line has a matching inventory transaction")
    add("SO invoiced qty vs invoices", all_(c, """
        SELECT l.id AS so_line_id, o.number, l.qty_invoiced, COALESCE(SUM(il.qty),0) AS invoiced
        FROM so_lines l JOIN sales_orders o ON o.id=l.so_id
        LEFT JOIN invoice_lines il ON il.so_line_id=l.id AND il.invoice_id IN (SELECT id FROM invoices WHERE status<>'void')
        GROUP BY l.id HAVING ABS(l.qty_invoiced - COALESCE(SUM(il.qty),0)) > 1e-6"""),
        "SO line invoiced quantity equals the sum of non-void invoice lines")
    add("Invoice totals", all_(c, """
        SELECT v.id, v.number, v.subtotal, v.total, ROUND(COALESCE(SUM(l.amount),0),2) AS lines
        FROM invoices v LEFT JOIN invoice_lines l ON l.invoice_id=v.id GROUP BY v.id
        HAVING ABS(v.subtotal - ROUND(COALESCE(SUM(l.amount),0),2)) > 0.005 OR ABS(v.total - v.subtotal - v.tax) > 0.005"""),
        "Invoice subtotal equals its lines and total equals subtotal + tax")
    add("Invoice payments", all_(c, """
        SELECT v.id, v.number, v.amount_paid, ROUND(COALESCE(SUM(p.amount),0),2) AS payments, v.status
        FROM invoices v LEFT JOIN payments p ON p.invoice_id=v.id GROUP BY v.id
        HAVING ABS(v.amount_paid - ROUND(COALESCE(SUM(p.amount),0),2)) > 0.005
           OR v.amount_paid > v.total + 0.005
           OR (v.status='paid' AND v.amount_paid < v.total - 0.005)"""),
        "Invoice amount paid equals recorded payments and never exceeds the total")
    add("Bill payments", all_(c, """
        SELECT b.id, b.number, b.amount_paid, ROUND(COALESCE(SUM(p.amount),0),2) AS payments
        FROM bills b LEFT JOIN supplier_payments p ON p.bill_id=b.id GROUP BY b.id
        HAVING ABS(b.amount_paid - ROUND(COALESCE(SUM(p.amount),0),2)) > 0.005 OR b.amount_paid > b.total + 0.005"""),
        "Bill amount paid equals supplier payments and never exceeds the total")
    add("PO billed qty vs bills", all_(c, """
        SELECT l.id AS po_line_id, p.number, l.qty_billed, COALESCE(SUM(bl.qty),0) AS billed
        FROM po_lines l JOIN purchase_orders p ON p.id=l.po_id
        LEFT JOIN bill_lines bl ON bl.po_line_id=l.id AND bl.bill_id IN (SELECT id FROM bills WHERE status<>'void')
        GROUP BY l.id HAVING ABS(l.qty_billed - COALESCE(SUM(bl.qty),0)) > 1e-6"""),
        "PO line billed quantity equals non-void bill lines")
    neg = [] if setting(c, "allow_negative_stock") else all_(
        c, "SELECT i.sku, l.code AS location, s.qty FROM stock s JOIN items i ON i.id=s.item_id "
           "JOIN locations l ON l.id=s.location_id WHERE s.qty < -1e-9")
    add("No negative stock", neg, "No location is below zero while negative stock is disallowed")
    add("Foreign keys", [dict(zip(["table", "rowid", "parent", "fkid"], tuple(r)))
                         for r in c.execute("PRAGMA foreign_key_check").fetchall()],
        "All references point to existing records")
    ic = [r[0] for r in c.execute("PRAGMA quick_check").fetchall()]
    add("Database integrity", [] if ic == ["ok"] else [{"message": m} for m in ic], "SQLite structural integrity check")
    return {"ok": all(x["ok"] for x in checks), "checks": checks, "ran_at": now()}


def rebuild_stock(c, ctx):
    """Recompute cached stock and running balances from the immutable ledger."""
    require(ctx, "admin")
    with tx(c):
        before = all_(c, "SELECT * FROM stock")
        c.execute("DELETE FROM stock")
        c.execute("INSERT INTO stock(item_id,location_id,qty) SELECT item_id,location_id,ROUND(SUM(qty),4) "
                  "FROM inventory_txns GROUP BY item_id,location_id")
        c.execute("""UPDATE inventory_txns SET balance_after = ROUND((SELECT SUM(qty) FROM inventory_txns t2
                     WHERE t2.item_id=inventory_txns.item_id AND t2.location_id=inventory_txns.location_id
                     AND t2.id<=inventory_txns.id),4)""")
        audit(c, ctx.username, "rebuild", "stock", None, f"Stock rebuilt from ledger ({len(before)} rows before)")
        return {"ok": True}
