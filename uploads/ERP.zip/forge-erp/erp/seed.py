"""Deterministic synthetic business: 12 months of procure-to-pay, make, and order-to-cash history.

All activity goes through the real service layer, so every ledger, document and balance is
produced by the same rules the application enforces at runtime.
"""
import heapq
import itertools
import random
from datetime import date, timedelta

from . import services as S
from .auth import hash_password
from .db import BizError, all_, one, scalar, tx
from .services import Ctx

SUPPLIERS = [
    ("SUP-STL", "Great Lakes Steel Supply", "Dana Kowalski", "Cleveland", "OH", 30, 6),
    ("SUP-FST", "Midwest Fastener Corp", "Luis Ortega", "Indianapolis", "IN", 30, 4),
    ("SUP-CTG", "Summit Coatings Inc", "Rita Shah", "Akron", "OH", 45, 8),
    ("SUP-ELC", "Voltline Electrical Dist.", "Ben Carter", "Louisville", "KY", 30, 10),
    ("SUP-PKG", "BoxRight Packaging", "Nina Alvarez", "Columbus", "OH", 15, 3),
    ("SUP-ALU", "Tri-State Aluminum", "Grant Fowler", "Pittsburgh", "PA", 30, 9),
    ("SUP-MTR", "Precision Motor Works", "Helen Park", "Grand Rapids", "MI", 60, 14),
    ("SUP-HWD", "Allied Hardware & Casters", "Omar Reyes", "Fort Wayne", "IN", 30, 5),
]

# sku, name, category, type, uom, price, std_cost, reorder_point, reorder_qty, supplier
ITEMS = [
    ("RM-STS16", "Steel sheet 16ga 4x8", "Steel", "raw", "sheet", 0, 58.00, 60, 120, "SUP-STL"),
    ("RM-STT10", "Steel square tube 1in", "Steel", "raw", "ft", 0, 2.15, 1500, 3000, "SUP-STL"),
    ("RM-STA15", "Steel angle 1.5in", "Steel", "raw", "ft", 0, 1.80, 800, 1600, "SUP-STL"),
    ("RM-ALX20", "Aluminum extrusion 20mm", "Aluminum", "raw", "ft", 0, 3.40, 400, 800, "SUP-ALU"),
    ("RM-MDF34", "Maple hardboard top 3/4in", "Wood", "raw", "sheet", 0, 41.00, 30, 60, "SUP-ALU"),
    ("RM-PCBK", "Powder coat, black", "Coatings", "raw", "lb", 0, 6.25, 150, 300, "SUP-CTG"),
    ("RM-PCGY", "Powder coat, industrial gray", "Coatings", "raw", "lb", 0, 6.10, 150, 300, "SUP-CTG"),
    ("RM-BLT8", "Hex bolt M8x25 zinc", "Fasteners", "raw", "ea", 0, 0.09, 4000, 10000, "SUP-FST"),
    ("RM-NUT8", "Hex nut M8 nylon-insert", "Fasteners", "raw", "ea", 0, 0.05, 4000, 10000, "SUP-FST"),
    ("RM-WSH8", "Washer M8 flat", "Fasteners", "raw", "ea", 0, 0.02, 4000, 10000, "SUP-FST"),
    ("RM-CST4", "Caster 4in swivel w/ brake", "Hardware", "raw", "ea", 0, 7.80, 200, 400, "SUP-HWD"),
    ("RM-FOOT", "Leveling foot 3/8-16", "Hardware", "raw", "ea", 0, 1.10, 300, 600, "SUP-HWD"),
    ("RM-HNDL", "Pull handle 6in", "Hardware", "raw", "ea", 0, 2.40, 150, 300, "SUP-HWD"),
    ("RM-SLD18", "Drawer slide 18in pair", "Hardware", "raw", "pr", 0, 9.50, 120, 240, "SUP-HWD"),
    ("RM-CBL18", "Cable 18AWG 3-cond", "Electrical", "raw", "ft", 0, 0.42, 600, 1500, "SUP-ELC"),
    ("RM-SWT1", "Rocker switch 15A", "Electrical", "raw", "ea", 0, 3.20, 80, 200, "SUP-ELC"),
    ("RM-BOXL", "Shipping carton large", "Packaging", "raw", "ea", 0, 6.40, 80, 200, "SUP-PKG"),
    ("RM-BOXM", "Shipping carton medium", "Packaging", "raw", "ea", 0, 3.90, 120, 300, "SUP-PKG"),
    ("RM-FOAM", "Foam corner set", "Packaging", "raw", "set", 0, 1.35, 150, 400, "SUP-PKG"),
    ("CP-MTR25", "Motor 1/4 HP 115V", "Electrical", "component", "ea", 0, 64.00, 25, 50, "SUP-MTR"),
    ("CP-CTRL", "Speed controller board", "Electrical", "component", "ea", 0, 22.50, 30, 60, "SUP-ELC"),
    ("CP-FRM48", "Welded bench frame 48in", "Subassembly", "component", "ea", 0, 0, 12, 24, None),
    ("CP-FRM72", "Welded bench frame 72in", "Subassembly", "component", "ea", 0, 0, 8, 16, None),
    ("CP-DRW", "Drawer assembly", "Subassembly", "component", "ea", 0, 0, 20, 40, None),
    ("FG-WB48", "Industrial workbench 48in", "Workbenches", "finished", "ea", 489.00, 0, 10, 20, None),
    ("FG-WB72", "Industrial workbench 72in", "Workbenches", "finished", "ea", 649.00, 0, 6, 12, None),
    ("FG-SR36", "Heavy-duty shelving 36in", "Storage", "finished", "ea", 279.00, 0, 12, 24, None),
    ("FG-TC3", "Tool cart, 3 drawer", "Carts", "finished", "ea", 359.00, 0, 10, 20, None),
    ("FG-MC2", "Mobile utility cart", "Carts", "finished", "ea", 219.00, 0, 12, 24, None),
    ("FG-SC1", "Steel storage cabinet", "Storage", "finished", "ea", 529.00, 0, 6, 12, None),
    ("FG-FU20", "Shop air circulator 20in", "Equipment", "finished", "ea", 329.00, 0, 8, 16, None),
    ("FG-DPS", "Drill press stand", "Equipment", "finished", "ea", 189.00, 0, 8, 16, None),
    ("SV-INST", "On-site installation", "Services", "service", "hr", 95.00, 0, 0, 0, None),
    ("SV-FRT", "Freight - LTL", "Services", "service", "ea", 145.00, 0, 0, 0, None),
]

# parent: (labor, overhead, [(component, qty_per, scrap%)])
BOMS = {
    "CP-FRM48": (18.0, 6.0, [("RM-STT10", 34, 4), ("RM-STA15", 8, 3), ("RM-FOOT", 4, 0), ("RM-PCGY", 1.6, 5)]),
    "CP-FRM72": (24.0, 8.0, [("RM-STT10", 46, 4), ("RM-STA15", 12, 3), ("RM-FOOT", 6, 0), ("RM-PCGY", 2.2, 5)]),
    "CP-DRW": (6.0, 2.0, [("RM-STS16", 0.25, 6), ("RM-SLD18", 1, 0), ("RM-HNDL", 1, 0), ("RM-PCBK", 0.4, 5)]),
    "FG-WB48": (14.0, 5.0, [("CP-FRM48", 1, 0), ("RM-MDF34", 0.5, 2), ("RM-BLT8", 16, 2), ("RM-NUT8", 16, 2),
                            ("RM-WSH8", 32, 2), ("RM-BOXL", 1, 0), ("RM-FOAM", 1, 0)]),
    "FG-WB72": (18.0, 6.0, [("CP-FRM72", 1, 0), ("RM-MDF34", 0.75, 2), ("RM-BLT8", 20, 2), ("RM-NUT8", 20, 2),
                            ("RM-WSH8", 40, 2), ("RM-BOXL", 1, 0), ("RM-FOAM", 1, 0)]),
    "FG-SR36": (10.0, 4.0, [("RM-STA15", 48, 3), ("RM-STS16", 1.2, 5), ("RM-BLT8", 24, 2), ("RM-NUT8", 24, 2),
                            ("RM-PCGY", 2.0, 5), ("RM-BOXL", 1, 0)]),
    "FG-TC3": (16.0, 5.0, [("RM-STS16", 0.9, 5), ("CP-DRW", 3, 0), ("RM-CST4", 4, 0), ("RM-HNDL", 1, 0),
                           ("RM-PCBK", 1.5, 5), ("RM-BLT8", 12, 2), ("RM-BOXL", 1, 0)]),
    "FG-MC2": (9.0, 3.0, [("RM-STT10", 22, 4), ("RM-STS16", 0.6, 5), ("RM-CST4", 4, 0), ("RM-PCBK", 1.0, 5),
                          ("RM-BLT8", 8, 2), ("RM-BOXM", 1, 0)]),
    "FG-SC1": (20.0, 7.0, [("RM-STS16", 2.4, 6), ("RM-HNDL", 2, 0), ("RM-PCGY", 3.0, 5), ("RM-FOOT", 4, 0),
                           ("RM-BLT8", 16, 2), ("RM-BOXL", 1, 0), ("RM-FOAM", 1, 0)]),
    "FG-FU20": (12.0, 4.0, [("CP-MTR25", 1, 0), ("CP-CTRL", 1, 1), ("RM-ALX20", 6, 3), ("RM-CBL18", 8, 5),
                            ("RM-SWT1", 1, 0), ("RM-PCBK", 0.6, 5), ("RM-BOXM", 1, 0)]),
    "FG-DPS": (8.0, 3.0, [("RM-STT10", 16, 4), ("RM-STS16", 0.4, 5), ("RM-FOOT", 4, 0), ("RM-PCGY", 0.8, 5),
                          ("RM-BOXM", 1, 0)]),
}

CUSTOMERS = [
    ("C-ACME", "Acme Tool & Die", "Columbus", "OH", 30, 40000), ("C-BRKR", "Brookside Auto Repair", "Dayton", "OH", 30, 15000),
    ("C-CRSS", "Crossroads Hardware Co-op", "Lexington", "KY", 45, 60000),
    ("C-DLTA", "Delta Fleet Maintenance", "Cincinnati", "OH", 30, 25000),
    ("C-EAGL", "Eagle Industrial Supply", "Toledo", "OH", 30, 80000), ("C-FRTR", "Frontier Machining", "Erie", "PA", 30, 20000),
    ("C-GRNV", "Greenville School District", "Greenville", "OH", 45, 30000),
    ("C-HRBR", "Harbor Marine Services", "Sandusky", "OH", 15, 10000),
    ("C-IRON", "Ironwood Fabricators", "Fort Wayne", "IN", 30, 35000),
    ("C-JNSN", "Johnson Facilities Group", "Indianapolis", "IN", 30, 50000),
    ("C-KEYS", "Keystone Labs", "Pittsburgh", "PA", 30, 20000), ("C-LKSD", "Lakeside Makerspace", "Ann Arbor", "MI", 15, 8000),
    ("C-MRDN", "Meridian Hospital Facilities", "Louisville", "KY", 45, 45000),
    ("C-NRTH", "Northgate Equipment Rental", "Akron", "OH", 30, 30000),
    ("C-OAKS", "Oak Street Garage", "Springfield", "OH", 15, 6000),
    ("C-PNCL", "Pinnacle Aerospace Tooling", "Wichita", "KS", 30, 70000),
    ("C-QSRV", "QuickServe Appliance Repair", "Muncie", "IN", 30, 12000),
    ("C-RDGE", "Ridgeway Ag Equipment", "Lima", "OH", 30, 25000),
    ("C-STRM", "Stream Valley Utilities", "Huntington", "WV", 60, 40000),
    ("C-TRNT", "Trinity Woodworks", "Bloomington", "IN", 15, 9000),
    ("C-UNVS", "University Maintenance Dept.", "Athens", "OH", 45, 55000),
    ("C-VNGD", "Vanguard Logistics", "Columbus", "OH", 30, 65000),
    ("C-WSTF", "Westfield Motorsports", "Mansfield", "OH", 15, 15000),
    ("C-ZNTH", "Zenith Electronics Rework", "Kettering", "OH", 30, 18000),
]
SLOW_PAYERS = {"C-OAKS", "C-HRBR", "C-WSTF"}

EMPLOYEES = [
    # code, first, last, title, dept, pay_type, rate, manager_code, years
    ("E1001", "Margaret", "Holloway", "General Manager", "Administration", "salary", 128000, None, 11),
    ("E1002", "Peter", "Morgan", "Operations Manager", "Operations", "salary", 96000, "E1001", 8),
    ("E1003", "Alicia", "Nguyen", "Controller", "Finance", "salary", 92000, "E1001", 6),
    ("E1004", "Derek", "Simmons", "Sales Manager", "Sales", "salary", 88000, "E1001", 5),
    ("E1005", "Carla", "Mendez", "Production Supervisor", "Production", "salary", 71000, "E1002", 7),
    ("E1006", "James", "Whitaker", "Warehouse Lead", "Warehouse", "hourly", 27.50, "E1002", 4),
    ("E1007", "Sofia", "Ramirez", "Buyer", "Purchasing", "salary", 62000, "E1002", 3),
    ("E1008", "Kevin", "O'Brien", "Welder", "Production", "hourly", 26.00, "E1005", 6),
    ("E1009", "Tyrone", "Jackson", "Welder", "Production", "hourly", 25.25, "E1005", 2),
    ("E1010", "Laura", "Chen", "Powder Coat Technician", "Production", "hourly", 23.75, "E1005", 3),
    ("E1011", "Miguel", "Santos", "Assembler", "Production", "hourly", 21.50, "E1005", 1),
    ("E1012", "Rachel", "Kim", "Assembler", "Production", "hourly", 21.00, "E1005", 2),
    ("E1013", "Brandon", "Lee", "Machine Operator", "Production", "hourly", 24.00, "E1005", 5),
    ("E1014", "Hannah", "Fischer", "Quality Inspector", "Quality", "hourly", 25.00, "E1002", 4),
    ("E1015", "Andre", "Dubois", "Shipping Clerk", "Warehouse", "hourly", 20.50, "E1006", 2),
    ("E1016", "Emily", "Turner", "Receiving Clerk", "Warehouse", "hourly", 20.50, "E1006", 1),
    ("E1017", "Victor", "Petrov", "Forklift Operator", "Warehouse", "hourly", 21.75, "E1006", 3),
    ("E1018", "Grace", "Okafor", "AP/AR Specialist", "Finance", "hourly", 26.50, "E1003", 2),
    ("E1019", "Nathan", "Brooks", "Account Executive", "Sales", "salary", 58000, "E1004", 3),
    ("E1020", "Priya", "Desai", "Inside Sales Rep", "Sales", "hourly", 24.00, "E1004", 1),
    ("E1021", "Owen", "Gallagher", "Manufacturing Engineer", "Engineering", "salary", 84000, "E1002", 4),
    ("E1022", "Zoe", "Hartman", "Maintenance Technician", "Operations", "hourly", 28.00, "E1002", 2),
]

ASSETS = [
    ("FA-001", "CNC press brake 100T", "Machinery", 148000, 15000, 120, 4, "E1013"),
    ("FA-002", "Fiber laser cutter 3kW", "Machinery", 212000, 20000, 120, 3, "E1013"),
    ("FA-003", "MIG welder 250A #1", "Welding", 4800, 300, 60, 5, "E1008"),
    ("FA-004", "MIG welder 250A #2", "Welding", 4800, 300, 60, 2, "E1009"),
    ("FA-005", "Powder coat batch oven", "Finishing", 38500, 2500, 120, 6, "E1010"),
    ("FA-006", "Powder spray booth", "Finishing", 16200, 1000, 96, 6, "E1010"),
    ("FA-007", "Electric forklift 5000lb", "Material handling", 31000, 6000, 84, 3, "E1017"),
    ("FA-008", "Pallet jack, electric", "Material handling", 3900, 300, 60, 2, "E1015"),
    ("FA-009", "Box truck 26ft", "Vehicles", 89000, 18000, 96, 4, "E1006"),
    ("FA-010", "Cargo van", "Vehicles", 46000, 9000, 72, 2, "E1019"),
    ("FA-011", "Bandsaw, horizontal", "Machinery", 9200, 500, 84, 7, "E1008"),
    ("FA-012", "Air compressor 60gal", "Machinery", 2600, 0, 60, 4, "E1022"),
    ("FA-013", "Laptop - Finance", "IT", 1650, 0, 36, 1, "E1003"),
    ("FA-014", "Laptop - Sales", "IT", 1650, 0, 36, 2, "E1004"),
    ("FA-015", "Server / NAS", "IT", 5400, 0, 48, 2, "E1003"),
    ("FA-016", "Coordinate measuring arm", "Quality", 27500, 2000, 96, 3, "E1014"),
]


def seed(c, days=365, rng_seed=7):
    rnd = random.Random(rng_seed)
    end = date.today()
    start = end - timedelta(days=days)
    admin = Ctx("admin", "admin")
    buyer = Ctx("sramirez", "clerk")
    mgr = Ctx("pmorgan", "manager")
    sales = Ctx("pdesai", "clerk")
    wh = Ctx("jwhitaker", "clerk")
    ar = Ctx("gokafor", "clerk")
    with tx(c):
        # ---------- users
        for un, name, role, pw in [("admin", "Administrator", "admin", "admin"),
                                   ("pmorgan", "Peter Morgan", "manager", "manager"),
                                   ("sramirez", "Sofia Ramirez", "clerk", "clerk"),
                                   ("pdesai", "Priya Desai", "clerk", "clerk"),
                                   ("jwhitaker", "James Whitaker", "clerk", "clerk"),
                                   ("gokafor", "Grace Okafor", "clerk", "clerk"),
                                   ("auditor", "External Auditor", "viewer", "viewer")]:
            h, s = hash_password(pw)
            c.execute("INSERT OR IGNORE INTO users(username,full_name,role,pw_hash,salt,must_change_pw) "
                      "VALUES(?,?,?,?,?,1)", (un, name, role, h, s))
        # ---------- locations
        c.execute("UPDATE locations SET name='Main Plant & Warehouse', address='1200 Industrial Pkwy, Dayton OH' "
                  "WHERE code='MAIN'")
        c.execute("INSERT OR IGNORE INTO locations(code,name,address) VALUES('DIST','Columbus Distribution Center',"
                  "'88 Logistics Way, Columbus OH')")
        main = scalar(c, "SELECT id FROM locations WHERE code='MAIN'")
        dist = scalar(c, "SELECT id FROM locations WHERE code='DIST'")
        # ---------- suppliers
        sup = {}
        for code, name, contact, city, st, terms, lead in SUPPLIERS:
            sup[code] = c.execute(
                "INSERT INTO suppliers(code,name,contact,email,phone,address,city,state,postal,terms_days,lead_time_days)"
                " VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (code, name, contact, f"{contact.split()[0].lower()}@{code[4:].lower()}supply.example",
                 f"({rnd.randint(200, 989)}) 555-{rnd.randint(1000, 9999)}", f"{rnd.randint(100, 9999)} Commerce Dr",
                 city, st, f"{rnd.randint(40000, 49999)}", terms, lead)).lastrowid
        # ---------- items
        item = {}
        for sku, name, cat, typ, uom, price, std, rop, roq, s_code in ITEMS:
            item[sku] = c.execute(
                "INSERT INTO items(sku,name,category,type,uom,price,std_cost,avg_cost,reorder_point,reorder_qty,"
                "preferred_supplier_id) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                (sku, name, cat, typ, uom, price, std, std, rop, roq, sup.get(s_code))).lastrowid
        # ---------- BOMs (components first so rolled cost propagates)
        bom = {}
        for parent in ["CP-FRM48", "CP-FRM72", "CP-DRW"] + [k for k in BOMS if k.startswith("FG")]:
            lab, ovh, comps = BOMS[parent]
            r = S.save_bom(c, mgr, {"item_id": item[parent], "version": "A", "labor_cost": lab, "overhead_cost": ovh,
                                    "lines": [{"component_id": item[x], "qty_per": q, "scrap_pct": sp}
                                              for x, q, sp in comps]})
            bom[parent] = r["id"]
            std = round(lab + ovh + sum(q * (1 + sp / 100) * (scalar(c, "SELECT std_cost FROM items WHERE id=?", item[x]))
                                        for x, q, sp in comps), 2)
            c.execute("UPDATE items SET std_cost=?, avg_cost=? WHERE id=?", (std, std, item[parent]))
        # ---------- customers
        cus = {}
        for code, name, city, st, terms, limit in CUSTOMERS:
            limit = max(limit, 15000)
            cus[code] = c.execute(
                "INSERT INTO customers(code,name,contact,email,phone,address,city,state,postal,terms_days,credit_limit,"
                "tax_exempt) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (code, name, rnd.choice(["Pat", "Chris", "Jordan", "Sam", "Alex", "Taylor", "Morgan", "Casey"]) + " " +
                 rnd.choice(["Miller", "Davis", "Garcia", "Wilson", "Moore", "Clark", "Lewis", "Young"]),
                 f"purchasing@{code[2:].lower()}.example", f"({rnd.randint(200, 989)}) 555-{rnd.randint(1000, 9999)}",
                 f"{rnd.randint(10, 9999)} {rnd.choice(['Main', 'Oak', 'Market', 'Industrial', 'Park', 'River'])} St",
                 city, st, f"{rnd.randint(40000, 49999)}", terms, limit,
                 1 if code in ("C-GRNV", "C-UNVS", "C-MRDN") else 0)).lastrowid
        # ---------- employees
        emp = {}
        for code, fn, ln, title, dept, pt, rate, mcode, yrs in EMPLOYEES:
            hire = (end - timedelta(days=int(yrs * 365 + rnd.randint(0, 200)))).isoformat()
            emp[code] = c.execute(
                "INSERT INTO employees(code,first_name,last_name,title,department,email,phone,hire_date,pay_type,pay_rate,"
                "status,manager_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (code, fn, ln, title, dept, f"{fn[0].lower()}{ln.lower().replace(chr(39), '')}@northwindfab.example",
                 f"x{rnd.randint(200, 499)}", hire, pt, rate, "active", emp.get(mcode))).lastrowid
        c.execute("UPDATE employees SET status='leave' WHERE code='E1012'")
        c.execute("INSERT INTO employees(code,first_name,last_name,title,department,hire_date,termination_date,pay_type,"
                  "pay_rate,status,manager_id) VALUES('E0990','Gary','Lund','Assembler','Production',?,?,'hourly',20.0,"
                  "'terminated',?)", ((end - timedelta(days=900)).isoformat(), (end - timedelta(days=120)).isoformat(),
                                      emp["E1005"]))
        # ---------- assets
        for tag, name, cat, cost, salv, life, yrs, ecode in ASSETS:
            pd = (end - timedelta(days=int(yrs * 365 + rnd.randint(0, 150)))).isoformat()
            aid = c.execute(
                "INSERT INTO assets(tag,name,category,serial,location_id,employee_id,purchase_date,cost,salvage_value,"
                "useful_life_months,status,next_service_date) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                (tag, name, cat, f"SN{rnd.randint(100000, 999999)}", main, emp[ecode], pd, cost, salv, life,
                 "in_service", (end + timedelta(days=rnd.randint(-10, 120))).isoformat())).lastrowid
            for k in range(rnd.randint(1, 3)):
                c.execute("INSERT INTO asset_events(asset_id,date,type,description,cost,username) VALUES(?,?,?,?,?,?)",
                          (aid, (end - timedelta(days=rnd.randint(5, 330))).isoformat(),
                           rnd.choice(["maintenance", "inspection", "repair"]),
                           rnd.choice(["Scheduled PM", "Annual safety inspection", "Replaced worn parts",
                                       "Calibration", "Lubrication and belt check"]),
                           round(rnd.uniform(40, 900), 2), "zhartman"))
        c.execute("UPDATE assets SET status='maintenance' WHERE tag='FA-004'")
        c.execute("UPDATE assets SET status='retired', employee_id=NULL WHERE tag='FA-012'")
        c.execute("UPDATE assets SET location_id=? WHERE tag IN ('FA-008','FA-010')", (dist,))

        # ---------- opening balances
        ots = f"{start.isoformat()}T07:00:00"
        for sku, name, cat, typ, uom, price, std, rop, roq, _ in ITEMS:
            if typ == "service":
                continue
            q = roq * rnd.uniform(1.2, 1.8) if typ != "finished" else roq * rnd.uniform(0.6, 1.0)
            q = round(q) if uom in ("ea", "sheet", "pr", "set") else round(q, 1)
            uc = scalar(c, "SELECT std_cost FROM items WHERE id=?", item[sku])
            S.post_inventory(c, admin, item[sku], main, q, "opening", uc, "opening", None, "Opening balance", ots)
            if typ == "finished" and rnd.random() < 0.6:
                S.post_inventory(c, admin, item[sku], dist, max(2, round(q / 3)), "opening", uc, "opening", None,
                                 "Opening balance", ots)

        # ---------- simulation
        events, counter = [], itertools.count()

        def at(d, fn, *a):
            if d <= end:
                heapq.heappush(events, (d, next(counter), fn, a))

        sup_rows = {r["id"]: r for r in all_(c, "SELECT * FROM suppliers")}
        cus_rows = {r["id"]: r for r in all_(c, "SELECT * FROM customers")}
        fg = [item[x[0]] for x in ITEMS if x[3] == "finished"]
        weights = [9, 6, 8, 7, 9, 4, 5, 6]
        services_ = [item["SV-INST"], item["SV-FRT"]]

        def receive(d, po_id):
            po = one(c, "SELECT * FROM purchase_orders WHERE id=?", po_id)
            if po["status"] not in ("approved", "partial"):
                return
            lines = all_(c, "SELECT * FROM po_lines WHERE po_id=? AND qty_received<qty", po_id)
            partial = rnd.random() < 0.18 and po["status"] == "approved"
            todo = []
            for l in lines:
                rem = l["qty"] - l["qty_received"]
                q = round(rem * rnd.uniform(0.4, 0.7)) if partial and rem > 4 else rem
                if q > 0:
                    todo.append({"po_line_id": l["id"], "qty": q})
            if not todo:
                return
            S.receive_po(c, wh, po_id, todo, d.isoformat())
            at(d + timedelta(days=rnd.randint(1, 4)), bill, po_id)
            if partial:
                at(d + timedelta(days=rnd.randint(4, 9)), receive, po_id)

        def bill(d, po_id):
            try:
                b = S.create_bill(c, ar, po_id, f"INV{rnd.randint(10000, 99999)}", d.isoformat())
            except BizError:
                return
            bl = one(c, "SELECT * FROM bills WHERE id=?", b["id"])
            pay_d = date.fromisoformat(bl["due_date"]) - timedelta(days=rnd.randint(0, 5))
            at(max(pay_d, d), pay_bill, b["id"])

        def pay_bill(d, bill_id):
            bl = one(c, "SELECT * FROM bills WHERE id=?", bill_id)
            if bl["status"] in ("open", "partial"):
                S.pay_bill(c, ar, bill_id, round(bl["total"] - bl["amount_paid"], 2), d.isoformat(),
                           rnd.choice(["ACH", "ACH", "Check", "Wire"]), f"REF{rnd.randint(100000, 999999)}")

        def purchasing(d):
            sugg = [s for s in S.reorder_suggestions(c) if s["action"] == "buy" and s["supplier_id"]]
            by = {}
            for s in sugg:
                by.setdefault(s["supplier_id"], []).append(s)
            for sid, lines in by.items():
                drift = 1 + rnd.uniform(-0.04, 0.06)
                po = S.save_po(c, buyer, {
                    "supplier_id": sid, "order_date": d.isoformat(), "location_id": main,
                    "lines": [{"item_id": s["item_id"], "qty": s["suggested_qty"],
                               "unit_cost": round(scalar(c, "SELECT std_cost FROM items WHERE id=?", s["item_id"]) * drift, 4)}
                              for s in lines]})
                S.approve_po(c, mgr, po["id"])
                lead = sup_rows[sid]["lead_time_days"] + rnd.randint(-1, 4)
                at(d + timedelta(days=max(1, lead)), receive, po["id"])

        def production(d):
            for sku in ["CP-FRM48", "CP-FRM72", "CP-DRW"] + [x for x in BOMS if x.startswith("FG")]:
                iid = item[sku]
                r = one(c, "SELECT * FROM v_items WHERE id=?", iid)
                planned = scalar(c, "SELECT COALESCE(SUM(qty-qty_completed),0) FROM production_orders WHERE item_id=? "
                                    "AND status IN ('planned','released')", iid)
                if r["on_hand"] + planned - r["committed"] < r["reorder_point"]:
                    mo = S.save_mo(c, mgr, {"item_id": iid, "qty": r["reorder_qty"], "location_id": main,
                                            "start_date": d.isoformat(),
                                            "due_date": (d + timedelta(days=rnd.randint(3, 6))).isoformat()})
                    S.release_mo(c, mgr, mo["id"])
                    at(d + timedelta(days=rnd.randint(2, 4)), complete, mo["id"])

        def complete(d, mo_id):
            mo = one(c, "SELECT * FROM production_orders WHERE id=?", mo_id)
            if mo["status"] != "released":
                return
            rem = mo["qty"] - mo["qty_completed"]
            # build as much as components allow (partial output), retry later for the rest
            for q in (rem, round(rem / 2), max(1, round(rem / 4))):
                try:
                    S.complete_mo(c, Ctx("cmendez", "clerk"), mo_id, q, d.isoformat())
                    break
                except BizError:
                    continue
            mo = one(c, "SELECT * FROM production_orders WHERE id=?", mo_id)
            if mo["status"] == "released":
                at(d + timedelta(days=3), complete, mo_id)

        def sell(d):
            for _ in range(rnd.randint(3, 6)):
                code = rnd.choice(list(cus.values()))
                cu = cus_rows[code]
                n = rnd.choices([1, 2, 3, 4], [4, 4, 2, 1])[0]
                picks = list(dict.fromkeys(rnd.choices(fg, weights, k=n)))
                lines = []
                for iid in picks:
                    price = scalar(c, "SELECT price FROM items WHERE id=?", iid)
                    lines.append({"item_id": iid, "qty": rnd.choices([1, 2, 3, 4, 6, 10], [5, 5, 3, 2, 1, 1])[0],
                                  "unit_price": price, "discount_pct": rnd.choice([0, 0, 0, 5, 10])})
                if rnd.random() < 0.2:
                    lines.append({"item_id": rnd.choice(services_), "qty": rnd.choice([1, 2, 4]), "unit_price": None})
                loc = dist if rnd.random() < 0.25 else main
                so = S.save_so(c, sales, {"customer_id": code, "order_date": d.isoformat(), "location_id": loc,
                                          "ship_by": (d + timedelta(days=rnd.randint(3, 12))).isoformat(),
                                          "customer_po": f"PO{rnd.randint(1000, 99999)}" if rnd.random() < 0.7 else "",
                                          "lines": lines})
                if rnd.random() < 0.04:
                    continue  # stays a draft (quote not yet accepted)
                try:
                    S.confirm_so(c, sales, so["id"])
                except BizError:
                    continue  # blocked by credit limit; left as draft for review
                at(d + timedelta(days=rnd.randint(1, 5)), ship, so["id"])

        def ship(d, so_id):
            so = one(c, "SELECT * FROM sales_orders WHERE id=?", so_id)
            if so["status"] not in ("confirmed", "partial"):
                return
            todo = []
            for l in all_(c, "SELECT l.*, i.type FROM so_lines l JOIN items i ON i.id=l.item_id WHERE so_id=? "
                             "AND qty_shipped<qty", so_id):
                rem = l["qty"] - l["qty_shipped"]
                if l["type"] == "service":
                    q = rem
                else:
                    have = scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", l["item_id"],
                                  so["location_id"]) or 0
                    if have < rem:  # pull from the other site before shipping short
                        other = main if so["location_id"] == dist else dist
                        spare = int(scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?",
                                           l["item_id"], other) or 0)
                        move = min(spare, int(rem - have))
                        if move > 0:
                            S.transfer_stock(c, wh, l["item_id"], other, so["location_id"], move,
                                             f"Transfer to fulfil {so['number']}", d.isoformat())
                            have += move
                    q = min(rem, int(have))
                if q > 0:
                    todo.append({"so_line_id": l["id"], "qty": q})
            if todo:
                sh = S.ship_so(c, wh, so_id, todo, d.isoformat(), None,
                               rnd.choice(["UPS Freight", "Estes", "XPO", "Own truck", "R+L Carriers"]),
                               f"1Z{rnd.randint(10**9, 10**10 - 1)}")
                at(d + timedelta(days=rnd.choice([0, 0, 1])), invoice, sh["id"])
            so = one(c, "SELECT * FROM sales_orders WHERE id=?", so_id)
            if so["status"] in ("confirmed", "partial"):
                at(d + timedelta(days=3), ship, so_id)

        def invoice(d, ship_id):
            v = S.invoice_shipment(c, ar, ship_id, d.isoformat())
            inv = one(c, "SELECT * FROM invoices WHERE id=?", v["id"])
            code = scalar(c, "SELECT code FROM customers WHERE id=?", inv["customer_id"])
            due = date.fromisoformat(inv["due_date"])
            lag = rnd.randint(25, 80) if code in SLOW_PAYERS else rnd.randint(-12, 12)
            pd = max(d, due + timedelta(days=lag))
            if rnd.random() < 0.12:
                at(pd - timedelta(days=10) if pd - timedelta(days=10) > d else pd, pay, v["id"], 0.5)
            at(pd, pay, v["id"], 1.0)

        def pay(d, inv_id, frac):
            inv = one(c, "SELECT * FROM invoices WHERE id=?", inv_id)
            if inv["status"] not in ("open", "partial"):
                return
            bal = round(inv["total"] - inv["amount_paid"], 2)
            amt = bal if frac >= 1 else round(bal * frac, 2)
            S.record_payment(c, ar, inv_id, amt, d.isoformat(), rnd.choice(["Check", "ACH", "ACH", "Card"]),
                             f"{rnd.randint(1000, 99999)}")

        def housekeeping(d):
            # monthly cycle count with small variances, and a replenishment transfer to the DC
            for iid in rnd.sample([item[x[0]] for x in ITEMS if x[3] == "raw"], 3):
                have = scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", iid, main) or 0
                if have > 20:
                    S.adjust_stock(c, mgr, iid, main, counted=round(have * rnd.uniform(0.985, 1.01)),
                                   reason="Monthly cycle count", date_=d.isoformat())
            for iid in rnd.sample(fg, 2):
                have = scalar(c, "SELECT qty FROM stock WHERE item_id=? AND location_id=?", iid, main) or 0
                if have >= 6:
                    S.transfer_stock(c, wh, iid, main, dist, int(have // 3), "DC replenishment", d.isoformat())

        d = start + timedelta(days=1)
        while d <= end:
            while events and events[0][0] <= d:
                _, _, fn, a = heapq.heappop(events)
                fn(d, *a)
            if d.weekday() < 5:
                if d.weekday() in (0, 3):
                    purchasing(d)
                if d.weekday() in (1, 3):
                    production(d)
                if rnd.random() < 0.75:
                    sell(d)
            if d.day == 15:
                housekeeping(d)
            d += timedelta(days=1)

        # ---------- a few deliberate exceptions for realism
        drafts = all_(c, "SELECT id FROM sales_orders WHERE status='draft' ORDER BY id DESC LIMIT 2")
        if drafts:
            S.cancel_so(c, mgr, drafts[-1]["id"])
        po = S.save_po(c, buyer, {"supplier_id": sup["SUP-MTR"], "order_date": end.isoformat(), "location_id": main,
                                  "notes": "Quote for next quarter - pending approval",
                                  "lines": [{"item_id": item["CP-MTR25"], "qty": 200, "unit_cost": 61.5},
                                            {"item_id": item["CP-CTRL"], "qty": 200, "unit_cost": 21.9}]})
        S.save_mo(c, mgr, {"item_id": item["FG-SC1"], "qty": 8, "location_id": main, "start_date": end.isoformat(),
                           "notes": "Planned for Meridian Hospital project"})
        c.execute("DELETE FROM audit_log WHERE username IN ('admin') AND action='login'")
    return {"start": start.isoformat(), "end": end.isoformat()}
