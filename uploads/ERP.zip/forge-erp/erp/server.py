"""HTTP server (stdlib only): JSON API, static UI, printable documents, file transfers."""
import base64
import json
import mimetypes
import os
import re
import sqlite3
import tempfile
import threading
import traceback
from http import cookies
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from . import auth, backup, documents, entities, reports, services as S
from .db import BizError, Forbidden, NotFound, connect, get_settings, init_db, all_, tx, audit, cast_setting

STATIC = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static")
MAX_BODY = 30 * 1024 * 1024


class App:
    def __init__(self, db_path, allowed_hosts=None):
        self.db_path = db_path
        self.local = threading.local()
        self.allowed_hosts = set(allowed_hosts or []) | {"127.0.0.1", "localhost", "[::1]"}

    def conn(self):
        # ThreadingHTTPServer runs each request on a new thread, so connections are per request.
        return connect(self.db_path)


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        raise BizError("A valid record id is required.")


ACTIONS = {
    # purchasing
    "po_save": lambda c, x, b: S.save_po(c, x, b),
    "po_approve": lambda c, x, b: S.approve_po(c, x, _int(b.get("id"))),
    "po_cancel": lambda c, x, b: S.cancel_po(c, x, _int(b.get("id"))),
    "po_close": lambda c, x, b: S.close_po(c, x, _int(b.get("id"))),
    "po_receive": lambda c, x, b: S.receive_po(c, x, _int(b.get("id")), b.get("lines"), b.get("date"),
                                               b.get("location_id"), b.get("notes")),
    "bill_create": lambda c, x, b: S.create_bill(c, x, _int(b.get("po_id")), b.get("supplier_ref", ""), b.get("date"),
                                                 b.get("tax") or 0, b.get("notes")),
    "bill_pay": lambda c, x, b: S.pay_bill(c, x, _int(b.get("id")), b.get("amount"), b.get("date"),
                                           b.get("method") or "ACH", b.get("reference") or ""),
    "bill_void": lambda c, x, b: S.void_bill(c, x, _int(b.get("id"))),
    # sales
    "so_save": lambda c, x, b: S.save_so(c, x, b),
    "so_confirm": lambda c, x, b: S.confirm_so(c, x, _int(b.get("id")), bool(b.get("override_credit"))),
    "so_cancel": lambda c, x, b: S.cancel_so(c, x, _int(b.get("id"))),
    "so_close": lambda c, x, b: S.close_so(c, x, _int(b.get("id"))),
    "so_ship": lambda c, x, b: S.ship_so(c, x, _int(b.get("id")), b.get("lines"), b.get("date"), b.get("location_id"),
                                         b.get("carrier") or "", b.get("tracking") or "", b.get("notes")),
    "invoice_create": lambda c, x, b: S.invoice_shipment(c, x, _int(b.get("shipment_id")), b.get("date"), b.get("notes")),
    "invoice_pay": lambda c, x, b: S.record_payment(c, x, _int(b.get("id")), b.get("amount"), b.get("date"),
                                                    b.get("method") or "Check", b.get("reference") or ""),
    "invoice_void": lambda c, x, b: S.void_invoice(c, x, _int(b.get("id"))),
    # manufacturing
    "bom_save": lambda c, x, b: S.save_bom(c, x, b),
    "mo_save": lambda c, x, b: S.save_mo(c, x, b),
    "mo_release": lambda c, x, b: S.release_mo(c, x, _int(b.get("id"))),
    "mo_complete": lambda c, x, b: S.complete_mo(c, x, _int(b.get("id")), b.get("qty"), b.get("date")),
    "mo_cancel": lambda c, x, b: S.cancel_mo(c, x, _int(b.get("id"))),
    # inventory
    "inv_adjust": lambda c, x, b: S.adjust_stock(c, x, _int(b.get("item_id")), _int(b.get("location_id")),
                                                 b.get("qty"), b.get("counted"), b.get("reason") or "",
                                                 b.get("unit_cost"), b.get("date")),
    "inv_transfer": lambda c, x, b: S.transfer_stock(c, x, _int(b.get("item_id")), _int(b.get("from_location_id")),
                                                     _int(b.get("to_location_id")), b.get("qty"), b.get("note") or "",
                                                     b.get("date")),
    "reorder_create_pos": lambda c, x, b: S.create_pos_from_suggestions(c, x, b.get("item_ids")),
    "rebuild_stock": lambda c, x, b: S.rebuild_stock(c, x),
    # assets
    "asset_event": lambda c, x, b: S.add_asset_event(c, x, _int(b.get("id")), b.get("type") or "note",
                                                     b.get("description") or "", b.get("cost") or 0, b.get("date"),
                                                     b.get("status") or None),
}


def make_handler(app):
    class H(BaseHTTPRequestHandler):
        server_version = "ForgeERP"
        sys_version = ""
        protocol_version = "HTTP/1.1"

        def log_message(self, fmt, *args):
            if os.environ.get("ERP_HTTP_LOG"):
                super().log_message(fmt, *args)

        # ---------------- helpers
        def _send(self, code, body, ctype="application/json; charset=utf-8", headers=None, csp=None):
            if isinstance(body, (dict, list)):
                body = json.dumps(body, default=str).encode()
            elif isinstance(body, str):
                body = body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Referrer-Policy", "no-referrer")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Security-Policy", csp or
                             "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                             "frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
            for k, v in (headers or {}).items():
                self.send_header(k, v)
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(body)

        def _err(self, code, msg):
            self._send(code, {"error": msg})

        def _cookie(self, name):
            raw = self.headers.get("Cookie")
            if not raw:
                return None
            ck = cookies.SimpleCookie()
            try:
                ck.load(raw)
            except cookies.CookieError:
                return None
            return ck[name].value if name in ck else None

        def _read_raw(self):
            # Always drain the request body so keep-alive connections stay in sync.
            try:
                n = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                n = 0
            if n > MAX_BODY:
                self.close_connection = True
                self._raw = None
                return
            self._raw = self.rfile.read(n) if n > 0 else b""

        def _body(self):
            raw = self._raw
            if raw is None:
                raise BizError("Request too large (limit 30 MB).")
            if not raw:
                return {}
            try:
                return json.loads(raw)
            except ValueError:
                raise BizError("Malformed JSON body.")

        def _host_ok(self):
            host = (self.headers.get("Host") or "").rsplit(":", 1)[0].lower()
            return host in app.allowed_hosts

        def _user(self, c):
            return auth.session_user(c, self._cookie("erp_session"))

        def _file(self, data, filename, ctype):
            self._send(200, data, ctype, {"Content-Disposition": f'attachment; filename="{filename}"'})

        # ---------------- verbs
        def do_HEAD(self):
            self.do_GET()

        def do_GET(self):
            self._dispatch("GET")

        def do_POST(self):
            self._dispatch("POST")

        def _dispatch(self, method):
            self._read_raw() if method == "POST" else setattr(self, "_raw", b"")
            if not self._host_ok():
                return self._err(421, "Host not allowed.")
            u = urlparse(self.path)
            path = u.path
            params = {k: v[-1] for k, v in parse_qs(u.query).items()}
            c = app.conn()
            try:
                self._route(c, method, path, params)
            finally:
                c.close()

        def _route(self, c, method, path, params):
            try:
                if method == "GET" and not path.startswith(("/api/", "/doc/")):
                    return self._static(path)
                if path == "/api/login" and method == "POST":
                    return self._login(c)
                user = self._user(c)
                if not user:
                    return self._err(401, "Please sign in.")
                ctx = auth.ctx_for(user)
                if method == "POST":
                    origin = self.headers.get("Origin")
                    if origin and urlparse(origin).hostname not in {h.strip("[]") for h in app.allowed_hosts}:
                        return self._err(403, "Cross-origin request rejected.")
                    if self.headers.get("X-CSRF") != user["csrf"]:
                        return self._err(403, "Session token mismatch. Reload the page.")
                if path.startswith("/doc/"):
                    return self._doc(c, path)
                return self._api(c, ctx, user, method, path, params)
            except Forbidden as e:
                self._err(403, str(e))
            except NotFound as e:
                self._err(404, str(e))
            except BizError as e:
                self._err(400, str(e))
            except sqlite3.IntegrityError as e:
                self._err(400, f"Data integrity rule violated: {e}")
            except Exception as e:  # pragma: no cover - logged for diagnosis
                traceback.print_exc()
                self._err(500, f"Unexpected error: {type(e).__name__}. See server console.")

        def _static(self, path):
            if path in ("/", "/index.html"):
                path = "/index.html"
            fp = os.path.normpath(os.path.join(STATIC, path.lstrip("/")))
            if not fp.startswith(STATIC + os.sep) or not os.path.isfile(fp):
                fp = os.path.join(STATIC, "index.html")
            with open(fp, "rb") as f:
                data = f.read()
            ctype = mimetypes.guess_type(fp)[0] or "application/octet-stream"
            if ctype.startswith("text/") or ctype.endswith("javascript"):
                ctype += "; charset=utf-8"
            self._send(200, data, ctype)

        def _login(self, c):
            b = self._body()
            token, csrf, u = auth.login(c, b.get("username"), b.get("password"))
            self._send(200, {"ok": True}, headers={
                "Set-Cookie": f"erp_session={token}; HttpOnly; SameSite=Strict; Path=/"})

        def _doc(self, c, path):
            m = re.fullmatch(r"/doc/([a-z_]+)/(\d+)", path)
            if not m:
                raise NotFound("Unknown document.")
            html = documents.render(c, m.group(1), int(m.group(2)))
            self._send(200, html, "text/html; charset=utf-8",
                       csp="default-src 'none'; style-src 'unsafe-inline'; script-src 'unsafe-inline'")

        def _api(self, c, ctx, user, method, path, p):
            seg = path.strip("/").split("/")[1:]  # drop 'api'
            head = seg[0] if seg else ""
            G, P = method == "GET", method == "POST"

            if head == "me" and G:
                return self._send(200, {"username": user["username"], "full_name": user["full_name"],
                                        "role": user["role"], "csrf": user["csrf"],
                                        "must_change_pw": bool(user["must_change_pw"])})
            if head == "logout" and P:
                auth.logout(c, self._cookie("erp_session"))
                return self._send(200, {"ok": True}, headers={"Set-Cookie": "erp_session=; Max-Age=0; Path=/"})
            if head == "password" and P:
                b = self._body()
                if b.get("user_id") and int(b["user_id"]) != user["id"]:
                    auth.admin_reset_password(c, ctx, int(b["user_id"]), b.get("new_password"))
                else:
                    auth.change_password(c, user["id"], b.get("old_password"), b.get("new_password"))
                return self._send(200, {"ok": True})
            if head == "meta" and G:
                st = all_(c, "SELECT key,value,type,label,grp,description FROM settings ORDER BY rowid")
                return self._send(200, {"entities": entities.public_meta(), "reports": reports.report_index(),
                                        "settings": st, "values": get_settings(c),
                                        "locations": all_(c, "SELECT id, code, name FROM locations WHERE active=1 ORDER BY id")})
            if head == "lookup" and G and len(seg) == 2:
                return self._send(200, self._lookup(c, ctx, seg[1], p.get("q", ""), p.get("id")))
            if head == "list" and G and len(seg) == 2:
                fmt = p.get("format")
                if fmt in ("csv", "xlsx"):
                    hdr, rows = entities.export_rows(c, ctx, seg[1], p)
                    return self._export(seg[1], hdr, rows, fmt)
                return self._send(200, entities.list_rows(c, ctx, seg[1], p))
            if head == "export" and G and len(seg) == 2:  # import-compatible layout
                hdr, rows = entities.export_for_import(c, ctx, seg[1])
                return self._export(seg[1] + "-data", hdr, rows, p.get("format") or "xlsx")
            if head == "template" and G and len(seg) == 2:
                hdr = [h for h, _ in entities.import_layout(seg[1])]
                return self._export(seg[1] + "-template", hdr, [], p.get("format") or "xlsx")
            if head == "record" and G and len(seg) == 3:
                kind, rid = seg[1], int(seg[2])
                e = entities.ENTITIES.get(kind, {})
                if e.get("role"):
                    S.require(ctx, e["role"])
                try:
                    data = documents.load(c, kind, rid)
                except NotFound:
                    if kind in entities.ENTITIES:
                        data = entities.get_record(c, ctx, kind, rid)
                        data["history"] = all_(c, "SELECT ts, username, action, summary FROM audit_log WHERE entity=? "
                                                  "AND entity_id=? ORDER BY id DESC LIMIT 50", kind, rid)
                    else:
                        raise
                if kind == "employees" and not entities.can_see_sensitive(ctx):
                    data["pay_rate"] = None
                return self._send(200, data)
            if head == "save" and P and len(seg) == 2:
                return self._send(200, entities.save_record(c, ctx, seg[1], self._body()))
            if head == "delete" and P and len(seg) == 3:
                return self._send(200, entities.delete_record(c, ctx, seg[1], int(seg[2])))
            if head == "bulk" and P and len(seg) == 2:
                b = self._body()
                return self._send(200, entities.bulk_update(c, ctx, seg[1], b.get("ids"), b.get("field"),
                                                            b.get("op") or "set", b.get("value")))
            if head == "import" and P and len(seg) == 2:
                b = self._body()
                try:
                    data = base64.b64decode(b.get("data") or "", validate=True)
                except ValueError:
                    raise BizError("Upload could not be decoded.")
                try:
                    hdr, rows = entities.xlsx_read(b.get("filename"), data)
                except ValueError as e:
                    raise BizError(str(e))
                if not hdr:
                    raise BizError("The file is empty.")
                if not b.get("dry_run", True):
                    backup.create_backup(c, app.db_path, "pre-import")
                return self._send(200, entities.import_rows(c, ctx, seg[1], hdr, rows, b.get("dry_run", True)))
            if head == "action" and P and len(seg) == 2:
                fn = ACTIONS.get(seg[1])
                if not fn:
                    raise NotFound("Unknown action.")
                S.require(ctx, "clerk")
                return self._send(200, fn(c, ctx, self._body()) or {"ok": True})
            if head == "dashboard" and G:
                return self._send(200, reports.dashboard(c, ctx))
            if head == "reports" and G and len(seg) == 2:
                out = reports.run_report(c, ctx, seg[1], p)
                fmt = p.get("format")
                if fmt in ("csv", "xlsx"):
                    cols = out["columns"]
                    return self._export(seg[1], [x["label"] for x in cols],
                                        [[r.get(x["key"]) for x in cols] for r in out["rows"]], fmt)
                return self._send(200, out)
            if head == "search" and G:
                return self._send(200, entities.global_search(c, ctx, p.get("q")))
            if head == "reconcile" and G:
                return self._send(200, S.reconcile(c))
            if head == "requirements" and G:
                return self._send(200, S.requirements(c, int(p["bom_id"]), float(p.get("qty") or 1)))
            if head == "settings" and P:
                S.require(ctx, "admin")
                b = self._body()
                with tx(c):
                    for k, v in (b.get("values") or {}).items():
                        r = c.execute("SELECT value,type FROM settings WHERE key=?", (k,)).fetchone()
                        if not r:
                            raise BizError(f"Unknown setting {k}.")
                        try:
                            nv = cast_setting(v, r["type"])
                        except ValueError:
                            raise BizError(f"Invalid value for {k}.")
                        if r["type"] in ("int", "float") and nv < 0:
                            raise BizError(f"{k} cannot be negative.")
                        if k == "default_tax_rate" and nv >= 1:
                            raise BizError("Tax rate must be a fraction below 1.")
                        sv = ("1" if nv else "0") if r["type"] == "bool" else str(nv)
                        if sv != r["value"]:
                            c.execute("UPDATE settings SET value=? WHERE key=?", (sv, k))
                            audit(c, ctx.username, "setting", "settings", None, f"{k}: {r['value']} -> {sv}",
                                  {k: r["value"]}, {k: sv})
                return self._send(200, {"ok": True})
            if head == "backups":
                S.require(ctx, "admin")
                sub = seg[1] if len(seg) > 1 else ""
                if G and not sub:
                    return self._send(200, backup.list_backups(app.db_path))
                if P and sub == "create":
                    r = backup.create_backup(c, app.db_path, "manual")
                    with tx(c):
                        audit(c, ctx.username, "backup", "system", None, f"Backup {r['name']} created")
                    return self._send(200, r)
                if G and sub == "download" and len(seg) == 3:
                    fp = backup.backup_path(app.db_path, seg[2])
                    with open(fp, "rb") as f:
                        return self._file(f.read(), seg[2], "application/octet-stream")
                if P and sub == "verify":
                    return self._send(200, backup.verify_backup(backup.backup_path(app.db_path, self._body().get("name"))))
                if P and sub == "restore":
                    b = self._body()
                    if b.get("data"):
                        src = backup.save_upload(app.db_path, base64.b64decode(b["data"]))
                    else:
                        src = backup.backup_path(app.db_path, b.get("name"))
                    r = backup.restore_from_file(c, app.db_path, src)
                    init_db(c)  # idempotent: re-applies settings/sequences if missing
                    with tx(c):
                        audit(c, ctx.username, "restore", "system", None,
                              f"Restored {r['restored']} (safety copy {r['safety_backup']})")
                    return self._send(200, r)
            raise NotFound(f"No route for {method} {path}")

        def _lookup(self, c, ctx, name, q, id_=None):
            e = entities.entity(name)
            if e.get("role"):
                S.require(ctx, e["role"])
            label = {"items": "sku || ' — ' || name", "employees": "code || ' — ' || first_name || ' ' || last_name",
                     "assets": "tag || ' — ' || name", "users": "username"}.get(name, f"{e['key']} || ' — ' || name")
            table = e.get("table") or e["view"]
            extra = ", type, price, avg_cost, std_cost, uom" if name == "items" else ""
            if id_:
                return all_(c, f"SELECT id, {label} AS label{extra} FROM {table} WHERE id=?", int(id_))
            act = " AND active=1" if "active" in {r[1] for r in c.execute(f"PRAGMA table_info({table})")} else ""
            where = " OR ".join(f"{s} LIKE ?" for s in e["search"] if s in {r[1] for r in
                                                                          c.execute(f"PRAGMA table_info({table})")})
            terms = [f"%{q.strip()}%"] * where.count("?")
            return all_(c, f"SELECT id, {label} AS label{extra} FROM {table} WHERE ({where}){act} "
                           f"ORDER BY {e['key']} LIMIT 30", *terms)

        def _export(self, name, hdr, rows, fmt):
            from .xlsx import write_csv, write_xlsx
            if fmt == "csv":
                return self._file(write_csv(hdr, rows), f"{name}.csv", "text/csv; charset=utf-8")
            return self._file(write_xlsx(hdr, rows, name), f"{name}.xlsx",
                              "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")

    return H


def serve(db_path, host="127.0.0.1", port=8765, allowed_hosts=None):
    app = App(db_path, allowed_hosts)
    httpd = ThreadingHTTPServer((host, port), make_handler(app))
    httpd.daemon_threads = True
    return httpd
