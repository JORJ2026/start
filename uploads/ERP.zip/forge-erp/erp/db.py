"""Database layer: schema, connections, transactions, settings, numbering."""
import json
import os
import sqlite3
import threading
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal, ROUND_HALF_UP

SCHEMA_VERSION = 1
EPS = 1e-9
WRITE_LOCK = threading.RLock()


class BizError(Exception):
    """A business-rule violation, reported to the user verbatim."""


class NotFound(BizError):
    pass


class Forbidden(BizError):
    pass


def money(x):
    return float(Decimal(str(x or 0)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def qty4(x):
    return float(Decimal(str(x or 0)).quantize(Decimal("0.0001"), rounding=ROUND_HALF_UP))


def today():
    return date.today().isoformat()


def now():
    return datetime.now().strftime("%Y-%m-%dT%H:%M:%S")


SCHEMA = r"""
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS settings(
  key TEXT PRIMARY KEY, value TEXT NOT NULL, type TEXT NOT NULL DEFAULT 'str',
  label TEXT, grp TEXT, description TEXT);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, full_name TEXT NOT NULL,
  role TEXT NOT NULL CHECK(role IN ('admin','manager','clerk','viewer')),
  pw_hash TEXT NOT NULL, salt TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  must_change_pw INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  csrf TEXT NOT NULL, created_at TEXT NOT NULL, expires_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log(
  id INTEGER PRIMARY KEY, ts TEXT NOT NULL, username TEXT, action TEXT NOT NULL,
  entity TEXT NOT NULL, entity_id INTEGER, summary TEXT, before_json TEXT, after_json TEXT);
CREATE INDEX IF NOT EXISTS ix_audit_entity ON audit_log(entity, entity_id);
CREATE INDEX IF NOT EXISTS ix_audit_ts ON audit_log(ts);
CREATE TABLE IF NOT EXISTS sequences(
  name TEXT PRIMARY KEY, prefix TEXT NOT NULL, next_val INTEGER NOT NULL CHECK(next_val>0), width INTEGER NOT NULL DEFAULT 5);

CREATE TABLE IF NOT EXISTS locations(
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL,
  address TEXT, active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)));

CREATE TABLE IF NOT EXISTS customers(
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL,
  contact TEXT, email TEXT, phone TEXT, address TEXT, city TEXT, state TEXT, postal TEXT,
  country TEXT NOT NULL DEFAULT 'US', terms_days INTEGER NOT NULL DEFAULT 30 CHECK(terms_days>=0),
  credit_limit REAL NOT NULL DEFAULT 0 CHECK(credit_limit>=0),
  tax_exempt INTEGER NOT NULL DEFAULT 0 CHECK(tax_exempt IN (0,1)), notes TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));

CREATE TABLE IF NOT EXISTS suppliers(
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL,
  contact TEXT, email TEXT, phone TEXT, address TEXT, city TEXT, state TEXT, postal TEXT,
  country TEXT NOT NULL DEFAULT 'US', terms_days INTEGER NOT NULL DEFAULT 30 CHECK(terms_days>=0),
  lead_time_days INTEGER NOT NULL DEFAULT 7 CHECK(lead_time_days>=0), notes TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));

CREATE TABLE IF NOT EXISTS items(
  id INTEGER PRIMARY KEY, sku TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL, description TEXT,
  category TEXT, type TEXT NOT NULL CHECK(type IN ('raw','component','finished','service')),
  uom TEXT NOT NULL DEFAULT 'ea', price REAL NOT NULL DEFAULT 0 CHECK(price>=0),
  std_cost REAL NOT NULL DEFAULT 0 CHECK(std_cost>=0), avg_cost REAL NOT NULL DEFAULT 0,
  reorder_point REAL NOT NULL DEFAULT 0 CHECK(reorder_point>=0),
  reorder_qty REAL NOT NULL DEFAULT 0 CHECK(reorder_qty>=0),
  preferred_supplier_id INTEGER REFERENCES suppliers(id) ON DELETE RESTRICT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)),
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));

CREATE TABLE IF NOT EXISTS stock(
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  qty REAL NOT NULL DEFAULT 0, PRIMARY KEY(item_id, location_id));

CREATE TABLE IF NOT EXISTS inventory_txns(
  id INTEGER PRIMARY KEY, ts TEXT NOT NULL,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty<>0), unit_cost REAL NOT NULL DEFAULT 0,
  type TEXT NOT NULL CHECK(type IN ('opening','receipt','shipment','issue','output','adjustment','transfer_in','transfer_out')),
  ref_type TEXT, ref_id INTEGER, balance_after REAL NOT NULL, username TEXT, note TEXT);
CREATE INDEX IF NOT EXISTS ix_itx_item ON inventory_txns(item_id, location_id);
CREATE INDEX IF NOT EXISTS ix_itx_ref ON inventory_txns(ref_type, ref_id);
CREATE INDEX IF NOT EXISTS ix_itx_ts ON inventory_txns(ts);

CREATE TABLE IF NOT EXISTS boms(
  id INTEGER PRIMARY KEY, item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  version TEXT NOT NULL DEFAULT 'A', labor_cost REAL NOT NULL DEFAULT 0 CHECK(labor_cost>=0),
  overhead_cost REAL NOT NULL DEFAULT 0 CHECK(overhead_cost>=0), notes TEXT,
  active INTEGER NOT NULL DEFAULT 1 CHECK(active IN (0,1)), UNIQUE(item_id, version));
CREATE TABLE IF NOT EXISTS bom_lines(
  id INTEGER PRIMARY KEY, bom_id INTEGER NOT NULL REFERENCES boms(id) ON DELETE CASCADE,
  component_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  qty_per REAL NOT NULL CHECK(qty_per>0),
  scrap_pct REAL NOT NULL DEFAULT 0 CHECK(scrap_pct>=0 AND scrap_pct<100), UNIQUE(bom_id, component_id));

CREATE TABLE IF NOT EXISTS purchase_orders(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','approved','partial','received','closed','cancelled')),
  order_date TEXT NOT NULL, expected_date TEXT,
  location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  notes TEXT, created_by TEXT, approved_by TEXT);
CREATE TABLE IF NOT EXISTS po_lines(
  id INTEGER PRIMARY KEY, po_id INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty>0), unit_cost REAL NOT NULL CHECK(unit_cost>=0),
  qty_received REAL NOT NULL DEFAULT 0 CHECK(qty_received>=0),
  qty_billed REAL NOT NULL DEFAULT 0 CHECK(qty_billed>=0));
CREATE INDEX IF NOT EXISTS ix_pol_po ON po_lines(po_id);
CREATE TABLE IF NOT EXISTS receipts(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  po_id INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE RESTRICT,
  date TEXT NOT NULL, location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  notes TEXT, created_by TEXT);
CREATE TABLE IF NOT EXISTS receipt_lines(
  id INTEGER PRIMARY KEY, receipt_id INTEGER NOT NULL REFERENCES receipts(id) ON DELETE RESTRICT,
  po_line_id INTEGER NOT NULL REFERENCES po_lines(id) ON DELETE RESTRICT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty>0), unit_cost REAL NOT NULL);
CREATE TABLE IF NOT EXISTS bills(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE, supplier_ref TEXT,
  supplier_id INTEGER NOT NULL REFERENCES suppliers(id) ON DELETE RESTRICT,
  po_id INTEGER REFERENCES purchase_orders(id) ON DELETE RESTRICT,
  date TEXT NOT NULL, due_date TEXT NOT NULL, subtotal REAL NOT NULL, tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL, amount_paid REAL NOT NULL DEFAULT 0 CHECK(amount_paid>=0),
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','partial','paid','void')), notes TEXT);
CREATE TABLE IF NOT EXISTS bill_lines(
  id INTEGER PRIMARY KEY, bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE RESTRICT,
  po_line_id INTEGER REFERENCES po_lines(id) ON DELETE RESTRICT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty>0), unit_cost REAL NOT NULL, amount REAL NOT NULL);
CREATE TABLE IF NOT EXISTS supplier_payments(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE RESTRICT,
  date TEXT NOT NULL, amount REAL NOT NULL CHECK(amount>0), method TEXT, reference TEXT);

CREATE TABLE IF NOT EXISTS sales_orders(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  status TEXT NOT NULL DEFAULT 'draft' CHECK(status IN ('draft','confirmed','partial','shipped','closed','cancelled')),
  order_date TEXT NOT NULL, ship_by TEXT, customer_po TEXT,
  location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  tax_rate REAL NOT NULL DEFAULT 0 CHECK(tax_rate>=0 AND tax_rate<1), notes TEXT, created_by TEXT);
CREATE TABLE IF NOT EXISTS so_lines(
  id INTEGER PRIMARY KEY, so_id INTEGER NOT NULL REFERENCES sales_orders(id) ON DELETE CASCADE,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty>0), unit_price REAL NOT NULL CHECK(unit_price>=0),
  discount_pct REAL NOT NULL DEFAULT 0 CHECK(discount_pct>=0 AND discount_pct<=100),
  qty_shipped REAL NOT NULL DEFAULT 0 CHECK(qty_shipped>=0),
  qty_invoiced REAL NOT NULL DEFAULT 0 CHECK(qty_invoiced>=0));
CREATE INDEX IF NOT EXISTS ix_sol_so ON so_lines(so_id);
CREATE TABLE IF NOT EXISTS shipments(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  so_id INTEGER NOT NULL REFERENCES sales_orders(id) ON DELETE RESTRICT,
  date TEXT NOT NULL, location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  carrier TEXT, tracking TEXT, notes TEXT, created_by TEXT);
CREATE TABLE IF NOT EXISTS shipment_lines(
  id INTEGER PRIMARY KEY, shipment_id INTEGER NOT NULL REFERENCES shipments(id) ON DELETE RESTRICT,
  so_line_id INTEGER NOT NULL REFERENCES so_lines(id) ON DELETE RESTRICT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty>0), unit_cost REAL NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS invoices(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  customer_id INTEGER NOT NULL REFERENCES customers(id) ON DELETE RESTRICT,
  so_id INTEGER NOT NULL REFERENCES sales_orders(id) ON DELETE RESTRICT,
  shipment_id INTEGER REFERENCES shipments(id) ON DELETE RESTRICT,
  date TEXT NOT NULL, due_date TEXT NOT NULL, subtotal REAL NOT NULL, tax REAL NOT NULL DEFAULT 0,
  total REAL NOT NULL, amount_paid REAL NOT NULL DEFAULT 0 CHECK(amount_paid>=0),
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','partial','paid','void')), notes TEXT);
CREATE INDEX IF NOT EXISTS ix_inv_ship ON invoices(shipment_id);
CREATE TABLE IF NOT EXISTS invoice_lines(
  id INTEGER PRIMARY KEY, invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
  so_line_id INTEGER REFERENCES so_lines(id) ON DELETE RESTRICT,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  description TEXT, qty REAL NOT NULL CHECK(qty>0), unit_price REAL NOT NULL, amount REAL NOT NULL);
CREATE TABLE IF NOT EXISTS payments(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE RESTRICT,
  date TEXT NOT NULL, amount REAL NOT NULL CHECK(amount>0), method TEXT, reference TEXT);

CREATE TABLE IF NOT EXISTS production_orders(
  id INTEGER PRIMARY KEY, number TEXT NOT NULL UNIQUE,
  item_id INTEGER NOT NULL REFERENCES items(id) ON DELETE RESTRICT,
  bom_id INTEGER NOT NULL REFERENCES boms(id) ON DELETE RESTRICT,
  qty REAL NOT NULL CHECK(qty>0), qty_completed REAL NOT NULL DEFAULT 0 CHECK(qty_completed>=0),
  status TEXT NOT NULL DEFAULT 'planned' CHECK(status IN ('planned','released','completed','cancelled')),
  location_id INTEGER NOT NULL REFERENCES locations(id) ON DELETE RESTRICT,
  start_date TEXT, due_date TEXT, completed_date TEXT, actual_cost REAL NOT NULL DEFAULT 0,
  notes TEXT, created_by TEXT);

CREATE TABLE IF NOT EXISTS employees(
  id INTEGER PRIMARY KEY, code TEXT NOT NULL UNIQUE COLLATE NOCASE,
  first_name TEXT NOT NULL, last_name TEXT NOT NULL, title TEXT, department TEXT,
  email TEXT, phone TEXT, hire_date TEXT, termination_date TEXT,
  pay_type TEXT NOT NULL DEFAULT 'hourly' CHECK(pay_type IN ('hourly','salary')),
  pay_rate REAL NOT NULL DEFAULT 0 CHECK(pay_rate>=0),
  status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','leave','terminated')),
  manager_id INTEGER REFERENCES employees(id) ON DELETE RESTRICT, notes TEXT);

CREATE TABLE IF NOT EXISTS assets(
  id INTEGER PRIMARY KEY, tag TEXT NOT NULL UNIQUE COLLATE NOCASE, name TEXT NOT NULL,
  category TEXT, serial TEXT,
  location_id INTEGER REFERENCES locations(id) ON DELETE RESTRICT,
  employee_id INTEGER REFERENCES employees(id) ON DELETE RESTRICT,
  supplier_id INTEGER REFERENCES suppliers(id) ON DELETE RESTRICT,
  purchase_date TEXT, cost REAL NOT NULL DEFAULT 0 CHECK(cost>=0),
  salvage_value REAL NOT NULL DEFAULT 0 CHECK(salvage_value>=0),
  useful_life_months INTEGER NOT NULL DEFAULT 60 CHECK(useful_life_months>0),
  status TEXT NOT NULL DEFAULT 'in_service' CHECK(status IN ('in_service','maintenance','retired','disposed')),
  next_service_date TEXT, notes TEXT);
CREATE TABLE IF NOT EXISTS asset_events(
  id INTEGER PRIMARY KEY, asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
  date TEXT NOT NULL, type TEXT NOT NULL CHECK(type IN ('maintenance','repair','inspection','transfer','assignment','status','note')),
  description TEXT, cost REAL NOT NULL DEFAULT 0 CHECK(cost>=0), username TEXT);

-- ---------- reporting views ----------
CREATE VIEW IF NOT EXISTS v_items AS
SELECT i.*, s.code AS supplier_code,
  COALESCE((SELECT SUM(qty) FROM stock WHERE item_id=i.id),0) AS on_hand,
  ROUND(COALESCE((SELECT SUM(qty) FROM stock WHERE item_id=i.id),0)*i.avg_cost,2) AS stock_value,
  COALESCE((SELECT SUM(l.qty-l.qty_received) FROM po_lines l JOIN purchase_orders p ON p.id=l.po_id
            WHERE l.item_id=i.id AND p.status IN ('approved','partial') AND l.qty>l.qty_received),0) AS on_order,
  COALESCE((SELECT SUM(l.qty-l.qty_shipped) FROM so_lines l JOIN sales_orders o ON o.id=l.so_id
            WHERE l.item_id=i.id AND o.status IN ('confirmed','partial') AND l.qty>l.qty_shipped),0) AS committed
FROM items i LEFT JOIN suppliers s ON s.id=i.preferred_supplier_id;

CREATE VIEW IF NOT EXISTS v_purchase_orders AS
SELECT p.*, s.code AS supplier_code, s.name AS supplier_name, lo.code AS location_code,
  ROUND(COALESCE((SELECT SUM(qty*unit_cost) FROM po_lines WHERE po_id=p.id),0),2) AS total,
  ROUND(COALESCE((SELECT SUM(qty_received*unit_cost) FROM po_lines WHERE po_id=p.id),0),2) AS received_value,
  ROUND(COALESCE((SELECT SUM(qty_billed*unit_cost) FROM po_lines WHERE po_id=p.id),0),2) AS billed_value
FROM purchase_orders p JOIN suppliers s ON s.id=p.supplier_id JOIN locations lo ON lo.id=p.location_id;

CREATE VIEW IF NOT EXISTS v_sales_orders AS
SELECT o.*, c.code AS customer_code, c.name AS customer_name, lo.code AS location_code,
  ROUND(COALESCE((SELECT SUM(qty*unit_price*(1-discount_pct/100.0)) FROM so_lines WHERE so_id=o.id),0),2) AS subtotal,
  ROUND(COALESCE((SELECT SUM(qty_shipped*unit_price*(1-discount_pct/100.0)) FROM so_lines WHERE so_id=o.id),0),2) AS shipped_value
FROM sales_orders o JOIN customers c ON c.id=o.customer_id JOIN locations lo ON lo.id=o.location_id;

CREATE VIEW IF NOT EXISTS v_invoices AS
SELECT v.*, c.code AS customer_code, c.name AS customer_name, o.number AS so_number,
  sh.number AS shipment_number, ROUND(v.total-v.amount_paid,2) AS balance,
  CASE WHEN v.status IN ('open','partial') AND v.due_date < date('now','localtime')
       THEN CAST(julianday(date('now','localtime'))-julianday(v.due_date) AS INTEGER) ELSE 0 END AS days_overdue
FROM invoices v JOIN customers c ON c.id=v.customer_id JOIN sales_orders o ON o.id=v.so_id
LEFT JOIN shipments sh ON sh.id=v.shipment_id;

CREATE VIEW IF NOT EXISTS v_bills AS
SELECT b.*, s.code AS supplier_code, s.name AS supplier_name, p.number AS po_number,
  ROUND(b.total-b.amount_paid,2) AS balance,
  CASE WHEN b.status IN ('open','partial') AND b.due_date < date('now','localtime')
       THEN CAST(julianday(date('now','localtime'))-julianday(b.due_date) AS INTEGER) ELSE 0 END AS days_overdue
FROM bills b JOIN suppliers s ON s.id=b.supplier_id LEFT JOIN purchase_orders p ON p.id=b.po_id;

CREATE VIEW IF NOT EXISTS v_receipts AS
SELECT r.*, p.number AS po_number, s.name AS supplier_name, lo.code AS location_code,
  ROUND(COALESCE((SELECT SUM(qty*unit_cost) FROM receipt_lines WHERE receipt_id=r.id),0),2) AS value
FROM receipts r JOIN purchase_orders p ON p.id=r.po_id JOIN suppliers s ON s.id=p.supplier_id
JOIN locations lo ON lo.id=r.location_id;

CREATE VIEW IF NOT EXISTS v_shipments AS
SELECT sh.*, o.number AS so_number, c.name AS customer_name, lo.code AS location_code,
  (SELECT number FROM invoices WHERE shipment_id=sh.id AND status<>'void') AS invoice_number,
  ROUND(COALESCE((SELECT SUM(qty*unit_cost) FROM shipment_lines WHERE shipment_id=sh.id),0),2) AS cost_value
FROM shipments sh JOIN sales_orders o ON o.id=sh.so_id JOIN customers c ON c.id=o.customer_id
JOIN locations lo ON lo.id=sh.location_id;

CREATE VIEW IF NOT EXISTS v_payments AS
SELECT p.*, v.number AS invoice_number, c.name AS customer_name
FROM payments p JOIN invoices v ON v.id=p.invoice_id JOIN customers c ON c.id=v.customer_id;

CREATE VIEW IF NOT EXISTS v_supplier_payments AS
SELECT p.*, b.number AS bill_number, s.name AS supplier_name
FROM supplier_payments p JOIN bills b ON b.id=p.bill_id JOIN suppliers s ON s.id=b.supplier_id;

CREATE VIEW IF NOT EXISTS v_production_orders AS
SELECT m.*, i.sku, i.name AS item_name, b.version AS bom_version, lo.code AS location_code,
  ROUND(m.qty-m.qty_completed,4) AS qty_remaining
FROM production_orders m JOIN items i ON i.id=m.item_id JOIN boms b ON b.id=m.bom_id
JOIN locations lo ON lo.id=m.location_id;

CREATE VIEW IF NOT EXISTS v_boms AS
SELECT b.*, i.sku, i.name AS item_name,
  (SELECT COUNT(*) FROM bom_lines WHERE bom_id=b.id) AS component_count,
  ROUND(b.labor_cost+b.overhead_cost+COALESCE((SELECT SUM(l.qty_per*(1+l.scrap_pct/100.0)*c.avg_cost)
     FROM bom_lines l JOIN items c ON c.id=l.component_id WHERE l.bom_id=b.id),0),4) AS rolled_cost
FROM boms b JOIN items i ON i.id=b.item_id;

CREATE VIEW IF NOT EXISTS v_inventory_txns AS
SELECT t.*, i.sku, i.name AS item_name, lo.code AS location_code, ROUND(t.qty*t.unit_cost,2) AS value
FROM inventory_txns t JOIN items i ON i.id=t.item_id JOIN locations lo ON lo.id=t.location_id;

CREATE VIEW IF NOT EXISTS v_stock AS
SELECT s.item_id, s.location_id, s.qty, i.sku, i.name AS item_name, i.uom, i.avg_cost,
  lo.code AS location_code, ROUND(s.qty*i.avg_cost,2) AS value
FROM stock s JOIN items i ON i.id=s.item_id JOIN locations lo ON lo.id=s.location_id;

CREATE VIEW IF NOT EXISTS v_employees AS
SELECT e.*, e.first_name||' '||e.last_name AS full_name,
  m.first_name||' '||m.last_name AS manager_name
FROM employees e LEFT JOIN employees m ON m.id=e.manager_id;

CREATE VIEW IF NOT EXISTS v_assets AS
SELECT a.*, lo.code AS location_code, e.first_name||' '||e.last_name AS assigned_to, s.name AS supplier_name,
  ROUND(MAX(a.salvage_value, a.cost - (a.cost-a.salvage_value) *
     MIN(1.0, MAX(0.0,(julianday(date('now','localtime'))-julianday(COALESCE(a.purchase_date,date('now','localtime'))))/30.436875)
         / a.useful_life_months)),2) AS book_value
FROM assets a LEFT JOIN locations lo ON lo.id=a.location_id LEFT JOIN employees e ON e.id=a.employee_id
LEFT JOIN suppliers s ON s.id=a.supplier_id;

CREATE VIEW IF NOT EXISTS v_customers AS
SELECT c.*,
  ROUND(COALESCE((SELECT SUM(total-amount_paid) FROM invoices WHERE customer_id=c.id AND status IN ('open','partial')),0),2) AS ar_balance
FROM customers c;

CREATE VIEW IF NOT EXISTS v_suppliers AS
SELECT s.*,
  ROUND(COALESCE((SELECT SUM(total-amount_paid) FROM bills WHERE supplier_id=s.id AND status IN ('open','partial')),0),2) AS ap_balance
FROM suppliers s;
"""

DEFAULT_SETTINGS = [
    # key, value, type, label, group, description
    ("company_name", "Northwind Fabrication Co.", "str", "Company name", "Company", "Printed on all documents"),
    ("company_address", "1200 Industrial Pkwy, Dayton, OH 45402", "str", "Company address", "Company", ""),
    ("company_phone", "(937) 555-0142", "str", "Phone", "Company", ""),
    ("company_email", "orders@northwindfab.example", "str", "Email", "Company", ""),
    ("currency_symbol", "$", "str", "Currency symbol", "Company", ""),
    ("default_tax_rate", "0.0725", "float", "Default sales tax rate", "Sales", "Fraction, e.g. 0.0725 = 7.25%"),
    ("enforce_credit_limit", "1", "bool", "Enforce customer credit limits", "Sales",
     "Block order confirmation when open AR + open orders exceed the customer's credit limit (0 limit = unlimited)"),
    ("auto_invoice_on_ship", "0", "bool", "Invoice automatically on shipment", "Sales", ""),
    ("allow_negative_stock", "0", "bool", "Allow negative stock", "Inventory",
     "If off, shipments, issues and transfers that would drive a location below zero are rejected"),
    ("over_receipt_tolerance_pct", "5", "float", "Over-receipt tolerance %", "Purchasing",
     "Maximum quantity received above ordered quantity"),
    ("po_approval_limit", "5000", "float", "PO approval limit for clerks", "Purchasing",
     "Purchase orders above this total require a manager or admin to approve"),
    ("require_receipt_before_bill", "1", "bool", "Three-way match (bill only received qty)", "Purchasing", ""),
    ("auto_backup_on_start", "1", "bool", "Automatic backup at startup", "System", ""),
    ("backup_retention", "30", "int", "Backups to keep", "System", "Older automatic backups are pruned"),
    ("session_hours", "12", "int", "Session length (hours)", "System", ""),
]

SEQUENCES = [
    ("purchase_orders", "PO-", 1001), ("receipts", "RCV-", 1001), ("bills", "BILL-", 1001),
    ("supplier_payments", "SPAY-", 1001), ("sales_orders", "SO-", 1001), ("shipments", "SHP-", 1001),
    ("invoices", "INV-", 1001), ("payments", "PAY-", 1001), ("production_orders", "MO-", 1001),
]


def connect(path):
    c = sqlite3.connect(path, timeout=10, isolation_level=None, check_same_thread=False)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    c.execute("PRAGMA busy_timeout=10000")
    if path != ":memory:":
        c.execute("PRAGMA journal_mode=WAL")
        c.execute("PRAGMA synchronous=NORMAL")
    return c


def init_db(c):
    c.executescript(SCHEMA)
    for k, v, t, label, grp, desc in DEFAULT_SETTINGS:
        c.execute("INSERT OR IGNORE INTO settings(key,value,type,label,grp,description) VALUES(?,?,?,?,?,?)",
                  (k, v, t, label, grp, desc))
    for name, prefix, start in SEQUENCES:
        c.execute("INSERT OR IGNORE INTO sequences(name,prefix,next_val) VALUES(?,?,?)", (name, prefix, start))
    c.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('schema_version',?)", (str(SCHEMA_VERSION),))
    c.execute("INSERT OR IGNORE INTO meta(key,value) VALUES('app','forge-erp')")
    if not c.execute("SELECT 1 FROM locations LIMIT 1").fetchone():
        c.execute("INSERT INTO locations(code,name) VALUES('MAIN','Main Warehouse')")


@contextmanager
def tx(c):
    """Serialized write transaction; rolls back on any exception."""
    with WRITE_LOCK:
        if c.in_transaction:  # nested: join outer transaction
            yield c
            return
        c.execute("BEGIN IMMEDIATE")
        try:
            yield c
            c.execute("COMMIT")
        except BaseException:
            c.execute("ROLLBACK")
            raise


def one(c, sql, *args):
    r = c.execute(sql, args).fetchone()
    return dict(r) if r else None


def all_(c, sql, *args):
    return [dict(r) for r in c.execute(sql, args).fetchall()]


def scalar(c, sql, *args):
    r = c.execute(sql, args).fetchone()
    return r[0] if r else None


def get_settings(c):
    out = {}
    for r in c.execute("SELECT key,value,type FROM settings"):
        out[r["key"]] = cast_setting(r["value"], r["type"])
    return out


def cast_setting(v, t):
    if t == "bool":
        return str(v).strip().lower() in ("1", "true", "yes", "on")
    if t == "int":
        return int(float(v))
    if t == "float":
        return float(v)
    return v


def setting(c, key):
    r = c.execute("SELECT value,type FROM settings WHERE key=?", (key,)).fetchone()
    if not r:
        raise KeyError(key)
    return cast_setting(r["value"], r["type"])


def next_number(c, name):
    r = c.execute("SELECT prefix,next_val,width FROM sequences WHERE name=?", (name,)).fetchone()
    c.execute("UPDATE sequences SET next_val=next_val+1 WHERE name=?", (name,))
    return f"{r['prefix']}{str(r['next_val']).zfill(r['width'])}"


def audit(c, user, action, entity, entity_id=None, summary=None, before=None, after=None):
    c.execute("INSERT INTO audit_log(ts,username,action,entity,entity_id,summary,before_json,after_json)"
              " VALUES(?,?,?,?,?,?,?,?)",
              (now(), user, action, entity, entity_id, summary,
               json.dumps(before, default=str) if before is not None else None,
               json.dumps(after, default=str) if after is not None else None))


def open_db(path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    c = connect(path)
    init_db(c)
    return c
