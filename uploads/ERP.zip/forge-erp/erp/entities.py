"""Entity metadata plus generic list / CRUD / bulk-edit / import / export / search."""
import re
import sqlite3

from .db import BizError, NotFound, all_, audit, one, scalar, tx
from .services import require
from .xlsx import read_table as xlsx_read  # noqa: F401  (used by server)

STATUS_PO = ["draft", "approved", "partial", "received", "closed", "cancelled"]
STATUS_SO = ["draft", "confirmed", "partial", "shipped", "closed", "cancelled"]
STATUS_MO = ["planned", "released", "completed", "cancelled"]
STATUS_INV = ["open", "partial", "paid", "void"]


def F(name, label, type_="text", **kw):
    return {"name": name, "label": label, "type": type_, **kw}


def C(key, label, type_="text", **kw):
    return {"key": key, "label": label, "type": type_, **kw}


ADDRESS = [F("contact", "Contact"), F("email", "Email", "email"), F("phone", "Phone"),
           F("address", "Address"), F("city", "City"), F("state", "State"), F("postal", "Postal code"),
           F("country", "Country", default="US")]

ENTITIES = {
    "customers": dict(
        label="Customer", plural="Customers", table="customers", view="v_customers", key="code", group="Sales",
        fields=[F("code", "Code", required=True), F("name", "Name", required=True), *ADDRESS,
                F("terms_days", "Terms (days)", "int", default=30), F("credit_limit", "Credit limit", "money", default=0),
                F("tax_exempt", "Tax exempt", "bool", default=0), F("notes", "Notes", "textarea"),
                F("active", "Active", "bool", default=1)],
        columns=[C("code", "Code"), C("name", "Name"), C("contact", "Contact"), C("phone", "Phone"),
                 C("city", "City"), C("state", "State"), C("terms_days", "Terms", "int"),
                 C("credit_limit", "Credit limit", "money"), C("ar_balance", "AR balance", "money"),
                 C("active", "Active", "bool")],
        search=["code", "name", "contact", "email", "city"], filters={"active": [1, 0]},
        bulk=["terms_days", "credit_limit", "tax_exempt", "active", "state"], sort="name"),
    "suppliers": dict(
        label="Supplier", plural="Suppliers", table="suppliers", view="v_suppliers", key="code", group="Purchasing",
        fields=[F("code", "Code", required=True), F("name", "Name", required=True), *ADDRESS,
                F("terms_days", "Terms (days)", "int", default=30), F("lead_time_days", "Lead time (days)", "int", default=7),
                F("notes", "Notes", "textarea"), F("active", "Active", "bool", default=1)],
        columns=[C("code", "Code"), C("name", "Name"), C("contact", "Contact"), C("phone", "Phone"),
                 C("city", "City"), C("terms_days", "Terms", "int"), C("lead_time_days", "Lead days", "int"),
                 C("ap_balance", "AP balance", "money"), C("active", "Active", "bool")],
        search=["code", "name", "contact", "email", "city"], filters={"active": [1, 0]},
        bulk=["terms_days", "lead_time_days", "active"], sort="name"),
    "items": dict(
        label="Item", plural="Items", table="items", view="v_items", key="sku", group="Inventory",
        fields=[F("sku", "SKU", required=True), F("name", "Name", required=True), F("description", "Description", "textarea"),
                F("category", "Category"), F("type", "Type", "select", required=True,
                                              choices=["raw", "component", "finished", "service"], default="raw"),
                F("uom", "Unit of measure", default="ea"), F("price", "Sales price", "money", default=0),
                F("std_cost", "Standard cost", "cost", default=0),
                F("avg_cost", "Average cost", "cost", readonly=True),
                F("reorder_point", "Reorder point", "float", default=0), F("reorder_qty", "Reorder qty", "float", default=0),
                F("preferred_supplier_id", "Preferred supplier", "ref", ref="suppliers"),
                F("active", "Active", "bool", default=1)],
        columns=[C("sku", "SKU"), C("name", "Name"), C("category", "Category"), C("type", "Type", "tag"),
                 C("uom", "UoM"), C("price", "Price", "money"), C("avg_cost", "Avg cost", "cost"),
                 C("on_hand", "On hand", "qty"), C("committed", "Committed", "qty"), C("on_order", "On order", "qty"),
                 C("stock_value", "Value", "money"), C("reorder_point", "Reorder pt", "qty"),
                 C("supplier_code", "Supplier"), C("active", "Active", "bool")],
        search=["sku", "name", "category", "description"],
        filters={"type": ["raw", "component", "finished", "service"], "active": [1, 0]},
        bulk=["price", "std_cost", "reorder_point", "reorder_qty", "category", "preferred_supplier_id", "active", "uom"],
        sort="sku"),
    "locations": dict(
        label="Location", plural="Locations", table="locations", view="locations", key="code", group="Inventory",
        fields=[F("code", "Code", required=True), F("name", "Name", required=True), F("address", "Address"),
                F("active", "Active", "bool", default=1)],
        columns=[C("code", "Code"), C("name", "Name"), C("address", "Address"), C("active", "Active", "bool")],
        search=["code", "name"], bulk=["active"], sort="code"),
    "employees": dict(
        label="Employee", plural="Employees", table="employees", view="v_employees", key="code", group="People",
        fields=[F("code", "Employee #", required=True), F("first_name", "First name", required=True),
                F("last_name", "Last name", required=True), F("title", "Title"), F("department", "Department"),
                F("email", "Email", "email"), F("phone", "Phone"), F("hire_date", "Hire date", "date"),
                F("termination_date", "Termination date", "date"),
                F("pay_type", "Pay type", "select", choices=["hourly", "salary"], default="hourly"),
                F("pay_rate", "Pay rate", "money", default=0, sensitive=True),
                F("status", "Status", "select", choices=["active", "leave", "terminated"], default="active"),
                F("manager_id", "Manager", "ref", ref="employees"), F("notes", "Notes", "textarea")],
        columns=[C("code", "Emp #"), C("full_name", "Name"), C("title", "Title"), C("department", "Department"),
                 C("email", "Email"), C("hire_date", "Hired", "date"), C("pay_type", "Pay type"),
                 C("pay_rate", "Rate", "money", sensitive=True), C("manager_name", "Manager"), C("status", "Status", "tag")],
        search=["code", "first_name", "last_name", "title", "department", "email"],
        filters={"status": ["active", "leave", "terminated"]},
        bulk=["department", "title", "status", "manager_id", "pay_rate"], sort="last_name"),
    "assets": dict(
        label="Asset", plural="Assets", table="assets", view="v_assets", key="tag", group="People",
        fields=[F("tag", "Asset tag", required=True), F("name", "Name", required=True), F("category", "Category"),
                F("serial", "Serial #"), F("location_id", "Location", "ref", ref="locations"),
                F("employee_id", "Assigned to", "ref", ref="employees"), F("supplier_id", "Supplier", "ref", ref="suppliers"),
                F("purchase_date", "Purchase date", "date"), F("cost", "Cost", "money", default=0),
                F("salvage_value", "Salvage value", "money", default=0),
                F("useful_life_months", "Useful life (months)", "int", default=60),
                F("status", "Status", "select", choices=["in_service", "maintenance", "retired", "disposed"],
                  default="in_service"),
                F("next_service_date", "Next service", "date"), F("notes", "Notes", "textarea")],
        columns=[C("tag", "Tag"), C("name", "Name"), C("category", "Category"), C("location_code", "Location"),
                 C("assigned_to", "Assigned to"), C("purchase_date", "Purchased", "date"), C("cost", "Cost", "money"),
                 C("book_value", "Book value", "money"), C("next_service_date", "Next service", "date"),
                 C("status", "Status", "tag")],
        search=["tag", "name", "category", "serial"],
        filters={"status": ["in_service", "maintenance", "retired", "disposed"]},
        bulk=["category", "location_id", "employee_id", "status", "next_service_date"], sort="tag"),
    "users": dict(
        label="User", plural="Users", table="users", view="users", key="username", group="Admin", role="admin",
        fields=[F("username", "Username", required=True), F("full_name", "Full name", required=True),
                F("role", "Role", "select", choices=["admin", "manager", "clerk", "viewer"], default="clerk"),
                F("active", "Active", "bool", default=1)],
        columns=[C("username", "Username"), C("full_name", "Name"), C("role", "Role", "tag"),
                 C("active", "Active", "bool"), C("created_at", "Created", "date")],
        search=["username", "full_name"], bulk=["role", "active"], sort="username", noimport=True),
    # ---- transactional (read via list, edited through services) ----
    "purchase_orders": dict(
        label="Purchase order", plural="Purchase orders", view="v_purchase_orders", group="Purchasing", txn=True,
        columns=[C("number", "PO #"), C("supplier_name", "Supplier"), C("order_date", "Ordered", "date"),
                 C("expected_date", "Expected", "date"), C("location_code", "Loc"), C("total", "Total", "money"),
                 C("received_value", "Received", "money"), C("billed_value", "Billed", "money"),
                 C("status", "Status", "tag")],
        search=["number", "supplier_name", "notes"], filters={"status": STATUS_PO}, sort="id", dir="desc",
        datecol="order_date"),
    "receipts": dict(
        label="Receipt", plural="Receipts", view="v_receipts", group="Purchasing", txn=True,
        columns=[C("number", "Receipt #"), C("po_number", "PO #"), C("supplier_name", "Supplier"),
                 C("date", "Date", "date"), C("location_code", "Loc"), C("value", "Value", "money"),
                 C("created_by", "By")],
        search=["number", "po_number", "supplier_name"], sort="id", dir="desc", datecol="date"),
    "bills": dict(
        label="Supplier bill", plural="Supplier bills", view="v_bills", group="Purchasing", txn=True,
        columns=[C("number", "Bill #"), C("supplier_ref", "Supplier inv #"), C("supplier_name", "Supplier"),
                 C("po_number", "PO #"), C("date", "Date", "date"), C("due_date", "Due", "date"),
                 C("total", "Total", "money"), C("balance", "Balance", "money"),
                 C("days_overdue", "Days late", "int"), C("status", "Status", "tag")],
        search=["number", "supplier_ref", "supplier_name", "po_number"], filters={"status": STATUS_INV},
        sort="id", dir="desc", datecol="date"),
    "supplier_payments": dict(
        label="Supplier payment", plural="Supplier payments", view="v_supplier_payments", group="Purchasing", txn=True,
        columns=[C("number", "Payment #"), C("bill_number", "Bill #"), C("supplier_name", "Supplier"),
                 C("date", "Date", "date"), C("amount", "Amount", "money"), C("method", "Method"),
                 C("reference", "Reference")],
        search=["number", "bill_number", "supplier_name", "reference"], sort="id", dir="desc", datecol="date"),
    "sales_orders": dict(
        label="Sales order", plural="Sales orders", view="v_sales_orders", group="Sales", txn=True,
        columns=[C("number", "SO #"), C("customer_name", "Customer"), C("customer_po", "Cust PO"),
                 C("order_date", "Ordered", "date"), C("ship_by", "Ship by", "date"), C("subtotal", "Subtotal", "money"),
                 C("shipped_value", "Shipped", "money"), C("status", "Status", "tag")],
        search=["number", "customer_name", "customer_po", "notes"], filters={"status": STATUS_SO},
        sort="id", dir="desc", datecol="order_date"),
    "shipments": dict(
        label="Shipment", plural="Shipments", view="v_shipments", group="Sales", txn=True,
        columns=[C("number", "Shipment #"), C("so_number", "SO #"), C("customer_name", "Customer"),
                 C("date", "Date", "date"), C("carrier", "Carrier"), C("tracking", "Tracking"),
                 C("invoice_number", "Invoice"), C("cost_value", "Cost", "money")],
        search=["number", "so_number", "customer_name", "tracking"], sort="id", dir="desc", datecol="date"),
    "invoices": dict(
        label="Invoice", plural="Invoices", view="v_invoices", group="Sales", txn=True,
        columns=[C("number", "Invoice #"), C("customer_name", "Customer"), C("so_number", "SO #"),
                 C("date", "Date", "date"), C("due_date", "Due", "date"), C("total", "Total", "money"),
                 C("balance", "Balance", "money"), C("days_overdue", "Days late", "int"), C("status", "Status", "tag")],
        search=["number", "customer_name", "so_number"], filters={"status": STATUS_INV},
        sort="id", dir="desc", datecol="date"),
    "payments": dict(
        label="Customer payment", plural="Customer payments", view="v_payments", group="Sales", txn=True,
        columns=[C("number", "Payment #"), C("invoice_number", "Invoice #"), C("customer_name", "Customer"),
                 C("date", "Date", "date"), C("amount", "Amount", "money"), C("method", "Method"),
                 C("reference", "Reference")],
        search=["number", "invoice_number", "customer_name", "reference"], sort="id", dir="desc", datecol="date"),
    "production_orders": dict(
        label="Production order", plural="Production orders", view="v_production_orders", group="Manufacturing",
        txn=True,
        columns=[C("number", "MO #"), C("sku", "SKU"), C("item_name", "Item"), C("qty", "Qty", "qty"),
                 C("qty_completed", "Done", "qty"), C("start_date", "Start", "date"), C("due_date", "Due", "date"),
                 C("actual_cost", "Actual cost", "money"), C("status", "Status", "tag")],
        search=["number", "sku", "item_name"], filters={"status": STATUS_MO}, sort="id", dir="desc",
        datecol="start_date"),
    "boms": dict(
        label="Bill of materials", plural="Bills of materials", view="v_boms", group="Manufacturing", txn=True,
        columns=[C("sku", "SKU"), C("item_name", "Item"), C("version", "Rev"), C("component_count", "Components", "int"),
                 C("labor_cost", "Labor", "cost"), C("overhead_cost", "Overhead", "cost"),
                 C("rolled_cost", "Rolled cost", "cost"), C("active", "Active", "bool")],
        search=["sku", "item_name"], filters={"active": [1, 0]}, sort="sku"),
    "inventory_txns": dict(
        label="Inventory transaction", plural="Inventory ledger", view="v_inventory_txns", group="Inventory", txn=True,
        columns=[C("id", "#", "int"), C("ts", "Time", "datetime"), C("sku", "SKU"), C("item_name", "Item"),
                 C("location_code", "Loc"), C("type", "Type", "tag"), C("qty", "Qty", "qty"),
                 C("unit_cost", "Unit cost", "cost"), C("value", "Value", "money"),
                 C("balance_after", "Balance", "qty"), C("note", "Reference"), C("username", "User")],
        search=["sku", "item_name", "note", "type"],
        filters={"type": ["opening", "receipt", "shipment", "issue", "output", "adjustment", "transfer_in",
                          "transfer_out"]}, sort="id", dir="desc", datecol="ts"),
    "stock": dict(
        label="Stock", plural="Stock by location", view="v_stock", group="Inventory", txn=True,
        columns=[C("sku", "SKU"), C("item_name", "Item"), C("location_code", "Location"), C("qty", "On hand", "qty"),
                 C("uom", "UoM"), C("avg_cost", "Avg cost", "cost"), C("value", "Value", "money")],
        search=["sku", "item_name", "location_code"], sort="sku"),
    "audit_log": dict(
        label="Audit entry", plural="Audit log", view="audit_log", group="Admin", txn=True, role="manager",
        columns=[C("id", "#", "int"), C("ts", "Time", "datetime"), C("username", "User"), C("action", "Action", "tag"),
                 C("entity", "Entity"), C("entity_id", "ID", "int"), C("summary", "Summary")],
        search=["username", "action", "entity", "summary"], sort="id", dir="desc", datecol="ts"),
}


def entity(name):
    e = ENTITIES.get(name)
    if not e:
        raise NotFound(f"Unknown entity '{name}'.")
    return e


def public_meta():
    out = {}
    for k, e in ENTITIES.items():
        out[k] = {x: e.get(x) for x in ("label", "plural", "key", "group", "fields", "columns", "search",
                                       "filters", "bulk", "sort", "dir", "txn", "role", "datecol", "noimport")}
    return out


def _view_cols(c, view):
    return {r[1] for r in c.execute(f"PRAGMA table_info({view})")}


# ------------------------------------------------------------------- list
def list_rows(c, ctx, name, params, paged=True):
    e = entity(name)
    if e.get("role"):
        require(ctx, e["role"])
    view = e["view"]
    cols = _view_cols(c, view)
    where, args = [], []
    q = (params.get("q") or "").strip()
    if q:
        terms = [t for t in q.split() if t][:6]
        for t in terms:
            where.append("(" + " OR ".join(f"CAST({s} AS TEXT) LIKE ?" for s in e["search"]) + ")")
            args += [f"%{t}%"] * len(e["search"])
    for k, v in params.items():
        if k.startswith("f_") and v not in (None, ""):
            col = k[2:]
            if col in cols:
                where.append(f"{col} = ?")
                args.append(v)
    dc = e.get("datecol")
    if dc:
        if params.get("from"):
            where.append(f"substr({dc},1,10) >= ?")
            args.append(params["from"][:10])
        if params.get("to"):
            where.append(f"substr({dc},1,10) <= ?")
            args.append(params["to"][:10])
    if params.get("ids"):
        ids = [int(x) for x in str(params["ids"]).split(",") if x.strip().isdigit()]
        where.append(f"id IN ({','.join('?' * len(ids)) or 'NULL'})")
        args += ids
    sql_where = (" WHERE " + " AND ".join(where)) if where else ""
    sort = params.get("sort") or e.get("sort") or "id"
    if sort not in cols:
        sort = "id"
    d = "DESC" if (params.get("dir") or e.get("dir") or "asc").lower() == "desc" else "ASC"
    total = scalar(c, f"SELECT COUNT(*) FROM {view}{sql_where}", *args)
    sql = f"SELECT * FROM {view}{sql_where} ORDER BY {sort} {d}, id {d}"
    if paged:
        size = max(1, min(500, int(params.get("size") or 50)))
        page = max(1, int(params.get("page") or 1))
        sql += f" LIMIT {size} OFFSET {(page - 1) * size}"
    else:
        size, page = total, 1
    rows = all_(c, sql, *args)
    if name == "users":
        for r in rows:
            r.pop("pw_hash", None)
            r.pop("salt", None)
    if not can_see_sensitive(ctx):
        sens = {col["key"] for col in e["columns"] if col.get("sensitive")}
        for r in rows:
            for s in sens:
                r[s] = None
    return {"rows": rows, "total": total, "page": page, "size": size}


def can_see_sensitive(ctx):
    return ctx.role in ("admin", "manager")


def export_rows(c, ctx, name, params):
    e = entity(name)
    data = list_rows(c, ctx, name, params, paged=False)
    cols = [col for col in e["columns"] if not (col.get("sensitive") and not can_see_sensitive(ctx))]
    return [col["label"] for col in cols], [[r.get(col["key"]) for col in cols] for r in data["rows"]]


# ------------------------------------------------------------------- CRUD
def _coerce(c, f, v):
    t = f["type"]
    if v is None or (isinstance(v, str) and v.strip() == ""):
        if f.get("required"):
            raise BizError(f"{f['label']} is required.")
        if f.get("default") is not None:
            return f["default"]
        return 0 if t in ("int", "float", "money", "cost", "bool") else None
    if t == "bool":
        if isinstance(v, str):
            s = v.strip().lower()
            if s in ("1", "true", "yes", "y", "on", "active"):
                return 1
            if s in ("0", "false", "no", "n", "off", "inactive"):
                return 0
            raise BizError(f"{f['label']} must be yes/no.")
        return 1 if v else 0
    if t in ("int", "float", "money", "cost"):
        try:
            n = float(str(v).replace(",", "").replace("$", "").strip())
        except ValueError:
            raise BizError(f"{f['label']} must be a number.")
        if n < 0:
            raise BizError(f"{f['label']} cannot be negative.")
        if t == "int":
            if not n.is_integer():
                raise BizError(f"{f['label']} must be a whole number.")
            return int(n)
        return round(n, 2) if t == "money" else round(n, 6)
    if t == "date":
        s = str(v).strip()[:10]
        if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
            raise BizError(f"{f['label']} must be a date (YYYY-MM-DD).")
        return s
    if t == "select":
        s = str(v).strip().lower().replace(" ", "_")
        if s not in f["choices"]:
            raise BizError(f"{f['label']} must be one of: {', '.join(f['choices'])}.")
        return s
    if t == "ref":
        ref = entity(f["ref"])
        sv = str(v).strip()
        if isinstance(v, (int, float)) or sv.isdigit():
            r = scalar(c, f"SELECT id FROM {ref['table']} WHERE id=?", int(float(sv)))
            if r:
                return r
        r = scalar(c, f"SELECT id FROM {ref['table']} WHERE {ref['key']}=?", sv)
        if not r:
            raise BizError(f"{f['label']}: no {ref['label'].lower()} '{sv}'.")
        return r
    if t == "email":
        s = str(v).strip()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", s):
            raise BizError(f"{f['label']} is not a valid email address.")
        return s
    s = str(v).strip()
    if len(s) > 4000:
        raise BizError(f"{f['label']} is too long.")
    return s


def _validate_row(c, name, row, existing=None):
    e = entity(name)
    out = {}
    for f in e["fields"]:
        if f.get("readonly"):
            continue
        if f["name"] in row:
            out[f["name"]] = _coerce(c, f, row[f["name"]])
        elif existing is None:
            out[f["name"]] = _coerce(c, f, f.get("default"))
    if name == "assets" and out.get("salvage_value", 0) and out.get("cost") is not None \
            and out["salvage_value"] > out["cost"]:
        raise BizError("Salvage value cannot exceed cost.")
    if name == "employees" and existing and out.get("manager_id") == existing["id"]:
        raise BizError("An employee cannot be their own manager.")
    if name == "employees" and out.get("termination_date") and out.get("hire_date") \
            and out["termination_date"] < out["hire_date"]:
        raise BizError("Termination date cannot be before the hire date.")
    return out


def _friendly(e, err, ent):
    msg = str(err)
    if "UNIQUE" in msg:
        col = msg.split(".")[-1]
        return BizError(f"A {ent['label'].lower()} with this {col} already exists.")
    if "FOREIGN KEY" in msg:
        return BizError(f"This {ent['label'].lower()} is referenced by other records and cannot be deleted. "
                        "Deactivate it instead.")
    if "CHECK" in msg:
        return BizError(f"A value is outside the allowed range ({msg}).")
    return BizError(msg)


def get_record(c, ctx, name, id_):
    e = entity(name)
    if e.get("role"):
        require(ctx, e["role"])
    r = one(c, f"SELECT * FROM {e.get('view') or e['table']} WHERE id=?", id_)
    if not r:
        raise NotFound(f"{e['label']} {id_} not found.")
    r.pop("pw_hash", None)
    r.pop("salt", None)
    if not can_see_sensitive(ctx):
        for f in e.get("fields", []):
            if f.get("sensitive"):
                r[f["name"]] = None
    return r


def save_record(c, ctx, name, data):
    e = entity(name)
    if e.get("txn"):
        raise BizError(f"{e['plural']} are maintained through their own workflow.")
    require(ctx, e.get("role") or "clerk")
    with tx(c):
        id_ = data.get("id")
        existing = one(c, f"SELECT * FROM {e['table']} WHERE id=?", int(id_)) if id_ else None
        if id_ and not existing:
            raise NotFound(f"{e['label']} {id_} not found.")
        row = {k: v for k, v in data.items() if k != "id"}
        if not can_see_sensitive(ctx):
            for f in e["fields"]:
                if f.get("sensitive"):
                    row.pop(f["name"], None)
        vals = _validate_row(c, name, row, existing)
        if name == "users" and existing and existing["id"] and vals.get("active") == 0 \
                and existing["username"].lower() == ctx.username.lower():
            raise BizError("You cannot deactivate your own account.")
        try:
            if existing:
                if not vals:
                    return {"id": existing["id"]}
                c.execute(f"UPDATE {e['table']} SET {', '.join(k + '=?' for k in vals)} WHERE id=?",
                          (*vals.values(), existing["id"]))
                rid, act = existing["id"], "update"
            else:
                if name == "users":
                    from .auth import hash_password
                    pw = data.get("password") or ""
                    if len(pw) < 8:
                        raise BizError("New users need a password of at least 8 characters.")
                    h, s = hash_password(pw)
                    vals.update(pw_hash=h, salt=s)
                cols = ", ".join(vals)
                rid = c.execute(f"INSERT INTO {e['table']}({cols}) VALUES({','.join('?' * len(vals))})",
                                tuple(vals.values())).lastrowid
                act = "create"
        except sqlite3.IntegrityError as err:
            raise _friendly(e, err, e)
        after = one(c, f"SELECT * FROM {e['table']} WHERE id=?", rid)
        for d in (existing, after):
            if d:
                d.pop("pw_hash", None)
                d.pop("salt", None)
        changed = None
        if existing:
            changed = {k: [existing.get(k), after.get(k)] for k in after if existing.get(k) != after.get(k)}
            if not changed:
                return {"id": rid}
        audit(c, ctx.username, act, name, rid, f"{e['label']} {after.get(e['key'])} {act}d",
              {k: v[0] for k, v in changed.items()} if changed else None,
              {k: v[1] for k, v in changed.items()} if changed else after)
        return {"id": rid}


def delete_record(c, ctx, name, id_):
    e = entity(name)
    if e.get("txn"):
        raise BizError(f"{e['plural']} cannot be deleted; cancel or void them instead.")
    require(ctx, "manager" if not e.get("role") else e["role"])
    with tx(c):
        r = one(c, f"SELECT * FROM {e['table']} WHERE id=?", id_)
        if not r:
            raise NotFound(f"{e['label']} {id_} not found.")
        if name == "items" and scalar(c, "SELECT COUNT(*) FROM inventory_txns WHERE item_id=?", id_):
            raise BizError("This item has inventory history and cannot be deleted. Deactivate it instead.")
        if name == "users" and r["username"].lower() == ctx.username.lower():
            raise BizError("You cannot delete your own account.")
        try:
            c.execute("DELETE FROM stock WHERE item_id=? AND qty=0", (id_,)) if name == "items" else None
            c.execute(f"DELETE FROM {e['table']} WHERE id=?", (id_,))
        except sqlite3.IntegrityError as err:
            raise _friendly(e, err, e)
        r.pop("pw_hash", None)
        r.pop("salt", None)
        audit(c, ctx.username, "delete", name, id_, f"{e['label']} {r.get(e['key'])} deleted", r, None)
        return {"ok": True}


def bulk_update(c, ctx, name, ids, field, op, value):
    e = entity(name)
    require(ctx, "manager")
    if field not in (e.get("bulk") or []):
        raise BizError(f"'{field}' cannot be bulk edited.")
    f = next(x for x in e["fields"] if x["name"] == field)
    if f.get("sensitive") and not can_see_sensitive(ctx):
        raise BizError("Not permitted.")
    ids = [int(i) for i in ids or []]
    if not ids:
        raise BizError("Select at least one record.")
    if len(ids) > 5000:
        raise BizError("Bulk edits are limited to 5,000 records at a time.")
    numeric = f["type"] in ("int", "float", "money", "cost")
    if op in ("add", "pct") and not numeric:
        raise BizError("Arithmetic bulk edits only apply to numeric fields.")
    with tx(c):
        n = 0
        for i in ids:
            r = one(c, f"SELECT * FROM {e['table']} WHERE id=?", i)
            if not r:
                continue
            if op == "set":
                newv = _coerce(c, f, value)
            else:
                try:
                    amt = float(value)
                except (TypeError, ValueError):
                    raise BizError("Enter a numeric amount.")
                cur = r[field] or 0
                newv = cur + amt if op == "add" else cur * (1 + amt / 100.0)
                if newv < 0:
                    raise BizError(f"{r.get(e['key'])}: result would be negative.")
                newv = _coerce(c, f, round(newv, 2 if f["type"] == "money" else 6) if f["type"] != "int" else round(newv))
            if r[field] == newv:
                continue
            try:
                c.execute(f"UPDATE {e['table']} SET {field}=? WHERE id=?", (newv, i))
            except sqlite3.IntegrityError as err:
                raise _friendly(e, err, e)
            audit(c, ctx.username, "bulk_update", name, i, f"{f['label']}: {r[field]} -> {newv}",
                  {field: r[field]}, {field: newv})
            n += 1
        return {"updated": n}


# ------------------------------------------------------------------- import / export
def import_layout(name):
    e = entity(name)
    cols = []
    for f in e["fields"]:
        if f.get("readonly"):
            continue
        cols.append((f["name"][:-3] if f["type"] == "ref" else f["name"], f))
    return cols


def export_for_import(c, ctx, name):
    e = entity(name)
    lay = import_layout(name)
    rows = []
    for r in all_(c, f"SELECT * FROM {e['table']} ORDER BY {e['key']}"):
        out = []
        for hdr, f in lay:
            v = r.get(f["name"])
            if f.get("sensitive") and not can_see_sensitive(ctx):
                v = None
            if f["type"] == "ref" and v:
                ref = entity(f["ref"])
                v = scalar(c, f"SELECT {ref['key']} FROM {ref['table']} WHERE id=?", v)
            out.append(v)
        rows.append(out)
    return [h for h, _ in lay], rows


def import_rows(c, ctx, name, headers, rows, dry_run=True):
    e = entity(name)
    if e.get("txn") or e.get("noimport"):
        raise BizError(f"{e['plural']} cannot be imported.")
    require(ctx, "manager")
    lay = import_layout(name)
    lookup = {}
    for hdr, f in lay:
        for alias in (hdr, f["name"], f["label"]):
            lookup[re.sub(r"[^a-z0-9]", "", alias.lower())] = f
    mapping = []
    unknown = []
    for h in headers:
        f = lookup.get(re.sub(r"[^a-z0-9]", "", (h or "").lower()))
        mapping.append(f)
        if not f and h:
            unknown.append(h)
    keyf = next(f for f in e["fields"] if f["name"] == e["key"])
    if keyf not in mapping:
        raise BizError(f"The file must include a '{e['key']}' column.")
    result = {"created": 0, "updated": 0, "unchanged": 0, "errors": [], "ignored_columns": unknown,
              "dry_run": bool(dry_run), "rows": len(rows)}

    class _Rollback(Exception):
        pass

    try:
        with tx(c):
            for i, raw in enumerate(rows, 2):
                rec = {}
                for f, v in zip(mapping, raw):
                    if f and not (f.get("sensitive") and not can_see_sensitive(ctx)):
                        rec[f["name"]] = v
                key = str(rec.get(e["key"]) or "").strip()
                if not key:
                    result["errors"].append({"row": i, "message": f"Missing {keyf['label']}."})
                    continue
                existing = one(c, f"SELECT * FROM {e['table']} WHERE {e['key']}=?", key)
                try:
                    if existing:
                        rec = {k: v for k, v in rec.items() if v not in (None, "")}  # blanks keep current values
                    vals = _validate_row(c, name, rec, existing)
                    if existing:
                        diff = {k: v for k, v in vals.items() if existing.get(k) != v}
                        if not diff:
                            result["unchanged"] += 1
                            continue
                        c.execute(f"UPDATE {e['table']} SET {', '.join(k + '=?' for k in diff)} WHERE id=?",
                                  (*diff.values(), existing["id"]))
                        audit(c, ctx.username, "import_update", name, existing["id"], f"{key} updated by import",
                              {k: existing.get(k) for k in diff}, diff)
                        result["updated"] += 1
                    else:
                        rid = c.execute(f"INSERT INTO {e['table']}({', '.join(vals)}) VALUES({','.join('?' * len(vals))})",
                                        tuple(vals.values())).lastrowid
                        audit(c, ctx.username, "import_create", name, rid, f"{key} created by import", None, vals)
                        result["created"] += 1
                except BizError as err:
                    result["errors"].append({"row": i, "key": key, "message": str(err)})
                except sqlite3.IntegrityError as err:
                    result["errors"].append({"row": i, "key": key, "message": str(_friendly(e, err, e))})
            if dry_run or result["errors"]:
                raise _Rollback()
    except _Rollback:
        result["committed"] = False
        return result
    result["committed"] = True
    return result


# ------------------------------------------------------------------- search
SEARCH_TARGETS = [
    ("customers", "code", "name"), ("suppliers", "code", "name"), ("items", "sku", "name"),
    ("sales_orders", "number", "customer_name"), ("purchase_orders", "number", "supplier_name"),
    ("invoices", "number", "customer_name"), ("bills", "number", "supplier_name"),
    ("production_orders", "number", "item_name"), ("shipments", "number", "customer_name"),
    ("receipts", "number", "supplier_name"), ("employees", "code", "full_name"), ("assets", "tag", "name"),
]


def global_search(c, ctx, q, limit=6):
    q = (q or "").strip()
    if len(q) < 2:
        return []
    out = []
    for name, a, b in SEARCH_TARGETS:
        e = ENTITIES[name]
        conds = " OR ".join(f"CAST({s} AS TEXT) LIKE ?" for s in e["search"])
        rows = all_(c, f"SELECT id, {a} AS a, {b} AS b, {('status' if 'status' in _view_cols(c, e['view']) else 'NULL')}"
                       f" AS status FROM {e['view']} WHERE {conds} ORDER BY CASE WHEN {a} LIKE ? THEN 0 ELSE 1 END, id DESC"
                       f" LIMIT {limit}", *([f"%{q}%"] * len(e["search"])), f"{q}%")
        for r in rows:
            out.append({"entity": name, "label": e["label"], "id": r["id"], "title": r["a"], "subtitle": r["b"],
                        "status": r["status"]})
    return out
