"""Local authentication: PBKDF2 password hashes, server-side sessions, CSRF tokens, lockout."""
import hashlib
import hmac
import secrets
import threading
import time
from datetime import datetime, timedelta

from .db import BizError, audit, one, setting, tx
from .services import Ctx

ITERATIONS = 240_000
_FAILS = {}
_FAIL_LOCK = threading.Lock()
MAX_FAILS, LOCK_SECONDS = 5, 300


def hash_password(pw, salt=None):
    salt = salt or secrets.token_hex(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), bytes.fromhex(salt), ITERATIONS).hex()
    return h, salt


def verify_password(pw, h, salt):
    return hmac.compare_digest(hash_password(pw, salt)[0], h)


def _locked(username):
    with _FAIL_LOCK:
        n, until = _FAILS.get(username.lower(), (0, 0))
        return until > time.time()


def _fail(username):
    with _FAIL_LOCK:
        n, until = _FAILS.get(username.lower(), (0, 0))
        n += 1
        _FAILS[username.lower()] = (n, time.time() + LOCK_SECONDS if n >= MAX_FAILS else 0)


def login(c, username, password):
    username = (username or "").strip()
    if _locked(username):
        raise BizError("Too many failed attempts. Try again in a few minutes.")
    u = one(c, "SELECT * FROM users WHERE username=?", username)
    if not u or not u["active"] or not verify_password(password or "", u["pw_hash"], u["salt"]):
        _fail(username)
        with tx(c):
            audit(c, username or "?", "login_failed", "users", u["id"] if u else None, "Failed sign-in")
        raise BizError("Invalid username or password.")
    with _FAIL_LOCK:
        _FAILS.pop(username.lower(), None)
    token, csrf = secrets.token_urlsafe(32), secrets.token_urlsafe(24)
    hours = setting(c, "session_hours")
    with tx(c):
        c.execute("DELETE FROM sessions WHERE expires_at < ?", (datetime.now().isoformat(),))
        c.execute("INSERT INTO sessions(token,user_id,csrf,created_at,expires_at) VALUES(?,?,?,?,?)",
                  (hashlib.sha256(token.encode()).hexdigest(), u["id"], csrf, datetime.now().isoformat(),
                   (datetime.now() + timedelta(hours=hours)).isoformat()))
        audit(c, u["username"], "login", "users", u["id"], "Signed in")
    return token, csrf, u


def session_user(c, token):
    if not token:
        return None
    r = one(c, "SELECT s.csrf, s.expires_at, u.* FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token=?",
            hashlib.sha256(token.encode()).hexdigest())
    if not r or not r["active"] or r["expires_at"] < datetime.now().isoformat():
        return None
    return r


def logout(c, token):
    with tx(c):
        c.execute("DELETE FROM sessions WHERE token=?", (hashlib.sha256((token or "").encode()).hexdigest(),))


def change_password(c, user_id, old, new):
    u = one(c, "SELECT * FROM users WHERE id=?", user_id)
    if not verify_password(old or "", u["pw_hash"], u["salt"]):
        raise BizError("Current password is incorrect.")
    _set_pw(c, u, new, u["username"])


def admin_reset_password(c, ctx, user_id, new):
    from .services import require
    require(ctx, "admin")
    u = one(c, "SELECT * FROM users WHERE id=?", user_id)
    if not u:
        raise BizError("User not found.")
    _set_pw(c, u, new, ctx.username, must_change=True)


def _set_pw(c, u, new, actor, must_change=False):
    if len(new or "") < 8:
        raise BizError("Passwords must be at least 8 characters.")
    if new.lower() in (u["username"].lower(), "password", "12345678"):
        raise BizError("Choose a less guessable password.")
    h, s = hash_password(new)
    with tx(c):
        c.execute("UPDATE users SET pw_hash=?, salt=?, must_change_pw=? WHERE id=?", (h, s, int(must_change), u["id"]))
        c.execute("DELETE FROM sessions WHERE user_id=?", (u["id"],)) if must_change else None
        audit(c, actor, "password", "users", u["id"], f"Password changed for {u['username']}")


def ensure_admin(c):
    """Create the initial admin account on an empty database."""
    if one(c, "SELECT id FROM users LIMIT 1"):
        return None
    h, s = hash_password("admin")
    with tx(c):
        c.execute("INSERT INTO users(username,full_name,role,pw_hash,salt,must_change_pw) VALUES(?,?,?,?,?,1)",
                  ("admin", "Administrator", "admin", h, s))
    return "admin"


def ctx_for(u):
    return Ctx(username=u["username"], role=u["role"])
