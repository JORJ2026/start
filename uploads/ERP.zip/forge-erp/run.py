#!/usr/bin/env python3
"""Forge ERP launcher.

    python3 run.py                 start (creates data/erp.db on first run)
    python3 run.py --demo          start with a fresh 12-month synthetic dataset
    python3 run.py --port 9000 --no-browser
"""
import argparse
import os
import sys
import threading
import webbrowser

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from erp import backup, db, seed  # noqa: E402
from erp.auth import ensure_admin  # noqa: E402
from erp.server import serve  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Forge ERP - offline manufacturing & distribution ERP")
    ap.add_argument("--db", default=os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "erp.db"))
    ap.add_argument("--host", default="127.0.0.1", help="Bind address (default: this computer only)")
    ap.add_argument("--port", type=int, default=8765)
    ap.add_argument("--demo", action="store_true", help="Replace the database with fresh synthetic demo data")
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--allow-host", action="append", default=[], help="Extra Host header to accept (LAN use)")
    a = ap.parse_args()

    if a.demo and os.path.exists(a.db):
        conn = db.open_db(a.db)
        backup.create_backup(conn, a.db, "pre-demo")
        conn.close()
        for ext in ("", "-wal", "-shm"):
            if os.path.exists(a.db + ext):
                os.remove(a.db + ext)
    fresh = not os.path.exists(a.db)
    conn = db.open_db(a.db)
    if a.demo or (fresh and not os.environ.get("ERP_EMPTY")):
        print("Generating 12 months of synthetic business history...", flush=True)
        r = seed.seed(conn)
        print(f"  history {r['start']} to {r['end']}", flush=True)
    created = ensure_admin(conn)
    if created:
        print("Created initial user  admin / admin  (change it after signing in)")
    if not fresh and db.setting(conn, "auto_backup_on_start"):
        b = backup.create_backup(conn, a.db, "startup")
        backup.prune(a.db, db.setting(conn, "backup_retention"))
        print(f"Startup backup: backups/{b['name']}")
    conn.close()

    httpd = serve(a.db, a.host, a.port, a.allow_host)
    url = f"http://{'127.0.0.1' if a.host in ('0.0.0.0', '') else a.host}:{a.port}/"
    print(f"Forge ERP running at {url}  (Ctrl+C to stop)", flush=True)
    if not a.no_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping.")
    finally:
        httpd.server_close()


if __name__ == "__main__":
    main()
